%------------------------------------------------------------------------
%
%------------------------------------------------------------------------

function showProfile(I,theta)
  
if (abs(theta) == pi/2)
    theta = theta+0.01;
end

a = tan(theta); % slop of the line
r = size(I,1);  % size of the image (aimed square)

if a>1
    x0 = floor((a-1)*r/(2*a)+1);
    xn = floor((a+1)*r/(2*a));
elseif a<-1
    x0 = floor((a+1)*r/(2*a)+1);
    xn = floor((a-1)*r/(2*a));
else 
    x0 = 1;
    xn = r;
end;

% we define the segment intersection between the image I and y=tan(theta)x
xi = x0:1:xn;         
yi = a*xi+(1-a)*r/2;

% the linescan are points (cx,cy) with intensity C
[cx,cy,C] = improfile(I,xi,yi);    % STRANGE there is a NaN !

% Hurst index estimation of the linescan (aimed to be a fBm)
Hest = VaPkstST(C,size(C,1),2,[1 -1])

% Radon transform for the angle theta
R = radon(I,theta)
size(R,1)
R(R==0) = []; % to delete zeros
R
HRest = VaPkstST(R,size(R,1),2,[1 -1]) % doesn't work because it is not a fBm !!
                                       % use instead wavelet to estimate H

%-----------------%
% Display results %
%-----------------%

figure;
subplot(511);
img = mat2gray(I);
imshow(img);
hold on
plot(xi,yi,'r');
title('profile define by the line y=tan(theta)x');

subplot(512);
plot(1:length(C),C,'r');
grid on, axis tight
xlabel('lateral distance [px]');
ylabel('intensity');
title('profile');

subplot(513);
p=zeros(10,size(C,1));
for i=1:10
    p(i,:)=C';
end
prof=mat2gray(p);
imshow(prof)

subplot(514);
plot(1:length(R),R,'r');
grid on, axis tight
xlabel('lateral distance [px]');
ylabel('intensity');
title('profile');

subplot(515);
p=zeros(10,size(R,1));
for i=1:10
    p(i,:)=R';
end
prof=mat2gray(p);
imshow(prof)
end