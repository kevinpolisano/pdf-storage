% ------------------------------------------------------------------------
%
% Author : Kevin Polisano
% Email  : kevin.polisano@ensimag.fr
% Adress : LJK Grenoble
%
% Input :
%           I : the matrix (image) whose we want to analyze orientations
%           Tab : the angles of turning bands and their Hurst exponent
%           theta_tab(k) : orientation vectors at scale k
%           angles_tab(k) : angle defined of these vectors at scale k
%           his_tab(k) : histogram of the repartition of these angles
%           xout_tab(k) : index of the histogram (see help hist in matlab)
%           anglemax_tab(k) : the dominant angle in the histogram
%
%   This GUI represents the features at different scales k
%   The refresh is made by the file updateh.m
%-------------------------------------------------------------------------
function varargout = orientation(varargin)
% ORIENTATION MATLAB code for orientation.fig
%      ORIENTATION, by itself, creates a new ORIENTATION or raises the existing
%      singleton*.
%
%      H = ORIENTATION returns the handle to a new ORIENTATION or the handle to
%      the existing singleton*.
%
%      ORIENTATION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ORIENTATION.M with the given input arguments.
%
%      ORIENTATION('Property','Value',...) creates a new ORIENTATION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before orientation_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to orientation_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help orientation

% Last Modified by GUIDE v2.5 12-Jun-2013 15:53:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @orientation_OpeningFcn, ...
                   'gui_OutputFcn',  @orientation_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before orientation is made visible.
function orientation_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to orientation (see VARARGIN)

% Choose default command line output for orientation
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

I = varargin{1};
setappdata(handles.figure1,'I',I);
as = varargin{2};
setappdata(handles.figure1,'as',as);
Wx = varargin{3};
setappdata(handles.figure1,'Wx',Wx)
theta_tab = varargin{4};
setappdata(handles.figure1,'theta_tab',theta_tab);
angles_tab = varargin{5};
setappdata(handles.figure1,'angles_tab',angles_tab);
his_tab = varargin{6};
setappdata(handles.figure1,'his_tab',his_tab);
xout_tab = varargin{7};
setappdata(handles.figure1,'xout_tab',xout_tab);
k = 1;
setappdata(handles.figure1,'k',k);
anglemax_tab = varargin{8};
setappdata(handles.figure1,'anglemax_tab',anglemax_tab);
Tab = varargin{9};
hissym_tab = varargin{10};
setappdata(handles.figure1,'Tab',Tab);
setappdata(handles.figure1,'hissym_tab',hissym_tab);
set(handles.text1,'String','k =');
setappdata(handles.figure1,'tog1',0);
setappdata(handles.figure1,'tog2',0);
updateh(handles);



% UIWAIT makes orientation wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = orientation_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
h = get(hObject,'Value'); % we get the value of the slider before calling
as = getappdata(handles.figure1,'as');
na = length(as);
k = 2 + floor(h*(na-1));
setappdata(handles.figure1,'k',k);
updateh(handles);


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double



% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in togglebutton1.
function togglebutton1_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton1
h = get(hObject,'Value');
setappdata(handles.figure1,'tog1',h);
updateh(handles);


% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton2
h = get(hObject,'Value');
setappdata(handles.figure1,'tog2',h);
updateh(handles);


% --------------------------------------------------------------------
% function uipushtool1_ClickedCallback(hObject, eventdata, handles)
% % hObject    handle to uipushtool1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% im_final = getframe(handles.axes4);
% image(im_final.cdata);
% imwrite(im_final.cdata,'essai.jpg');


% --------------------------------------------------------------------
function uipushtool1_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to uipushtool1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
im_Hist = getframe(handles.axes4);
image(im_Hist.cdata);
im_Orient = getframe(handles.axes2);
image(im_Orient.cdata);
im_Map = getframe(handles.axes3);
image(im_Map.cdata);
k = getappdata(handles.figure1,'k');
nameHist = strcat('Images/hist_',num2str(k),'.jpg');
nameOrient = strcat('Images/orientations_',num2str(k),'.jpg');
nameMap = strcat('Images/colormap_',num2str(k),'.jpg');
imwrite(im_Orient.cdata,nameOrient);
imwrite(im_Hist.cdata,nameHist);
imwrite(im_Map.cdata,nameMap);
