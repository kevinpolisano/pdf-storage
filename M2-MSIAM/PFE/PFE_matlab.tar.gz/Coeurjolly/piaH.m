function res=piaH(a,H,i)
%
% ----------------------------------------------------------------------------
% Input  : 
%                            a : filter
%                            H : Hurst parameter, 0<H<1.
%                            i : indice for which the covariance is evaluated.
% Output : 
%              Estimation of the covariance function of process of 
%              discrete variations of fBm, given by
%              pi_a^H (i) = -1/2 sum_{q=0}^{l}{ a_q a_r |q-r+i|^{2H} }
% 
% Example :       piaH( [1 -1], 0.6, i=0 ) 
%    
% ----------------------------------------------------------------------------
%
% Reference :   Phd Thesis Coeurjolly (2000), Chapter 2, p.26, Eq. 2.7
%
% ----------------------------------------------------------------------------

l=length(a)-1;
d=l+1;
res=0;
for q=0:l
for r=0:l
z=a(q+1)*a(r+1)*abs(q-r+i)^(2*H);
res=res-0.5*z;
end
end
