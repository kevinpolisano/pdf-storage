function [Hols,Cols]=VaPkolST(fBm,k,a,M)

% ------------------------------------------------------------------------
%
% Input   :
%                     fBm : data modelized by a standard fractional Brownian 
%                           motion.   
%                       k : power of the discrete variations.
%                       a : filter
%                       M : maximum number of dilatations
%
%
% Output  :
%
%             Hols,  Cols : estimation of the self-similarity parameter, H 
%                           and the scale coefficient by a simple linear 
%                           regression of  
%                           log( S_n(k,a^m) ) on log( m ) for m=1,...,M
%                           where a^m is the filter a, dilated m times and
%                           S_n(k,a^m) is the k-th absolute empirical 
%                           moment of discrete variations of fractional 
%                           Brownian motion  
%
%
% Example :  [Hols,Cols]= VaPkolST( circFBM(1000,0.3), 2, [1 -1], 5)
%
% Subroutines called : dilatation, piaH
%
% ------------------------------------------------------------------------
%
% References : 
%
%        Phd Thesis Coeurjolly (2000), Chapter 2, p.31-33. 
%
% ------------------------------------------------------------------------
%
% -------------------------------------------------------------------------
% Construction of k-th absolute empirical moment of the vector fBm filtered
% by dilated vectors of a
% -------------------------------------------------------------------------

SNkaM=zeros(M,1);
am=a;
for m=1:M
Vam=filter(am,1,fBm);Vam=Vam(length(am):length(fBm));
SNkaM(m)=mean(abs(Vam).^k);
am=dilatation(a,m+1);
end
% ----------------------------------------------------
% Estimation of parameters via a log-linear regression
% ----------------------------------------------------
LN=log(SNkaM)';
XM=zeros(M,2);
XM(:,2)=ones(1,M)';
XM(:,1)=k*log(1:M)';
S=XM' * XM;
size(S);
Sinv=inv(S);
T=XM' * LN';
alphaest=Sinv * T;
Hols=alphaest(1);
pia0=piaH(a,Hols,0);
N=length(fBm);
Ek= 2^(k/2) * gamma( (k+1)/2) / gamma(0.5);
Cols=N^(Hols)/(pia0^(1/k)) / Ek^(1/k) * exp(alphaest(2)/k);

