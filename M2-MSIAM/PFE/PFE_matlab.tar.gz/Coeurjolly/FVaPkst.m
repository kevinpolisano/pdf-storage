function Fres=FVaPkst(Htry,fBm,n,k,a)
%
% ------------------------------------------------------------------------
%
% Input   :
% 
%                    Htry : real in ]0,1[ for which Fres is evaluated  
%                     fBm : data modelized by a standard fractional Brownian 
%                           motion.   
%                       n : length of the discretized sample path 
%                       k : power of the discrete variations.
%                       a : filter
%
%
% Output  :
%              Value of the following function in Htry :
%               Fres(Htry)  = | log(SNka) - log( E(SNka) ) |
%              The minimum of this function will give an estimator of H. 
%
%
% Example :   Fres=FVaPkst( 0.5, circFBM(1000,0.9), 1000, 2, [1 -1])
%
% Subroutine called : piaH 
%
% ------------------------------------------------------------------------
%
% References : 
%
%        Phd Thesis Coeurjolly (2000), Chapter 2, p.28-30. 
%
% ------------------------------------------------------------------------
Va=filter(a,1,fBm);Va=Va(length(a):length(fBm));
SNka=mean(abs(Va).^k);
Ek=2^(k/2) * gamma(0.5*(k+1)) / gamma(0.5);
Fres=log(SNka)+k*Htry*log(n) -  log( piaH(a,Htry,0)^(k/2) * Ek );
Fres=abs(Fres);
