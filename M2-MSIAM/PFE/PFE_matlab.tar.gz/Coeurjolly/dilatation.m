function resdil=dilatation(a,m)
%
% -----------------------------------------
% Input : 
%               a : vector
%               m : number of dilatation
%
% Output :     Vector dilated m times
% 
% Example : resdil= dilatation( [1 -1], 3) 
%            
% -----------------------------------------
%
     la=length(a);
     am=zeros(m*la-1,1);
     am(1:m:m*la-1)=a;
     resdil=am;
