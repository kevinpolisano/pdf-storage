function Hest=VaPkstST(fBm,n,k,a)
%
% ------------------------------------------------------------------------
%
% Input   :
%                     fBm : data modelized by a standard fractional Brownian 
%                           motion.   
%                       n : length of the discretized sample path 
%                       k : power of the discrete variations.
%                       a : filter
%
%
% Output  :
%
%                  Estimation of the self-similarity parameter, H, 
%                  using the k-th absolute empirical moment of 
%                  standard fractional Bronian motion.
%
%
% Example :  Hest= VaPkstST( circFBM(1000,0.3), 1000, 2, [1 -1])
%
% Subroutine called : FVaPkst
%
% ------------------------------------------------------------------------
%
% References : 
%
%        Phd Thesis Coeurjolly (2000), Chapter 2, p.28-30. 
%
% ------------------------------------------------------------------------
OPTIONS=[];
Hest=fminbnd('FVaPkst',0,1,OPTIONS,fBm,n,k,a);
