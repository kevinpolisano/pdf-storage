function [frec] = testSQ()

% Parameters
nv = 16; % Nb coef par octave
gamma = 0.05; % Seuil
clwin = 7;

% Choice of Wavelet : decoment one line
% Generalized Morse : 'gmor beta - gamma'. Includes Derivatives of Gaussian
% when gamma=2
%myw = 'gmor2-2';
% Bump wavelet : 'bump mu - sigma'
%myw = 'bump0.6-0.2';
% Morlet wavelet : 'cmor Fb - Fc'
myw = 'cmor4-1';

%% Choice of signal : decoment one line
% Lenna
% %img = myread('lenna.gif');
% N = 256;t = linspace(0,1,N);x1 = ones(N,1)*t;x2 = t'*ones(1,N);
% len = myread('lenna.gif');
% osc =  cos (2*pi*(20*x1-10*x1.^2+17*x2-20*x2.^2+15*x1.*x2));
% len = 2*(len-mean(len(:)))/max(len(:));
% img = len + osc;
% %imagesc(img);return;

% AM/FM
%N = 256;t = linspace(0,1,N);x1 = ones(N,1)*t;x2 = t'*ones(1,N);img = 3*cos(2*pi*2.9*(x1+x2))+ cos(2*pi*5*(x1+2*x2)) + (1+0.1*cos(2*pi*(x1+1.2*x2))).*cos(2*pi*27*(x1+2.31*x2));
%N = 256;t = linspace(0,1,N);x1 = ones(N,1)*t;x2 = t'*ones(1,N);img = cos(2*pi*(17*x1+22*x2));%figure();imagesc(img);return;
% Texture
%img = myread('textures/nuts.pgm');
%img = myread('textures/grass.jpg');
%img = myread('textures/sands.jpg');
%img = myread('textures/fringe_face.jpg');

%img = myread('textures/metal.pgm');
%img = myread('textures/checkerboard.pgm');
% Quadratic phase
N = 256;t = linspace(0,1,N);x1 = ones(N,1)*t;x2 = t'*ones(1,N); phi = (2*pi*(52*x1+10*x1.^2+17*x2-20*x2.^2-41*x1.*x2));disp(coeps(phi));img = cos(phi)+1.2*sin(2*pi*14*(x1+x2)) + 2*exp(-10*((x1-0.5).^2+(x2-0.5).^2)) .* sin(2*pi*5*(x1.^2+x2.^2+0.2*(x1+0.2*x2)));

% 4 sinus
%N = 256;t = linspace(0,1,N);x1 = ones(N,1)*t;x2 = t'*ones(1,N);img = cos(2*pi*5*(x1+x2))+2*cos(2*pi*13*(x1+2*x2))+1.4*cos(2*pi*27*(x1+2.3*x2))+0.4*cos(2*pi*40*(1.7*x1+2.3*x2));
%N = 128;t = linspace(0,1,N);x1 = ones(N,1)*t;x2 = t'*ones(1,N);img = 41*cos(2*pi*(x1+0.2*x2))+0*randn(N,N);% noise
% Synthetic 2D from wavelab
%img = MakeImage('Circle',128);
%img = randn(256,256);

% noise
%img = randn(256,256);


% Display
%figure();imagesc(img);colormap('gray');return;%figure();plot(t,img(N/2,:),t,cos(2*pi*120*t),'r');return;

%% SQ

N = size(img,1);
maxna = log2(N)-1;
as = 2.^(0:(1/nv):maxna);

% Riesz transform and componentwise wavelet transform
%Wx = monowt2(img,as,myw);

% Display results
%disp3D(as,Wx,1);return;
%monodisp(as,Wx);return; % 2D

% Synchrosqueezing step
[fs Wx Tx] = monosq2(img,nv,as,gamma,myw);


% Extraction of ridge
[fi e] = brevridge(Tx, 0.001, 3, clwin);

res = img;
index = N/8+1:7*N/8;
for l=1:length(fi)
    c = fi{l};
    frec =  synth1(Tx,myw,nv,c,clwin);
    figure();imagesc(frec(index,index));colormap('gray');title(['Mode ' num2str(l)]);
    res = res - frec;
    figure();imagesc(res(index,index));colormap('gray');title(['Residual ' num2str(l)]);
end

figure(); imagesc(img);colormap('gray');

%% Face reconstruction
%c(c<20)=NaN;figure();surf(-c);set(findall(gca,'type','surf'),'edgecolor','none');colormap('gray');
 
%return;

% Display results
disp3D(as,Tx,2);
monodisp(fs,Tx);
