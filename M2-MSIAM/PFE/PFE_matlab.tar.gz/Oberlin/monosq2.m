function [fs Wx Tx] = monosq2(s,nv,as,gamma,mywav)
% monosq2 : computes the 2D monogenic synchrosqueezing transform of an image
%
% Inputs :
%   s : square image, size power of 2
%   nv : number of scales per octave
%   as : vector of scales
%   gamma : threshold for sq
%   mywav : string name of the wavelet
% Output
%   Wx and Tx: na-cells of cells of matrix of wavelet/synchrosqueezing coefficients. Wx{a}{l}(b) : coefficient at scale
%   as(a) and time b=(b1,b2) of dimension l (l=1, 2 or 3).

n = size(s,1);
na = length(as);

z = triesz(s);

% symmetric padding of each component
[N x1 n1] = mypad2(z{1});
[N x2 n1] = mypad2(z{2});
[N x3 n1] = mypad2(z{3});

% Frequency vector : fftshift
xi1 = 2*ones(N,1)*(-N/2+1:N/2)/N;
xi2 = xi1';
xi = xi1.^2 + xi2.^2;
xi = sqrt(xi);

%% Wavelet transform and derivatives
% Initialization
Wx = cell(na);
Wdx = cell(na);
Wdy = cell(na);

xh1 = fftshift(fft2(x1));
xh2 = fftshift(fft2(x2));
xh3 = fftshift(fft2(x3));

% Filter definition
if strncmp(mywav,'gmor',4)
    [v1 v2] = regexp(mywav,'[0-9]*-[0-9]');
    beta = str2num(mywav(v1:v2-2));
    gam = str2num(mywav(v2:end));
    filt = @(a) gmor2(beta,gam,a*xi);
    filtdx = @(a) -N*1i*pi*xi1 .* gmor2(beta,gam,a*xi);
    filtdy = @(a) -N*1i*pi*xi2 .* gmor2(beta,gam,a*xi);
elseif strncmp(mywav,'cmor',4)
    [v1 v2] = regexp(mywav,'[0-9]*-[0-9]');
    Fb = str2num(mywav(v1:v2-2));
    Fc= str2num(mywav(v2:end));
    filt = @(a) cmor2(Fb,Fc,a*xi);
    filtdx = @(a) -N*1i*pi*xi1 .* cmor2(Fb,Fc,a*xi);
    filtdy = @(a) -N*1i*pi*xi2 .* cmor2(Fb,Fc,a*xi);
elseif strncmp(mywav,'bump',4)
    [v1 v2] = regexp(mywav,'[0-9]*-[0-9]');
    mu = str2num(mywav(v1:v2-2));
    sigma= str2num(mywav(v2:end));
    filt = @(a) bump2(mu,sigma,a*xi);
    filtdx = @(a) -N*1i*pi*xi1 .* bump2(mu,sigma,a*xi);
    filtdy = @(a) -N*1i*pi*xi2 .* bump2(mu,sigma,a*xi);
end

% for each octave
for ai = 1:na
 	a = as(ai);
    
    % wavelet
    psih = conj(filt(a));
    tmp1 = real(ifft2(ifftshift(psih .* xh1)));
    tmp2 = real(ifft2(ifftshift(psih .* xh2)));
    tmp3 = real(ifft2(ifftshift(psih .* xh3)));
    Wx{ai} = {tmp1(n1+1:n1+n,n1+1:n1+n), tmp2(n1+1:n1+n,n1+1:n1+n), tmp3(n1+1:n1+n,n1+1:n1+n)};
    
    % x derivative
    psih = conj(filtdx(a));
    tmp1 = real(ifft2(psih .* xh1));
    tmp2 = real(ifft2(psih .* xh2));
    tmp3 = real(ifft2(psih .* xh3));
    Wdx{ai} = {tmp1(n1+1:n1+n,n1+1:n1+n), tmp2(n1+1:n1+n,n1+1:n1+n), tmp3(n1+1:n1+n,n1+1:n1+n)};
    
    % y derivative
    psih = conj(filtdy(a));
    tmp1 = real(ifft2(psih .* xh1));
    tmp2 = real(ifft2(psih .* xh2));
    tmp3 = real(ifft2(psih .* xh3));
    Wdy{ai} = {tmp1(n1+1:n1+n,n1+1:n1+n), tmp2(n1+1:n1+n,n1+1:n1+n), tmp3(n1+1:n1+n,n1+1:n1+n)};
end
 

%% Synchrosqueezing step
na = length(Wx);
[N1 N2] = size(Wx{1}{1});

% Only square images
if N1~=N2
    errordlg('Only squared images!');
    return;
else 
    N=N1;
end

fs = 1./as*N/2;

Tx = cell(na,1);
for k=1:na
    Tx{k} = {zeros(N1,N2),zeros(N1,N2),zeros(N1,N2)};
end

for ai = 1:na
    amp = abs3(Wx{ai});
    [kx ky] = freqi(Wx{ai},Wdx{ai},Wdy{ai});
    w = 0.5*sqrt(kx.^2+ky.^2);
    if 0%sum(amp(:))>N*N*0.1
        disp(mean(w(:)));
    end
    k = round(1+nv*log2(w));
    b = 1:(N1*N2);k = k(:);
    idx = find(amp<gamma);b(idx)=[];k(idx) = [];
	idx = find(k<1);b(idx)=[];k(idx) = [];
    idx = find(k>na);b(idx)=[];k(idx) = [];
        
    for l=1:length(k)
        Tx{k(l)}{1}(b(l)) = Tx{k(l)}{1}(b(l))+Wx{ai}{1}(b(l));
        Tx{k(l)}{2}(b(l)) = Tx{k(l)}{2}(b(l))+Wx{ai}{2}(b(l));
        Tx{k(l)}{3}(b(l)) = Tx{k(l)}{3}(b(l))+Wx{ai}{3}(b(l));
    end
    
end
   

