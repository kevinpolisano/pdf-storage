function res=plotslice(Wx,dir,sl)

na = length(Wx);
n = size(Wx{1}{1},1);

res = zeros(na,n);
if dir==1
    for k=1:na
        tmp = abs3(Wx{k});
        res(k,:) = tmp(:,sl);
    end
else
    for k=1:na
        tmp = abs3(Wx{k});
        res(k,:) = tmp(sl,:);
    end
end
