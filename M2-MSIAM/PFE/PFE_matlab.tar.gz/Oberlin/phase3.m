function [phi theta] = phase3(z)

num = z{2}.^2+z{3}.^2;
num = sqrt(num);

phi = atan2(num,sqrt(z{1}.^2));

theta{1} = z{2} ./ num;
theta{2} = z{3} ./ num;
