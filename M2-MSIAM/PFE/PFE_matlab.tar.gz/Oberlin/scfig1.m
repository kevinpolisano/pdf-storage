function scfig1()
%SCFIG1 plots the figures of paper SST 2D

N = 256;
t = linspace(0,1,N);
x1 = ones(N,1)*t;
x2 = t'*ones(1,N); 

phi = (2*pi*(70*x1+20*x1.^2+50*x2-20*x2.^2-41*x1.*x2));%disp(coeps(phi));
f3 = cos(phi);
f2 = 1.2*sin(2*pi*20*(x1+x2));
f1 = 2*exp(-10*((x1-0.5).^2+(x2-0.5).^2)) .* sin(2*pi*5*(x1.^2+x2.^2+2*(x1+0.2*x2)));

f = f1+f2+f3; % haute, moyenne et basse fréquence

%% Figure 1
% Plot signals f, f1, etc
figure();imagesc(f);formfig();
figure();imagesc(f1);formfig();
figure();imagesc(f2);formfig();
figure();imagesc(f3);formfig();

% Monogenic wavelet
N = size(f,1);
nv = 32;
gamma = 0.01;
myw = 'cmor2-1';
maxna = log2(N)-1;
as = 2.^(0:(1/nv):maxna);
% Riesz transform and componentwise wavelet transform
% and Synchrosqueezing step
[fs Wx Tx] = monosq2(f,nv,as,gamma,myw);

% Display results : 3D
disp3D(as,Wx,1);
set(gca,'CameraPosition',[-2244 910.4 9.28]);formfig();
disp3D(as,Tx,2);
set(gca,'CameraPosition',[-2244 910.4 9.28]);formfig();

% Display results : section
% section parameters
figure();
sl = 128;dir = 2;
% Compute slice
res=plotslice(Wx,dir,sl);
% display
imagesc((0:N-1)/N,as,log(1+flipud(res)));colormap('gray');
set(gca,'YDir','normal');
set(gcf,'colormap',flipud(get(gcf,'colormap')));
ylabel('Scale a');
xlabel('y');
set(gca,'YTick',(linspace(as(1),as(end),8)),'YTickLabel',fliplr(as(floor(linspace(1,length(as),8)))));

% section parameters
figure();
sl = 128;dir = 2;
% Compute slice
res=plotslice(Tx,dir,sl);
% display
imagesc((0:N-1)/N,fs,log(1+flipud(res)));colormap('gray');
set(gca,'YDir','normal');
set(gcf,'colormap',flipud(get(gcf,'colormap')));
ylabel('Frequency (Hz)');
xlabel('y');
set(gca,'YTick',(linspace(as(1),as(end),8)),'YTickLabel',as(floor(linspace(1,length(as),8))));



%% FIgure 2
img = f1+f2+f3;
f = {f2;f3;f1};

for l=1:3
    f{l}(1:N/8,:)=0;f{l}(:,1:N/8)=0;f{l}(7*N/8+1:N,:)=0;f{l}(:,7*N/8+1:N)=0;
end
    
nv = 16; % Nb coef par octave
gamma = 0.05; % Seuil
clwin = 7;
myw = 'cmor4-1';


N = size(img,1);
maxna = log2(N)-1;
as = 2.^(0:(1/nv):maxna);

% Riesz transform and componentwise wavelet transform
%Wx = monowt2(img,as,myw);

% Synchrosqueezing step
[fs Wx Tx] = monosq2(img,nv,as,gamma,myw);


% Extraction of ridge
[fi e] = brevridge(Tx, 0.001, 3, clwin);

% Display with MSE
for l=1:length(fi)
    c = fi{l};
    frec{l} =  synth1(Tx,myw,nv,c,clwin);
    figure();
    imagesc(frec{l}(N/8+1:7*N/8,N/8+1:7*N/8));colormap('gray');
    formfig();
    title(['Mode ' num2str(l) ', ' 'normalized MSE : ' num2str(norm(frec{l}-f{l})/norm(f{l}))]);
end

%% Figure 3

% Signal
N = 256;t = linspace(0,1,N);x1 = ones(N,1)*t;x2 = t'*ones(1,N);
len = myread('lenna.gif');
%osc =  cos (2*pi*(20*x1-10*x1.^2+17*x2-20*x2.^2+15*x1.*x2));
osc = cos(2*pi*(10*x1-10*x2+8*x2.^2));
len = 2*(len-mean(len(:)))/max(len(:));
img = len + osc;

%figure();imagesc(img);colormap('gray');return;

nv = 16; % Nb coef par octave
gamma = 0.05; % Seuil
clwin = 8;
myw = 'cmor4-1';
maxna = log2(N)-1;
as = 2.^(0:(1/nv):maxna);

% Synchrosqueezing step
[fs Wx Tx] = monosq2(img,nv,as,gamma,myw);

% Extraction of ridge


for clwin = 1:10
[fi e] = brevridge(Tx, 0.001, 1, clwin);
c = fi{1};
frec =  synth1(Tx,myw,nv,c,clwin);
disp(['CLWIN = ' num2str(clwin) ', MSE = ' num2str(norm(frec(N/8+1:7*N/8,N/8+1:7*N/8)-osc(N/8+1:7*N/8,N/8+1:7*N/8))/norm(osc(N/8+1:7*N/8,N/8+1:7*N/8)))]);
end

clwin = 7;
[fi e] = brevridge(Tx, 0.001, 1, clwin);
c = fi{1};
frec =  synth1(Tx,myw,nv,c,clwin);

% Display
figure();imagesc(len(N/8+1:7*N/8,N/8+1:7*N/8));colormap('gray'); formfig()
figure();imagesc(osc(N/8+1:7*N/8,N/8+1:7*N/8));colormap('gray'); formfig()
figure();imagesc(img(N/8+1:7*N/8,N/8+1:7*N/8));colormap('gray'); formfig()
figure();imagesc(frec(N/8+1:7*N/8,N/8+1:7*N/8));colormap('gray'); formfig()
title(['normalized MSE : ' num2str(norm(frec(N/8+1:7*N/8,N/8+1:7*N/8)-osc(N/8+1:7*N/8,N/8+1:7*N/8))/norm(osc(N/8+1:7*N/8,N/8+1:7*N/8)))]);
figure();imagesc(img(N/8+1:7*N/8,N/8+1:7*N/8)-frec(N/8+1:7*N/8,N/8+1:7*N/8));colormap('gray'); formfig()
title(['normalized MSE : ' num2str(norm(frec(N/8+1:7*N/8,N/8+1:7*N/8)-osc(N/8+1:7*N/8,N/8+1:7*N/8))/norm(len(N/8+1:7*N/8,N/8+1:7*N/8)))]);




function formfig()
xlabel('x');
ylabel('y');
colormap('gray');
set(gca,'XTick',[],'YTick',[]);
set(gca,'Fontsize',12);
set(findall(0,'type','text'),'Fontsize',12);


