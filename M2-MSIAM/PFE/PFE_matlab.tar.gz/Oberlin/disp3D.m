function disp3D(as,Wx,f)

unders = 10;
tau = 30;

na = length(as);
[n1 n2] = size(Wx{1}{1}(1+tau:unders:end-tau,1+tau:unders:end-tau));

x = [];
y = [];
z = [];
c = [];

% COmputing threshold
seuil = 0;
for a=1:na
    tmp = abs3(Wx{a});
    vmax = max(tmp(:));
    seuil = max([seuil vmax]);
end
col = seuil;
seuil = seuil/50;

for a=1:na
    tmp = abs3(Wx{a});
    %tmp = conv2(tmp,ones(unders,unders),'same')/unders^2;
    amp = tmp(1+tau:unders:end-tau,1+tau:unders:end-tau);
    [xc yc] = find(amp>seuil);
    x = [x;xc];
    y = [y;yc];
    z = [z;log2(as(a))*ones(length(xc),1)];
    cc = amp(xc,yc);
    c = [c;amp(xc+n2*(yc-1))];
end

x = (x-1)*10+tau+1;
y = (y-1)*10+tau+1;

figure();
scatter3(x,y,z,100/col*c,c);

if f==1 % scale
    xlabel('x');ylabel('y');zlabel('Scale a');
    supoc = floor(max(log2(as(:))))+1;
    set(gca,'ZTick',0:supoc,'ZTickLabel',2.^(0:supoc));
    set(gca,'ZDir','reverse');
else % frequency
    xlabel('x');ylabel('y');zlabel('Frequency f');
    supoc = floor(max(log2(as(:))))+1;
    set(gca,'ZTick',0:supoc,'ZTickLabel',2.^(0:supoc));
end
colorbar();
