function img = myread(name)

img = double(imread(name));
if length(size(img))>2
	img = 0.2989*img(:,:,1) + 0.5870*img(:,:,2) + 0.1140*img(:,:,3);
end

% Force img to be square
[k l] = size(img);
n=2^floor(log2(min(k,l)));
img = img(floor((k-n)/2)+1:floor((k+n)/2),floor((l-n)/2)+1:floor((l+n)/2));