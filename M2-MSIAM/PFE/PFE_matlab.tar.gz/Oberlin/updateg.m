function updateg(handles)
% updateg updates the GUI 'monodisp', internal function do not edit

as = getappdata(handles.figure1,'as');
Wx = getappdata(handles.figure1,'Wx');
k = getappdata(handles.figure1,'k');
vmax = getappdata(handles.figure1,'vmax');
effect = getappdata(handles.figure1,'effect');
n = size(Wx{1}{1},1);
na = length(as);
switch(get(handles.popupmenu1,'Value'))
    case 1 % Amplitude 3D
        set(handles.text5,'Visible','on');
        set(handles.popupmenu3,'Visible','on');
        set(handles.edit2,'Visible','on');
        
        set(handles.text2,'Visible','off');
        set(handles.edit1,'Visible','off');
        set(handles.text4,'Visible','off');
        set(handles.popupmenu2,'Visible','off');
        set(handles.text3,'Visible','off');
        set(handles.slider1,'Visible','off');
        
        sl = str2num(get(handles.edit2,'String'));
        sl = round(sl);
        if sl<1 || sl>n
        	errordlg('Wrong value for b parameter');
            return;
        end
        dir = get(handles.popupmenu3,'Value');
        res=plotslice(Wx,dir,sl);
        imagesc(1:n,as,flipud(log(1+res)),'Parent',handles.axes1);colormap('gray');
        set(gca,'YDir','normal');
        set(gcf,'colormap',flipud(get(gcf,'colormap')));
        ylabel('frequency (Hz)');
        set(gca,'YTick',(linspace(as(end),as(1),8)),'YTickLabel',as(floor(linspace(1,length(as),8))));
        
    case 2 % Amplitude 2D slice
        set(handles.text2,'Visible','on');
        set(handles.edit1,'Visible','on');
        set(handles.text4,'Visible','on');
        set(handles.popupmenu2,'Visible','on');
        set(handles.text3,'Visible','on');
        set(handles.slider1,'Visible','on');
        
        set(handles.text5,'Visible','off');
        set(handles.popupmenu3,'Visible','off');
        set(handles.edit2,'Visible','off');
        
        switch(effect)
            case 'surf'
                surf(flipud(fliplr(abs3(Wx{k}))),'Parent',handles.axes1,'EdgeColor','none');colormap('jet');
                set(handles.axes1,'zlim',[0 0.1+vmax]);
            case 'img'
                imagesc((1+abs3(Wx{k})),'Parent',handles.axes1);colormap('gray');
                set(handles.axes1,'clim',[0 (1.1+vmax)]);
            otherwise
                errordlg('Internal error');
        end
       
    case 3 % Orientation theta
        idx = 1:(1+floor(n/30)):n;
        [phi theta] = phase3(Wx{k});
        quiver(idx,idx,theta{1}(idx,idx),theta{2}(idx,idx));
        
        % Alternative sol
        %[kx ky] = freqi(Wx{k});
        %theta = atan(ky ./ kx);
        %quiver(idx,idx,theta(idx,idx),theta(idx,idx));
        
    case 4 % Frequence x (k1)
        [k1 k2] = freqi(Wx{k});
        k = sqrt(k1^2+k2^2);
        imagesc(k,'Parent',handles.axes1);
        set(handles.axes1,'clim',[0 n*2]);
end