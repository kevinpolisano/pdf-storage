function testRiesz(num)
%TEST1 Teste la transformée de Riesz

N = 1024;
t = linspace(0,1,N);
dt = 1/N;

xx = ones(N,1)*t;
yy = t'*ones(1,N);

switch(num)
    case 1
        % Test 1 : AM/FM
        img = cos(2*pi*5*xx+2*cos(xx)+2*pi*5*yy+10*yy.^2);
        z = triesz(img,dt,1);
    case 2
        % Test 2 : isotropic wavelet
        tmp = exp(-800*((xx-0.5).^2+(yy-0.5).^2));
        img = del2(tmp)/dt^2;
        z = triesz(img,dt,2);
    case 3
        % Test 3 : cosinus
        img = cos(2*pi*(2*t'*ones(1,N)+5*ones(N,1)*t));
        z = triesz(img,dt,2);
    case 4
        % Test 4 : mono cosinus
        img = cos(2*pi*10*xx);
        z = triesz(img,dt,1);
    case 5
        % Test 5
        phi = 2*pi*((10+3*cos(2*pi*1.8*xx)).*xx+(15+3*yy.^2).*yy);
        ai = 1./(1+3*(xx-0.5).^2+(yy-0.5).^2);
        img = ai .* cos(phi);
        z = triesz(img,dt,1);
    case 6
        % Test 6 : image deùodulation
        img = ReadImage('Lenna');
        %imagesc(img);return;
        N = size(img,1);
        t = linspace(0,1,N);
        dt = 1/N;
        xx = ones(N,1)*t;
        yy = t'*ones(1,N);
        img = img .* cos(2*pi*80*(xx+3*yy));
        
        z = triesz(img,dt,0);
        
        figure();
        imagesc(img);
        colormap('gray');
        figure();
        imagesc(abs3(z));
        colormap('gray');
        myimwrite(img,'demod1.jpg');myimwrite(abs3(z),'demod2.jpg');
	case 7
        % Test 7 : image deùodulation with spherical wave
        img = ReadImage('Lenna');
        %imagesc(img);return;
        N = size(img,1);
        t = linspace(0,1,N);
        dt = 1/N;
        xx = ones(N,1)*t;
        yy = t'*ones(1,N);
        img = img .* cos(2*pi*(200-80*(sqrt((xx-0.3).^2+(yy-0.5).^2))));
        
        z = triesz(img,dt,0);
        
        figure();
        imagesc(img);
        colormap('gray');
        figure();
        imagesc(abs3(z));
        colormap('gray');
        myimwrite(img,'demod3.jpg');myimwrite(abs3(z),'demod4.jpg');
    case 8
        % Texture experiment
        img = double(imread('textures/reptil_skin.pgm'));
        z = triesz(img,dt,1);
        img = double(imread('textures/nuts.pgm'));
        z = triesz(img,dt,1);
        img = double(imread('textures/sawtooth.pgm'));
        z = triesz(img,dt,1);
        img = double(imread('textures/metal.pgm'));
        z = triesz(img,dt,1);
        img = double(imread('textures/checkerboard.pgm'));
        z = triesz(img,dt,1);
	case 9
        % demasking
        img = double(imread('textures/checkerboard.pgm'));
        N= size(img,1);
        t = linspace(0,1,N);
        dt = 1/N;
        xx = ones(N,1)*t;
        yy = t'*ones(1,N);
        amp = 1-0.99*exp(-0.5*(xx-0.5).^2-0.8*(yy-0.5).^2);
        z = triesz(amp.*img,dt,0);
        figure();image(amp.*img);colormap('gray');
        %figure();image(abs3(z));colormap('gray');
        figure();image(60*img.*amp./(1+abs3(z)));colormap('gray');
	case 10
        % demasking with grass photo
        img = double(imread('textures/Wood_Texture.jpg'));
        if length(size(img))>2
            img = 0.2989*img(:,:,1) + 0.5870*img(:,:,2) + 0.1140*img(:,:,3);
        end
        [n1 n2] = size(img);
        t1 = linspace(0,1,n1);
        t2 = linspace(0,1,n2);
        dt = 1/N;
        xx = ones(n1,1)*t2;
        yy = t1'*ones(1,n2);
        amp = 1-0.95*exp(-2*(xx-0.5).^2-1.5*(yy-0.5).^2);
        z = triesz(amp.*img,dt,0);
        myimwrite(amp.*img,'demod5.jpg');myimwrite(abs3(z),'demod6.jpg');myimwrite(img.*amp./(1+abs3(z)),'demod7.jpg');return;
        figure();imagesc(amp.*img);colormap('gray');
        %figure();image(abs3(z));colormap('gray');
        figure();imagesc(60*img.*amp./(1+abs3(z)));colormap('gray');
	case 11
	img = double(imread('Bonami.jpg'));
    if length(size(img))>2
            img = 0.2989*img(:,:,1) + 0.5870*img(:,:,2) + 0.1140*img(:,:,3);
        end
    size(img)
	z = triesz(img,dt,1);	
end

    

