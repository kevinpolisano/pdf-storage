function [kx ky] = freqi(z,zx,zy)
% function freqi : computes horizzontal and vertical instantaneous
% frequencies.

n = size(z{1},1);

if nargin<3
% Solution 1 : Differentiation of the phase. Simple but not stable.
[phi theta] = phase3(z);
kx = madiff2(phi,1/n,1);
ky = madiff2(phi,1/n,2);
kx = abs(kx)/2/pi;
ky = abs(ky)/2/pi;
return;
end

if 0
% Solution 2 : direct differentiation in Clifford algebra, real part
phi1 = z{1}.*madiff2(z{1},1/n,1)+z{2}.*madiff2(z{2},1/n,1)+z{3}.*madiff2(z{3},1/n,1);
kx = phi1 ./ abs3(z).^2;
phi2 = z{1}.*madiff2(z{1},1/n,2)+z{2}.*madiff2(z{2},1/n,2)+z{3}.*madiff2(z{3},1/n,2);
ky = phi2 ./ abs3(z).^2;

kx = 1/2/pi*abs(kx);
ky = 1/2/pi*abs(ky);

[phi theta] = phase3(z);
kx = kx .* tan(phi);

%disp(['kx : ' num2str(mean(kx(:)))]);disp(['ky : ' num2str(mean(ky(:)))]);
return;
end


% Solution 3 : differentiation in the Clifford algebra, modulus
% Does not seem to work well.
W1 = z{1};
W2 = z{2};
W3 = z{3};
W1p = zx{1};
W2p = zx{2};
W3p = zx{3};
%kx = (W1p .* W1 + W2p .* W2 + W3p .* W3).^2 + (W2p .* W1 - W1p .* W2).^2 + (W3p .* W1 - W1p .* W3).^2 + (W3p .* W2 - W2p .* W3).^2;
kx = sqrt((W2p.*W1-W1p.*W2).^2 + (W3p.*W1-W1p.*W3).^2);
kx = kx ./ abs3(z).^2;

W1p = zy{1};
W2p = zy{2};
W3p = zy{3};
%ky = (W1p .* W1 + W2p .* W2 + W3p .* W3).^2 + (W2p .* W1 - W1p .* W2).^2  + (W3p .* W1 - W1p .* W3).^2 + (W3p .* W2 - W2p .* W3).^2;
ky = sqrt((W2p.*W1-W1p.*W2).^2 + (W3p.*W1-W1p.*W3).^2);
ky = ky ./ abs3(z).^2;

kx = kx/(2*pi);
ky = ky/(2*pi);

%disp(['kx : ' num2str(mean(kx(:)))]);disp(['ky : ' num2str(mean(ky(:)))]);

% Solution 4 : with regularization a la Unser. Not implemented yet

