function [fi e] = brevridge(Txx, lambda, nfi, clwin)

na = length(Txx);
n = size(Txx{1}{1},1);

% Fixed parameters
iborder = n/8;
nbtry = 50;
jmax = 8;

% Other variables
center = round(linspace(iborder+1,n-iborder,nbtry));
fi = cell(nfi,1);

% Building 3D array
Tx = zeros(n,n,na);
for k=1:na
    Tx(:,:,k) = abs3(Txx{k});
end
%Tx = log(abs(Tx)+eps^0.25);


% 
% % Borders are zeros
% %Tx(1:iborder,:,:)=0;Tx(:,1:iborder,:)=0;Tx(iborder+1:n,:,:)=0;Tx(:,iborder+1:n,:)=0;
% 
% 
% % Filtererd version of Tx for initialization
Tfilt = Tx;
% noy = [1 2 1]'*[1 2 1]/16;
% for k=1:na
%     for l=1:0
%         Tfilt(:,:,k) = conv2(Tfilt(:,:,k),noy,'same');
%     end
% end
% 
% if 0
% %% Simple naive method
% for ncomp=1:nfi
%     % for each mode
%     c = zeros(n,n);
%     for k1=1:n
%         for k2=1:n
%             [v idx] = max(Tfilt(k1,k2,15:na-15));
%             c(k1,k2) = idx+14;
%         end
%     end
%     
%     fi{ncomp} = c;
%     for kx=1:n
%         for ky=1:n
%             Tfilt(kx,ky,max(1,c(kx,ky)-clwin):min(na,c(kx,ky)+clwin)) = 0;
%         end
%     end
%     
% end
% e=0;
% return;
% end
% %figure();colormap('gray');
% %for k=1:na
% %    imagesc(Tx(:,:,k));pause;
% %end
%% Less naive
for ncomp=1:nfi
    % for each mode
    
    c = zeros(n,n);
    ccur = zeros(n,n); % current mode
    e = -Inf;
    
    for kk = 1:nbtry
        k = center(kk);
        % Find a Tx{a}(k,k) max
        [etmp kz] = max(Tfilt(k,k,:));
        ccur(k,k) = kz;
        idx1 = kz;
        
        % Step forward
        for kx=k:n-iborder
            [v tmp] = max(Tx(kx,k,max(1,idx1-jmax):min(na,idx1+jmax)));
            idx1 = tmp + max(1,idx1-jmax)-1;
            idx = idx1;
            etmp = etmp+v;
            ccur(kx,k) = idx;
            % y forward
            for ky=k+1:n-iborder
                [v tmp] = max(Tx(kx,ky,max(1,idx-jmax):min(na,idx+jmax)));
                idx = tmp + max(1,idx-jmax)-1;
                etmp = etmp+v;
                ccur(kx,ky) = idx;
            end
            idx = idx1;
            % y backward
            for ky=k-1:(-1):iborder+1
                [v tmp] = max(Tx(kx,ky,max(1,idx-jmax):min(na,idx+jmax)));
                idx = tmp + max(1,idx-jmax)-1;
                etmp = etmp+v;
                ccur(kx,ky) = idx;
            end
        end
            
        % Step backward
        idx1 = kz;
        for kx=k-1:(-1):iborder+1
            [v tmp] = max(Tx(kx,k,max(1,idx1-jmax):min(na,idx1+jmax)));
            idx1 = tmp + max(1,idx1-jmax)-1;
            idx = idx1;
            etmp = etmp+v;
            ccur(kx,k) = idx;
            % y forward
            for ky=k+1:n-iborder
                [v tmp] = max(Tx(kx,ky,max(1,idx-jmax):min(na,idx+jmax)));
                idx = tmp + max(1,idx-jmax)-1;
                etmp = etmp+v;
                ccur(kx,ky) = idx;
            end
            idx = idx1;
            % y backward
            for ky=k-1:(-1):iborder+1
                [v tmp] = max(Tx(kx,ky,max(1,idx-jmax):min(na,idx+jmax)));
                idx = tmp + max(1,idx-jmax)-1;
                etmp = etmp+v;
                ccur(kx,ky) = idx;
            end
        end
        
        if etmp>e
            e = etmp;
            c = ccur;
        end
    end
    
    fi{ncomp} = c;
    for kx=1:n
        for ky=1:n
            Tx(kx,ky,max(1,c(kx,ky)-clwin):min(na,c(kx,ky)+clwin)) = 0;
        end
    end
    
end
                
    
    
    
    

