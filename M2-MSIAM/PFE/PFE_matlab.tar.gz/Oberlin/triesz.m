function z = triesz(f,dt,doplot)
%TRIESZ computes and plots the Riesz transform of a 2D signal.
% f is a matrix
% dt a time period
% doplot a flag for plotting a figure with f, its instantaneous frequency, amplitude, phase etc
if nargin<3
    doplot = 0;
end
if nargin<2
    dt=1;
end

[n1 n2] = size(f);

% Centering the image f on the origin and discretization
xi1 = linspace(-n1/2,n1/2,n1);
xi2 = linspace(-n2/2,n2/2,n2);
% Norm of all point (xi1,xi2) 
nxi = sqrt((xi1'*ones(1,n2)).^2+(ones(n1,1)*xi2).^2);
nxi(abs(nxi)<0.0001)=0.0001;

% Compute the Fourier transform of f
ft = fftshift(fft2(f));

z = cell(3); % the monogenic signal Mf = (f,Rf1,Rf2) = (z1,z2,z3)

z{1} = f;

% TF{Rf1}(w) = -i*(wx/|w|)*TF(f) 
z{2} = -ifft2(ifftshift(1i*xi1'*ones(1,n2) ./ nxi .*ft));
% TF{Rf2}(w) = -i*(wy/|w|)*TF(f)
z{3} = -ifft2(ifftshift(1i*ones(n1,1)*xi2 ./ nxi .*ft));
z{1} = real(z{1});z{2} = real(z{2});z{3} = real(z{3});
%z{1} = imag(z{1});z{2} = imag(z{2});z{3} = imag(z{3});

idx1 = 50:floor(n1/30):n1-50;
idx2 = 50:floor(n2/30):n2-50;


if doplot
    if doplot==2
        % 1D plot (a slice corresponding to line x = 0)
        figure();plot(f(n1/2,:));hold on;
        plot(z{2}(n1/2,:),'r');
        plot(z{3}(n1/2,:),'k');    
        nn = abs3(z);
        plot(real(nn(n1/2,:)),'b--');
        legend('f','R1f','R2f','Modulus');
    
        % 3D plot
        figure();
        surf(z{1},'EdgeColor','none');pause;
        figure();
        surf(z{2},'EdgeColor','none');pause;
        figure();
        surf(z{2},'EdgeColor','none');pause;
    end
    
    
    % 2D plot
    [phi theta] = phase3(z);
    
    zx = {madiff2(z{1},dt,1),madiff2(z{2},dt,1),madiff2(z{3},dt,1)}
    zy = {madiff2(z{1},dt,2),madiff2(z{2},dt,2),madiff2(z{3},dt,2)}
    
    [kx ky] = freqi(z,zx,zy);
    
    figure();colormap('gray');
    subplot(2,3,1);imagesc(real(f));title('Signal f');set(gca,'clim',[0 1.2*max(f(:))]);
    subplot(2,3,2);imagesc(abs(kx));title('Horizontal frequency kx');set(gca,'clim',mean(abs(kx(:)))*[0.6 1.5]);
    subplot(2,3,3);imagesc(abs(ky));title('Vertical  frequency ky');set(gca,'clim',mean(abs(ky(:)))*[0.6 1.5]);
    subplot(2,3,4);imagesc(abs3(z));title('Amplitude');set(gca,'clim',[0 1.2*max(max(abs3(z)))]);
    subplot(2,3,5);imagesc(abs(phi));title('Phase phi');
    %figure();quiver(1:n1,1:n2,theta{1},theta{2});title('Orientation theta');   
    subplot(2,3,6);quiver(idx1,idx1,theta{1}(idx1,idx2),theta{2}(idx1,idx2));title('Orientation theta');    


    figure();imagesc(real(f));title('Signal f');set(gca,'clim',[0 1.2*max(f(:))]);colormap('gray');xlabel('x');ylabel('y');set(gca,'xtick',[],'ytick',[]);
    figure();imagesc(abs(kx));title('Horizontal frequency |kx|');set(gca,'clim',mean(abs(kx(:)))*[0 1.2]);colormap('gray');xlabel('x');ylabel('y');set(gca,'xtick',[],'ytick',[]);
    figure();imagesc(abs(ky));title('Vertical  frequency |ky|');set(gca,'clim',mean(abs(ky(:)))*[0 1.5]);colormap('gray');xlabel('x');ylabel('y');set(gca,'xtick',[],'ytick',[]);
    figure();imagesc(abs3(z));title('Amplitude');set(gca,'clim',[0 1.2*max(max(abs3(z)))]);xlabel('x');ylabel('y');set(gca,'xtick',[],'ytick',[]);colorbar();
    figure();imagesc(abs(phi));title('Phase phi');colormap('gray');xlabel('x');ylabel('y');set(gca,'xtick',[],'ytick',[]);
    %figure();quiver(idx1,idx1,theta{1}(idx1,idx2),theta{2}(idx1,idx2));title('Orientation theta');    
    figure();quiver(idx1,idx1,kx(idx1,idx2),ky(idx1,idx2));title('Orientation theta');  
    xlabel('x');ylabel('y');set(gca,'xtick',[],'ytick',[]);
    
    set(findall(0,'type','text'),'Fontsize',15);
    set(findall(0,'type','axes'),'Fontsize',15);
    
    



end

