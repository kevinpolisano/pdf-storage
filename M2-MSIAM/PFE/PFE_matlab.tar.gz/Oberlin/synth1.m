function frec =  synth1(Tx,mywav,nv,c,clwin)

n = size(Tx{1}{1},1);
na = length(Tx);

frec = zeros(n,n);

for k=1:na
    idx = find(c==k);
    for kk=max(1,k-clwin):min(na,k+clwin)
        frec(idx) = frec(idx) + Tx{kk}{1}(idx);
    end
end

% Calcul de CPsi
if strncmp(mywav,'gmor',4)
    [v1 v2] = regexp(mywav,'[0-9]*-[0-9]');
    beta = str2num(mywav(v1:v2-2));
    gamma = str2num(mywav(v2:end));
    PsiMor=@(x) 0.5*gmor2(beta,gamma,x)./x;
    CPsi = quadgk(@(x)PsiMor(x),eps,(beta/gamma)^(1/gamma)+2*sqrt(gamma*beta));  
elseif strncmp(mywav,'cmor',4)
    [v1 v2] = regexp(mywav,'[0-9]*-[0-9]');
    Fb = str2num(mywav(v1:v2-2));
    Fc = str2num(mywav(v2:end));
    PsiMor=@(x) 0.5*cmor2(Fb,Fc,x)./x;
    CPsi = quadgk(@(x)PsiMor(x),0,inf);  
elseif strncmp(mywav,'bump',4)
    [v1 v2] = regexp(mywav,'[0-9]*-[0-9]');
    mu = str2num(mywav(v1:v2-2));
    sigma = str2num(mywav(v2:end));
    PsiMor=@(x) 0.5*bump2(mu,sigma,x)./x;
    CPsi = quadgk(@(x)PsiMor(x),0,inf);  
end 

% Somme pondérée de Tx;
frec = frec /real(CPsi)/2;
frec = frec/nv*log(2);

