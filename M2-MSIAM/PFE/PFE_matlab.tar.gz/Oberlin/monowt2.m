function Wx = monowt2(s,as,mywav)
% monowt2 : computes the 2D continuous monogenic wavelet transform of an image
%
% Inputs :
%   s : square image, size power of 2
%   as : vector of scales
%   mywav : string name of the wavelet
% Output
%   Wx : na-cell of matrix of wavelet coefficients. Wx{a}{l}(b) : coefficient at scale
%   as(a) and time b=(b1,b2) of dimension l (l=1, 2 or 3).

n = size(s,1);
na = length(as);

z = triesz(s);

% symmetric padding of each component
[N x1 n1] = mypad2(z{1});
[N x2 n1] = mypad2(z{2});
[N x3 n1] = mypad2(z{3});

% Frequency vector : fftshift
xi1 = 2*ones(N,1)*(-N/2+1:N/2)/n;
xi2 = xi1';
xi = xi1.^2 + xi2.^2;
xi = sqrt(xi);

% Initialization
Wx = cell(na);
xh1 = fftshift(fft2(x1));
xh2 = fftshift(fft2(x2));
xh3 = fftshift(fft2(x3));

% Filter definition
if strncmp(mywav,'gmor',4)
    [v1 v2] = regexp(mywav,'[0-9]*-[0-9]');
    beta = str2num(mywav(v1:v2-2));
    gamma = str2num(mywav(v2:end));
    filt = @(a) gmor2(beta,gamma,a*xi);
elseif strncmp(mywav,'cmor',4)
    [v1 v2] = regexp(mywav,'[0-9]*-[0-9]');
    Fb = str2num(mywav(v1:v2-2));
    Fc= str2num(mywav(v2:end));
    filt = @(a) cmor2(Fb,Fc,a*xi);
elseif strncmp(mywav,'bump',4)
    [v1 v2] = regexp(mywav,'[0-9]*-[0-9]');
    mu = str2num(mywav(v1:v2-2));
    sigma= str2num(mywav(v2:end));
    filt = @(a) bump2(mu,sigma,a*xi);
end

% for each octave
for ai = 1:na
 	a = as(ai);
    psih = conj(filt(a));
    tmp1 = real(ifft2(ifftshift(psih .* xh1)));
    tmp2 = real(ifft2(ifftshift(psih .* xh2)));
    tmp3 = real(ifft2(ifftshift(psih .* xh3)));
    Wx{ai} = {tmp1(n1+1:n1+n,n1+1:n1+n), tmp2(n1+1:n1+n,n1+1:n1+n), tmp3(n1+1:n1+n,n1+1:n1+n)};
end


end 
