function realimg()
%REALIMG 

% Signal

fp = myread('fp/7_6.bmp');
fp = fp - mean(fp(:));
N = size(fp,1);

fpnoise = fp .* (1+0.5*randn(N,N));
tx=linspace(-1,1,N)'*ones(1,N);
ty=ones(N,1)*linspace(-1,1,N);
fpoc = fp.*exp(-15*(tx.^2+ty.^2));
index = 2*N/8+1:7*N/8;
figure();imagesc(fp);colormap('gray'); formfig();set(gca,'clim',[-120 120]);
figure();imagesc(fpnoise);colormap('gray'); formfig();set(gca,'clim',[-120 120]);
figure();imagesc(fpoc);colormap('gray'); formfig();set(gca,'clim',[-120 120]);

%return;

%return;

nv = 16; % Nb coef par octave
gamma = 0.05; % Seuil
clwin = 8;
myw = 'cmor4-1';
maxna = log2(N)-1;
as = 2.^(0:(1/nv):maxna);

% Synchrosqueezing step
[fs Wx Tx] = monosq2(fp,nv,as,gamma,myw);

% Extraction of ridge
if 0
for clwin = 1:10
[fi e] = brevridge(Tx, 0.001, 1, clwin);
c = fi{1};
frec =  synth1(Tx,myw,nv,c,clwin);
disp(['CLWIN = ' num2str(clwin) ', MSE = ' num2str(norm(frec(index,index)-osc(N/8+1:7*N/8,N/8+1:7*N/8))/norm(osc(N/8+1:7*N/8,N/8+1:7*N/8)))]);
end
end

clwin = 8;
[fi e] = brevridge(Tx, 1000, 1, clwin);
c = fi{1};
recfp =  synth1(Tx,myw,nv,c,clwin);

% Synchrosqueezing step
[fs Wx Tx] = monosq2(fpnoise,nv,as,gamma,myw);

clwin = 8;
[fi e] = brevridge(Tx, 1000, 1, clwin);
c = fi{1};
recfpn =  synth1(Tx,myw,nv,c,clwin);


% Synchrosqueezing step
[fs Wx Tx] = monosq2(fpoc,nv,as,gamma,myw);

clwin = 8;
[fi e] = brevridge(Tx, 1000, 1, clwin);
c = fi{1};
recfpoc =  synth1(Tx,myw,nv,c,clwin);


% Display
figure();imagesc(recfp);colormap('gray'); formfig();set(gca,'clim',[-120 120]);

figure();imagesc(recfpn);colormap('gray'); formfig();set(gca,'clim',[-120 120]);
disp(['MSE = ' num2str(norm(recfpn(index,index)-fp(index,index))/norm(fp(index,index)))]);

figure();imagesc(recfpoc);colormap('gray'); formfig();set(gca,'clim',[-120 120]);
disp(['MSE = ' num2str(norm(recfpoc(index,index)-fp(index,index))/norm(fp(index,index)))]);




function formfig()
xlabel('x');
ylabel('y');
colormap('gray');
set(gca,'XTick',[],'YTick',[]);
set(gca,'Fontsize',12);
set(findall(0,'type','text'),'Fontsize',12);



