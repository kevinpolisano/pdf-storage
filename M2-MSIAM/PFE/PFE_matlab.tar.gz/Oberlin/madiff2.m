function w = madiff2(W,dt,dir)

if 1
%% Order 1
if dir==1
    Wr = [W(:,end) W];
    w = Wr(:,2:end)-Wr(:,1:end-1);
    w = w / (dt);
    %figure();plot(w(100,:));
elseif dir==2
    Wr = [W(end,:); W;];
    w = Wr(2:end,:)-Wr(1:end-1,:);
    w = w / (dt);
    %figure();plot(w(:,100));
else
    error('Bad argument dir : must be 1 or 2');
end
return;
end

%% Order 4
if dir==1
    Wr = [W(:, end-1:end) W W(:, 1:2)];
    w = -Wr(:, 5:end);
    w = w + 8*Wr(:, 4:end-1);
    w = w - 8*Wr(:, 2:end-3);
    w = w + Wr(:, 1:end-4);
    w = w / (12*dt);
elseif dir==2
    Wr = [W(end-1:end,:); W; W(1:2,:)];
    Wr = unwrap(Wr,1,2);
    w = -Wr(5:end,:);
    w = w + 8*Wr(4:end-1,:);
    w = w - 8*Wr(2:end-3,:);
    w = w + Wr(1:end-4,:);
    w = w / (12*dt);
else
    error('Bad argument dir : must be 1 or 2');
end