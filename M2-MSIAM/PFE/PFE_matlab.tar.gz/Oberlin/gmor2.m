function psih = gmor2(beta,gamma,xi)
% gmor : the generalized Morse wavelet in Fourier domain
    psih = (exp(1)*gamma/beta)^(beta/gamma) * xi.^(beta) .* exp(-xi.^gamma); % Linf normalized
    psih(xi<0)=0;
end