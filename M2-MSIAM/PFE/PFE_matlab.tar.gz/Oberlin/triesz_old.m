function z = triesz(f,dt,doplot)
%TRIESZ computes and plots the Riesz transform of a 2D signal.

if nargin<3
    doplot = 0;
end
if nargin<2
    dt=1;
end

[n1 n2] = size(f);

xi1 = linspace(-n1/2,n1/2,n1);
xi2 = linspace(-n2/2,n2/2,n2);
nxi = sqrt((xi1'*ones(1,n2)).^2+(ones(n1,1)*xi2).^2);
nxi(abs(nxi)<0.0001)=0.0001;

ft = fftshift(fft2(f));

z = cell(3);

z{1} = f;
z{2} = -ifft2(ifftshift(1i*xi1'*ones(1,n2) ./ nxi .*ft));
z{3} = -ifft2(ifftshift(1i*ones(n1,1)*xi2 ./ nxi .*ft));
z{1} = real(z{1});z{2} = real(z{2});z{3} = real(z{3});
%z{1} = imag(z{1});z{2} = imag(z{2});z{3} = imag(z{3});

idx1 = 1:floor(n1/15):n1;
idx2 = 1:floor(n2/15):n2;


if doplot
    if doplot==2
        % 1D plot
        figure();plot(f(n1/2,:));hold on;
        plot(z{2}(n1/2,:),'r');
        plot(z{3}(n1/2,:),'k');    
        nn = abs3(z);
        plot(real(nn(n1/2,:)),'b--');
        legend('f','R1f','R2f','Modulus');
    
        % 3D plot
        figure();
        surf(z{1},'EdgeColor','none');pause;
        surf(z{2},'EdgeColor','none');pause;
        surf(z{2},'EdgeColor','none');pause;
    end
    
    
    % 2D plot
    [phi theta] = phase3(z);
    
    kx = madiff2(phi,dt,1);
    ky = madiff2(phi,dt,2);
    
    figure();colormap('gray');
    subplot(2,3,1);imagesc(real(f));title('Signal f');set(gca,'clim',[0 1.2*max(f(:))]);
    subplot(2,3,2);imagesc(abs(kx));title('Horizontal frequency kx');set(gca,'clim',mean(abs(kx(:)))*[0.6 1.5]);
    subplot(2,3,3);imagesc(abs(ky));title('Vertical  frequency ky');set(gca,'clim',mean(abs(ky(:)))*[0.6 1.5]);
    subplot(2,3,4);imagesc(abs3(z));title('Amplitude');set(gca,'clim',[0 1.2*max(max(abs3(z)))]);
    subplot(2,3,5);imagesc(abs(phi));title('Phase phi');
    %figure();quiver(1:n1,1:n2,theta{1},theta{2});title('Orientation theta');   
    subplot(2,3,6);quiver(idx1,idx1,theta{1}(idx1,idx2),theta{2}(idx1,idx2));title('Orientation theta');    
end

