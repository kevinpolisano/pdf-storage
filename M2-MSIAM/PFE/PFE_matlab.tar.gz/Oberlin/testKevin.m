function testKevin(I)


% Parameters
nv = 16; % Nb coef par octave
gamma = 0.05; % Seuil
clwin=7;
myw = 'cmor4-1';
%img = myread('Bonami.jpg');
img = I;

N = size(img,1);
maxna = log2(N)-1;
as = 2.^(0:(1/nv):maxna);

% Riesz transform and componentwise wavelet transform
Wx = monowt2(img,as,myw);

% For each octave we compute the histogram of orientations
k = 30;
n = size(Wx{1}{1},1);
idx = 1:(1+floor(n/30)):n;
[phi theta] = phase3(Wx{k});
quiver(idx,idx,theta{1}(idx,idx),theta{2}(idx,idx));
orientation = zeros(n,n);
for i=1:n
    for j=1:n
        orientation(i,j) = atan(theta{2}(i,j)/theta{1}(i,j));
    end
end
orientation
figure;
imagesc(orientation);
colormap HSV;
colorbar('location','eastoutside');
[his,xout] = hist(orientation(:),50);
[C I] = max(his);
anglemaxfq = (xout(I)+xout(I+1))/2
pi/4
figure;
bar(xout,his)
hold on
plot([anglemaxfq anglemaxfq],[0 C],'--r','LineWidth',2)

% Display results
%disp3D(as,Wx,1);return;
%monodisp(as,Wx);
return; % 2D

% Synchrosqueezing step
[fs Wx Tx] = monosq2(img,nv,as,gamma,myw);


% Extraction of ridge
[fi e] = brevridge(Tx, 0.001, 3, clwin);

res = img;
index = N/8+1:7*N/8;
for l=1:length(fi)
    c = fi{l};
    frec =  synth1(Tx,myw,nv,c,clwin);
    figure();imagesc(frec(index,index));colormap('gray');title(['Mode ' num2str(l)]);
    res = res - frec;
    figure();imagesc(res(index,index));colormap('gray');title(['Residual ' num2str(l)]);
end

figure(); imagesc(img);colormap('gray');

%% Face reconstruction
%c(c<20)=NaN;figure();surf(-c);set(findall(gca,'type','surf'),'edgecolor','none');colormap('gray');
 
%return;

% Display results
disp3D(as,Tx,2);
monodisp(fs,Tx);

end

