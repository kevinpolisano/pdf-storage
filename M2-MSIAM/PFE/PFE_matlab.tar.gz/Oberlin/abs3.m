function res = abs3(z)
res = sqrt(abs(z{1}).^2+abs(z{2}).^2+abs(z{3}).^2);
