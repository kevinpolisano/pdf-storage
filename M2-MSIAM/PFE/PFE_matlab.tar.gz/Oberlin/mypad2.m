function [N x n1] = mypad2(s)
% mypad : symmetric padding of vector s.

n = length(s);

% Computing the power of 2
N = 2^(1+round(log2(n+eps)));
n1 = floor((N-n)/2);

% Padding
padtype = 'symmetric';
try
    x = padarray(s,[n1 n1],padtype);
catch
    warning('Image processing Toolbox is not working. Using constant pading');
    sleft = [s(1,1)*ones(n1,n1);s(:,1)*ones(1,n1);s(n,1)*ones(n1,n1)];
    sright = [s(1,n)*ones(n1,n1);s(:,n)*ones(1,n1);s(n,n)*ones(n1,n1)];
    stp = ones(n1,1)*s(1,:);
    sbot = ones(n1,1)*s(n,:);
    x = [sleft [stp;s;sbot] sright];
end

