% ------------------------------------------------------------------------
%
% Author : Kevin Polisano
% Email  : kevin.polisano@ensimag.fr
% Adress : LJK Grenoble
%
% Input :
%         I : the matrix (image) which we want to analyze profiles
%       Tab : the angles of turning bands and their real Hurst exponent
%
%  This GUI enables to visualize 1D profiles and Radon transform of the 
%  image I in the direction defined by the angles contained in Tab,
%  and to estimate their Hurst exponent.
%
%  Main function : computeProfile (on the bottom of this file)
%  Others functions are used by the GUI
%
%-------------------------------------------------------------------------

function varargout = analyseProfile(varargin)
% ANALYSEPROFILE MATLAB code for analyseProfile.fig
%      ANALYSEPROFILE, by itself, creates a new ANALYSEPROFILE or raises the existing
%      singleton*.
%
%      H = ANALYSEPROFILE returns the handle to a new ANALYSEPROFILE or the handle to
%      the existing singleton*.
%
%      ANALYSEPROFILE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ANALYSEPROFILE.M with the given input arguments.
%
%      ANALYSEPROFILE('Property','Value',...) creates a new ANALYSEPROFILE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before analyseProfile_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to analyseProfile_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help analyseProfile

% Last Modified by GUIDE v2.5 12-Jun-2013 15:54:17

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @analyseProfile_OpeningFcn, ...
                   'gui_OutputFcn',  @analyseProfile_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before analyseProfile is made visible.
function analyseProfile_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to analyseProfile (see VARARGIN)

% Choose default command line output for analyseProfile
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
I = varargin{1};
Tab = varargin{2};
setappdata(handles.figure1,'I',I);
setappdata(handles.figure1,'Tab',Tab);
setappdata(handles.figure1,'k',1);
setappdata(handles.figure1,'s',size(Tab,2));
set(handles.slider1,'Min',1,'Max',size(Tab,2),'Value',1,'SliderStep',[1 1]/(size(Tab,2)-1));

colormap(handles.axes1,gray);
imagesc(I,'Parent',handles.axes1);

theta = Tab(1,1);
[xi yi C Hest R HRest] = computeProfile(I,theta);
% Plot axes 1
hold(handles.axes1,'on');
colormap(handles.axes1,gray);
imagesc(I,'Parent',handles.axes1);
plot(handles.axes1,xi,yi,'r');
title(handles.axes1,'Texture image');
hold(handles.axes1,'off');
% Plot axes 2
plot(handles.axes2,1:length(C),C,'r');
xlabel(handles.axes2,'lateral distance [px]');
ylabel(handles.axes2,'intensity');
title(handles.axes2,'profile');
% Plot axes 3
plot(handles.axes3,1:length(R),R,'b');
xlabel(handles.axes3,'s');
ylabel(handles.axes3,'TR[theta](s)');
title(handles.axes3,'Radon transform in the direction theta');
% Edit1
set(handles.edit1,'String',num2str(Hest));
% Edit2
set(handles.edit2,'String',num2str(HRest));
% Edit 3
set(handles.edit3,'String','1');
% Edit 5
set(handles.edit5,'String',num2str(Tab(2,1)));
% Edit 6
set(handles.edit6,'String',num2str(min(Tab(2,:))));

% TAB ANGLE VS H EST
HestTab = zeros(1,size(Tab,2));
HRestTab = zeros(1,size(Tab,2));
for i=1:size(Tab,2)
    [xi yi C Hest R HRest] = computeProfile(I,Tab(1,i));
    HestTab(i) = Hest;
    HRestTab(i) = HRest;
end;
setappdata(handles.figure1,'HestTab',HestTab);
setappdata(handles.figure1,'HRestTab',HRestTab);


% UIWAIT makes analyseProfile wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = analyseProfile_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
k = get(hObject,'Value');
I = getappdata(handles.figure1,'I');
Tab = getappdata(handles.figure1,'Tab');
theta = Tab(1,k);
h = Tab(2,k);
[xi yi C Hest R HRest] = computeProfile(I,theta);
% Plot axes 1
hold(handles.axes1,'on');
colormap(handles.axes1,gray);
imagesc(I,'Parent',handles.axes1);
plot(handles.axes1,xi,yi,'r');
title(handles.axes1,'Texture image');
hold(handles.axes1,'off');
% Plot axes 2
plot(handles.axes2,1:length(C),C,'r');
xlabel(handles.axes2,'lateral distance [px]');
ylabel(handles.axes2,'intensity');
title(handles.axes2,'profile');
% Plot axes 3
plot(handles.axes3,1:length(R),R,'b');
xlabel(handles.axes3,'s');
ylabel(handles.axes3,'TR[theta](s)');
title(handles.axes3,'Radon transform in the direction theta');
% Edit1
set(handles.edit1,'String',num2str(Hest));
% Edit2
set(handles.edit2,'String',num2str(HRest));
% Edit 3
set(handles.edit3,'String',num2str(k));
% Edit 5
set(handles.edit5,'String',num2str(h));






% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%--------------------------------------------------------------------------
% The main function
% Given an image I and a direction theta
% Compute the line (xi,yi) defined by y=tan(theta)x
%         the profile C of the image I along this line (xi,yi)
%         the Radon transform R of the Image I in the direction theta
%         the Hurst exponents of these two 1D signal
%             - Hest for the signal C estimated by quadric variations
%             - HRest for the signal R estimated by wavelets
%--------------------------------------------------------------------------
function [xi,yi,C,Hest,R,HRest] = computeProfile(I,theta)
  
if (abs(theta) == pi/2)
    theta = theta+0.01;
end

a = tan(theta); % slop of the line
r = size(I,1);  % size of the image (aimed square)

if a>1
    x0 = floor((a-1)*r/(2*a)+1);
    xn = floor((a+1)*r/(2*a));
elseif a<-1
    x0 = floor((a+1)*r/(2*a)+1);
    xn = floor((a-1)*r/(2*a));
else 
    x0 = 1;
    xn = r;
end;

% we define the segment intersection between the image I and y=tan(theta)x
xi = x0:1:xn;         
yi = a*xi+(1-a)*r/2;

% the linescan are points (cx,cy) with intensity C
[cx,cy,C] = improfile(I,xi,yi);    % STRANGE there is a NaN !
%[h_minnoint,h_min,h_minL,h_max] = demo_MF_BS_tool(C')

% Hurst index estimation of the linescan
Hest = VaPkolST(C,2,[1 -2 1],5);
%Hest = h_max;% VaPkstST(C,size(C,1),2,[1 -1])

% Radon transform for the angle theta
R = radon(I,theta);
R(R==0) = []; % to delete zeros
%[h_minnoint,h_min,h_minL,h_max] = demo_MF_BS_tool(R');7
HRest = VaPkolST(R,2,[1 -2 1],5)-0.5;
%HRest = h_min-0.5; % VaPkstST(R,size(R,1),2,[1 -1]);



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
HestTab = getappdata(handles.figure1,'HestTab');
HRestTab = getappdata(handles.figure1,'HRestTab');
Tab = getappdata(handles.figure1,'Tab');
figure;
plot(Tab(1,:),HestTab,'r');
hold on;
meanHest = nanmean(HestTab);
plot([-pi/2 pi/2],[meanHest meanHest],'r');
plot(Tab(1,:),HRestTab,'b');
hold off;


% --------------------------------------------------------------------
function uipushtool1_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to uipushtool1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
im_Text = getframe(handles.axes1);
image(im_Text.cdata);
im_Prof = getframe(handles.axes2);
image(im_Prof.cdata);
im_ProfRad = getframe(handles.axes3);
image(im_ProfRad.cdata);
k = getappdata(handles.figure1,'k');
nameText = strcat('Images/Coupe_',num2str(k),'.jpg');
nameProf = strcat('Images/Profile_',num2str(k),'.jpg');
nameProfRad = strcat('Images/ProfileRadon_',num2str(k),'.jpg');
imwrite(im_Text.cdata,nameText);
imwrite(im_Prof.cdata,nameProf);
imwrite(im_ProfRad.cdata,nameProfRad);
