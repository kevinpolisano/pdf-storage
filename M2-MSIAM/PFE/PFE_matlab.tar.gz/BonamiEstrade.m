% ------------------------------------------------------------------------
%
% Author : Kevin Polisano
% Email  : kevin.polisano@ensimag.fr
% Adress : LJK Grenoble
%
%        SIMULATION OF THE BONAMI ESTRADE MODEL BY TURNING BANDS
%
% References : 
% - Bonami & Estrade, Anisotropic analysis of some Gaussian models, 2003
% - Bierme, Moisan & Richard, A turning-band method for the simulation
%   of anisotropic fractional brownian fields, 2012
%
% Input :
%             r             : resolution parameter (sampling step = 1/r)
%             alpha1,alpha2 : the considered angular interval
%             epsilon       : the maximum angular distance between
%                             two adjacent bands
%             method [opt]  : use naive method                         (0) 
%                             or by default dynamic programming method (1)
%
% Output :   
%             afBf, a 2D anisotropic fractional Brownian field of size rxr
%             Tab, the angles of turning bands and their Hurst exponent
%
% ------------------------------------------------------------------------
function [afBf,Tab] = BonamiEstrade(r,alpha1,alpha2,epsilon,Params)

%--------------------%
% Parameters control %
%--------------------%

if (nargin == 5)           % parameters used to define function h or c
    method = Params(1);    % naive or dynamic programming method
    mu1 = Params(2);       % first constant 
    mu2 = Params(3);       % second constant 
    dir1 = Params(4);      % first direction
    dir2 = Params(5);      % second direction
    Hc = Params(6);        % global constant
    choiceG = Params(7);   % choice of the type of function used for h or c
    anisoHC = Params(8);   % anisotropy introduces by h or c
elseif (nargin < 5)
    choiceG = 0;
    method = 1;
    mu1 = 0.5;
    mu2 = 1;
    dir1 = 0;
    dir2 = 0;
    Hc = 0.5;
    anisoHC = 0;
elseif (nargin < 4)
    epsilon = 0.03;
elseif (nargin < 2)
    alpha1 = -pi/2;
    alpha2 = pi/2;
elseif (nargin < 1) || (nargin > 5)
    disp 'Number of arguments invalid';
    return;
end

%---------------%
% naive methode %
%---------------%

if (method == 0)
    s = floor((alpha2-alpha1)/epsilon);
    % Initialization of equiangular angles
    theta=zeros(1,s+2);
    for i=1:s+2
        theta(i)=alpha1+(i-1)/(s+1)*(alpha2-alpha1);
    end

    % Approximation of tan(theta_i) by continuous fractions 
    p = zeros(1,s);
    q = zeros(1,s);
    maxlength = 0;
    for i=1:s
        [p(i) q(i)] = rat(tan(theta(i+1)));
        if (abs(p(i))+q(i) > maxlength)
           maxlength = abs(p(i))+q(i);
        end
    end
end

%----------------------------%
% Dynamic Programming method %
%----------------------------%

if (method == 1)
   % pre-computation of bands which minimize the cost of simulation
   [p q] = chooseBands(r,alpha1,alpha2,epsilon);
   s = size(p,2);           % number of bands
   theta = zeros(1,s+2);    % the angle of the turning bands
   theta(1)=alpha1;         % we add by convention the extreme angles
   theta(s+2)=alpha2;
   maxlength = 0;           % used to store the s fBm of length r(|pi|+qi)
   for i=1:s
       theta(i+1) = atan(p(i)/q(i));
        if (abs(p(i))+q(i) > maxlength)
       maxlength = abs(p(i))+q(i);
        end
   end
end

%------------------------------------%
% Definition of the others functions %
%------------------------------------%

% Initialization of lambda_i
lambda=zeros(1,s);
lambda(1)=theta(3)-theta(1);
for i=2:s
    lambda(i)=theta(i+2)-theta(i+1);
end

% Definition of the Hurst function h(theta_i)
h = zeros(1,s);
if (anisoHC == 1)
    for i=1:s
        h(i) = Hc;
    end
elseif (anisoHC == 0)
    switch(choiceG)
        case 0 % h = constante
            for i=1:s
                h(i) = Hc;
            end
        case 1 % h = mu1 in the sector (dir1,dir2) and h = mu2 outside
            for i=1:s
                h(i) = g1(theta(i+1),dir1,dir2,mu1,mu2);
            end
        case 2 % h linear [-pi/2,dir1]->[mu2,mu1] and linear [dir1,pi/2]->[mu1,mu2]
            for i=1:s
                h(i) = g2(theta(i+1),dir1,mu1,mu2);
            end
        case 3 % h = r1(angle)mu1 + (1-r1(angle))mu2 barycentric
            for i=1:s
                h(i) = g3(theta(i+1),mu1,mu2);
            end
        case 4 % h is small in one direction
            for i=1:s
                h(i) = g4(theta(i+1),mu1,mu2,dir1,0.02);
            end
        case 5 % h is small in two directions
            for i=1:s
                h(i) = g5(theta(i+1),dir1,dir2,mu1,mu2,Hc,0.02);
            end
        case 6 % h is linear [dir1,dir22]->[mu1,mu2]
            for i=1:s
                h(i) = g6(theta(i+1),dir1,dir2,mu1,mu2,Hc);
            end
    end
end

% Definition of topothesis function c
C = zeros(1,s);
if (anisoHC == 0)
    for i=1:s
        C(i) = Hc;
    end
elseif (anisoHC == 1)
    switch(choiceG)
    case 0 % h = constante
        for i=1:s
            C(i) = Hc;
        end
    case 1 % h = mu1 in the sector (dir1,dir2) and h = mu2 outside
        for i=1:s
            C(i) = g1(theta(i+1),dir1,dir2,mu1,mu2);
        end
    case 2 % h linear [-pi/2,dir1]->[mu2,mu1] and linear [dir1,pi/2]->[mu1,mu2]
        for i=1:s
            C(i) = g2(theta(i+1),dir1,mu1,mu2);
        end
    case 3 % h = r1(angle)mu1 + (1-r1(angle))mu2 barycentric
        for i=1:s
            C(i) = g3(theta(i+1),mu1,mu2);
        end
    case 4 % h is small in one direction
        for i=1:s
            C(i) = g4(theta(i+1),mu1,mu2,dir1,0.02);
        end
    case 5 % h is small in two directions
        for i=1:s
            C(i) = g5(theta(i+1),dir1,dir2,mu1,mu2,Hc,0.02);
        end
    case 6 % h is linear [dir1,dir22]->[mu1,mu2]
        for i=1:s
           C(i) = g6(theta(i+1),dir1,dir2,mu1,mu2,Hc);
        end
    end
end


% Compute weights 
w = zeros(1,s);
for i=1:s
    w(i) = sqrt(lambda(i)*C(i)*gam(h(i))); 
end

% Corresponding angle/Hurst 
Tab = zeros(2,s);
for i=1:s
   Tab(1,i) = theta(i+1);
   Tab(2,i) = h(i);
end

%----------------------------------------------------%
% Simulation of the s fBm Yif(r(|pi|+qi),h(theta_i)) %
%----------------------------------------------------%

simul = zeros(maxlength,s);
%Hest = zeros(1,s);
for i=1:s
   l = r*(abs(p(i))+q(i))+1;
   simul(1:l,i) = circFBM(l,h(i));
   %Hest(i) = VaPkstST(simul(1:l,i),l,2,[1 -1]);
end

%------------------------------%
% Filling of the 2D afBf image %
%------------------------------%

X = zeros(r+1,r+1);
for i=1:s
    if p(i)<0
       shift = 1+r*abs(p(i)); % to prevent index of simul to be negatives
    else                      % this is shift relevant because mBf has
       shift = 1;             % stationnary increments
    end
    for k1=0:r
        for k2=0:r
            X(k1+1,k2+1) = X(k1+1,k2+1)+w(i)*simul(shift+k1*q(i)+k2*p(i),i);
        end
    end
end

afBf = X;
end

%---------------------%
% Auxiliary functions %
%---------------------%

function res = g6(x,dir1,dir2,mu1,mu2,H)
if (x >= dir1) & (x <= dir2)
    a = (mu2-mu1)/(dir2-dir1);
    b = mu1 - a*dir1;
    res = a*x+b;
else
    res = H;
end
end

function res = g4(x,mu1,mu2,dir,e)
    if (abs(x-dir)<e) 
        res = mu1;
    else
        res = mu2;
    end
end

function res = g1(x,dir1,dir2,mu1,mu2)
    if (x >= dir1) & (x <= dir2)
        res = mu1;
    else
        res = mu2;
    end
end

function res = g2(x,dir,mu1,mu2)
    a1 = (mu1-mu2)/(dir+pi/2);
    b1 = mu1 - a1*dir;
    a2 = (mu1-mu2)/(dir-pi/2);
    b2 = mu1 - a2*dir;
    if (x >= -pi/2) & (x <= dir)
        res = a1*x+b1;
    elseif (x > dir) & (x <= pi/2)
        res = a2*x+b2;
    end
end

function res = g3(x,mu1,mu2)
    if (x >= -pi/2) & (x <= 0)
        res = mu1*r1(-x)+mu2*(1-r1(-x));
    elseif (x >= 0) & (x <= pi/2)
        res = mu1*r1(x)+mu2*(1-r1(x));
    end
end

function res = g5(x,dir1,dir2,mu1,mu2,H,e)
    if (abs(x-dir1)<e)
        res = mu1;
    elseif (abs(x-dir2)<e)
        res = mu2;
    else
        res = H;
    end
end


function res = c(x,alpha1,alpha2)
    if ((x >= alpha1) & (x <= alpha2))
        res = 1;
    else
        res = 0;
    end
end

function res = gam(H)
    res = pi/(H*gamma(2*H)*sin(H*pi));
end

function res = r1(x)
    res = 0.5*(1+sin(2*x+pi/2));
end