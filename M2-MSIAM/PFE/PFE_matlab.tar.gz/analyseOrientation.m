% ------------------------------------------------------------------------
%
% Author : Kevin Polisano
% Email  : kevin.polisano@ensimag.fr
% Adress : LJK Grenoble
%
% Input :
%             I : the matrix (image) whose we want to analyze orientations
%           Tab : the angles of turning bands and their Hurst exponent
%
% Output :
%           theta_tab(k) : orientation vectors at scale k
%           angles_tab(k) : angle defined of these vectors at scale k
%           his_tab(k) : histogram of the repartition of these angles
%           xout_tab(k) : index of the histogram (see help hist in matlab)
%           anglemax_tab(k) : the dominant angle in the histogram
%
%           Then pass in parameters these tabulars to the orientation.m
%           function which is a GUI representing them.
%
%--------------------------------------------------------------------------
function analyseOrientation(I,Tab,Stats)

% Parameters
nv = 16;                   % Nb coef by octave
myw = 'cmor20-1';           % The Mother Wavelet used
N = size(I,1);             % Size of the image
maxna = log2(N)-1;         % Octave max
as = 2.^(0:(1/nv):maxna);  % Octaves
na =length(as);            % Nb of octaves
nbOctaveAnalyzed = 10;     % If Stats is True

% Riesz transform and componentwise wavelet transform
Wx = monowt2(I,as,myw);

% Storage of orientations for each octave
border = 20; % we ignore borders of the image
n = size(Wx{1}{1},1)-2*border
theta_tab = zeros(na,2,n,n);
angles_tab = zeros(na,n,n);
his_tab = zeros(na,50);
hissym_tab = zeros(na,2*n^2);
xout_tab = zeros(na,50);
anglemax_tab = zeros(na);
for k=1:na
    [theta angles his hissym xout anglemax] = orientations(Wx,k);
    theta_tab(k,1,:,:) = theta{1};
    theta_tab(k,2,:,:) = theta{2};
    angles_tab(k,:,:) = angles;
    hissym_tab(k,:) = hissym;
    %%% Statistical Analysis %%%
    if (Stats & k <= nbOctaveAnalyzed)
    my_data = zeros(2*n^2,2); % orientations symetrized (*2)
    my_hist = zeros(2*n^2,1); % histogram symetrized (*2)
    ind = 1;
    for i=1:n
        for j=1:n
            my_data(ind,1) = cos(angles(i,j));
            my_data(ind,2) = sin(angles(i,j));
            my_hist(ind) = angles(i,j);
            ind = ind+1;
            if angles(i,j)>=0
               my_data(ind,1) = cos(angles(i,j)-pi);
               my_data(ind,2) = sin(angles(i,j)-pi);
               my_hist(ind) = angles(i,j)-pi;
            else
               my_data(ind,1) = cos(angles(i,j)+pi);
               my_data(ind,2) = sin(angles(i,j)+pi);
               my_hist(ind) = angles(i,j)+pi;
            end
            ind = ind+1;
        end
    end
    name = strcat('Stats/my_data',num2str(k),'.out');
    name2 = strcat('Stats/my_hist',num2str(k),'.his');
    save(name,'my_data','-ASCII');
    save(name2,'my_hist','-ASCII');
    end
    %%% End Analysis %%%
    his_tab(k,:) = his;
    xout_tab(k,:) = xout;
    anglemax_tab(k) = anglemax;
end

orientation(I,as,Wx,theta_tab,angles_tab,his_tab,xout_tab,anglemax_tab,Tab,hissym_tab);

clear all;

end

% Auxiliary function to compute all objects we need, at a given scale k
function [thetabis angles his hissym xout anglemax] = orientations(Wx,k)
border = 20;
n = size(Wx{1}{1},1)-2*border;
% Compute the orientations theta
[phi theta] = phase3(Wx{k});
thetabis{1}=theta{1}(1+border:n+border,1+border:n+border);
thetabis{2}=theta{2}(1+border:n+border,1+border:n+border);
% Compute the corresponding angles
angles = zeros(n,n);
hissym = zeros(2*n^2,1);
ind = 1;
for i=1:n
    for j=1:n
        angles(i,j) = atan(thetabis{2}(i,j)/thetabis{1}(i,j)); % in real atan2
        hissym(ind) = angles(i,j);
        ind = ind+1;
        if angles(i,j)>=0
               hissym(ind) = angles(i,j)-pi;
        else
               hissym(ind) = angles(i,j)+pi;
        end
        ind = ind+1;
    end
end
% Compute the histogram of the angles and its maximum
[his,xout] = hist(angles(:),50);
[C I] = max(his);
anglemax = (xout(I)+xout(I))/2;
end