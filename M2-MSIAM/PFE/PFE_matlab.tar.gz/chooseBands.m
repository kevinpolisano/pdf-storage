% Fonction retournant les vecteurs (pk,qk) optimaux
function [p q] = chooseBands(r,alpha1,alpha2,epsilon)

N = 1+ceil(1/tan(epsilon));

% On construit l'ensemble V_N
compteur = 1;
for qq=1:N
    for pp=-N:N
        aux=atan(pp/qq);
        if ((alpha1 < aux) & (aux < alpha2) & gcd(pp,qq)==1)
            VN(1,compteur) = pp;
            VN(2,compteur) = qq;
            VN(3,compteur) = aux;
            VN(4,compteur) = C(r,abs(pp)+qq);
            compteur = compteur+1;
        end
    end
end

n = size(VN,2); % nombre de turning bands considérées

% On trie V_N suivant la valeur de arctan(pk/qk)
[Y l] = sort(VN(3,:));
VN2 = VN(:,l);

% On rajoute les angles extrêmes theta_0=alpha_1 et theta_(n+1)=alpha2
theta = zeros(1,n+2);
theta(1)=alpha1;
theta(n+2)=alpha2;
theta(2:n+1)=VN2(3,:);

ek = zeros(1,n+1);
ek(1)=0;
ek(2:n+1)=VN2(4,:);

% calcul des coûts
cout = zeros(1,n+2);
cout(n+2) = 0;

k = zeros(1,n+1);
for i=n+1:-1:1
   cmin = Inf;
   j = i+1;
   while ((j<=n+2) & (theta(j)<=theta(i)+epsilon))
      if (cout(j)<=cmin)
         cmin = cout(j);
         k(i) = j;
      end
      j=j+1;
   end
   cout(i)=ek(i)+cmin;
end

i=1;
s=1;
while (k(i)<=n)
   i=k(i);
   p(s)=VN2(1,i);
   q(s)=VN2(2,i);
   s=s+1;
end


end

% Coût d'une simulation d'un brownien fractionnaire Yi de longueur r*l
function res = C(r,l)
    a = ceil(log2(r*l));
    res = 2^(a)*a;
end