function varargout = BonamiEstradeSimulation(varargin)
% BONAMIESTRADESIMULATION MATLAB code for BonamiEstradeSimulation.fig
%      BONAMIESTRADESIMULATION, by itself, creates a new BONAMIESTRADESIMULATION or raises the existing
%      singleton*.
%
%      H = BONAMIESTRADESIMULATION returns the handle to a new BONAMIESTRADESIMULATION or the handle to
%      the existing singleton*.
%
%      BONAMIESTRADESIMULATION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BONAMIESTRADESIMULATION.M with the given input arguments.
%
%      BONAMIESTRADESIMULATION('Property','Value',...) creates a new BONAMIESTRADESIMULATION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before BonamiEstradeSimulation_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to BonamiEstradeSimulation_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help BonamiEstradeSimulation

% Last Modified by GUIDE v2.5 14-Jun-2013 09:46:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @BonamiEstradeSimulation_OpeningFcn, ...
                   'gui_OutputFcn',  @BonamiEstradeSimulation_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before BonamiEstradeSimulation is made visible.
function BonamiEstradeSimulation_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to BonamiEstradeSimulation (see VARARGIN)

% Choose default command line output for BonamiEstradeSimulation
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% Add current folder and all subfolders to the path
tmp=which('BonamiEstradeSimulation'); % complete path to the main file
index=strfind(tmp,'/');               % index of '/' into the string tmp              
p=tmp(1:index(end));                  % folder which contains the file
addpath([p,'WLBMF_tool'],[p,'CircStat2012a'],[p,'Coeurjolly'],[p,'Oberlin']);
clear p tmp index

% Default parameters
r = 255;
alpha1 = -pi/2;
alpha2 = pi/2;
epsilon = 0.03;
Params = [1 0.2 0.8 -pi/4 pi/4 0.5 0 0]; % method / mu1 / mu2 / dir1 / dir2 / HC / choiceG
countImage = 1;
setappdata(handles.figure1,'countImage',countImage);
setappdata(handles.figure1,'r',r);
setappdata(handles.figure1,'alpha1',alpha1);
setappdata(handles.figure1,'alpha2',alpha2);
setappdata(handles.figure1,'epsilon',epsilon);
setappdata(handles.figure1,'Params',Params);
setappdata(handles.figure1,'choiceDisp',0);
setappdata(handles.figure1,'Stats',0);
set(handles.uipanel3,'selectedobject',handles.radiobutton7);
set(handles.uipanel1,'selectedobject',handles.radiobutton3);
set(handles.uipanel2,'selectedobject',handles.radiobutton5);
changeBackgroundColor([0 0 0 0 1],handles);
updatep(handles);

% UIWAIT makes BonamiEstradeSimulation wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = BonamiEstradeSimulation_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
h = get(hObject,'String');
setappdata(handles.figure1,'r',str2num(h));
updatep(handles);


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
h = get(hObject,'String');
setappdata(handles.figure1,'alpha1',str2num(h));
updatep(handles);

% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
h = get(hObject,'String');
setappdata(handles.figure1,'alpha2',str2num(h));
updatep(handles);

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double
h = get(hObject,'String');
setappdata(handles.figure1,'epsilon',str2num(h));
updatep(handles);


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double
h = get(hObject,'String');
Params = getappdata(handles.figure1,'Params');
Params(2) = str2num(h);
setappdata(handles.figure1,'Params',Params);
updatep(handles);

% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double
h = get(hObject,'String');
Params = getappdata(handles.figure1,'Params');
Params(3) = str2num(h);
setappdata(handles.figure1,'Params',Params);
updatep(handles);


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double
h = get(hObject,'String');
Params = getappdata(handles.figure1,'Params');
Params(4) = str2num(h);
setappdata(handles.figure1,'Params',Params);
updatep(handles);


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double
h = get(hObject,'String');
Params = getappdata(handles.figure1,'Params');
Params(5) = str2num(h);
setappdata(handles.figure1,'Params',Params);
updatep(handles);

% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double
h = get(hObject,'String');
Params = getappdata(handles.figure1,'Params');
Params(6) = str2num(h);
setappdata(handles.figure1,'Params',Params);
updatep(handles);


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
updatep(handles);


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I = getappdata(handles.figure1,'I');
Tab = getappdata(handles.figure1,'Tab');
analyseProfile(I,Tab);


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I = getappdata(handles.figure1,'I');
Tab = getappdata(handles.figure1,'Tab');
Stats = getappdata(handles.figure1,'Stats');
analyseOrientation(I,Tab,Stats);

function updatep(handles)
r = getappdata(handles.figure1,'r');
alpha1 = getappdata(handles.figure1,'alpha1');
alpha2 = getappdata(handles.figure1,'alpha2');
epsilon = getappdata(handles.figure1,'epsilon');
Params = getappdata(handles.figure1,'Params');
choiceDisp = getappdata(handles.figure1,'choiceDisp');
[I Tab] = BonamiEstrade(r,alpha1,alpha2,epsilon,Params);
%%% Radon
if 0
theta = 0:180;
[R,xp] = radon(I,theta);
figure;
imshow(R,[],'Xdata',theta,'Ydata',xp,...
            'InitialMagnification','fit');
xlabel('\theta (degrees)');
ylabel('x''');
colormap(hot), colorbar;
iptsetpref('ImshowAxesVisible','off');
end
%%%
setappdata(handles.figure1,'I',I);
setappdata(handles.figure1,'Tab',Tab);

% Display Init (Classic fractional Brownian)
switch (choiceDisp)
    case 0
        colormap(handles.axes1,gray);
        imagesc(I,'Parent',handles.axes1);
    case 1
        s = size(Tab,2);
        x1 = zeros(2*s);
        y1 = zeros(2*s);
        for i=1:s
            x1(2*i-1)=-(1-Tab(2,i))*cos(Tab(1,i));
            y1(2*i-1)=-(1-Tab(2,i))*sin(Tab(1,i));
            x1(2*i)=(1-Tab(2,i))*cos(Tab(1,i));
            y1(2*i)=(1-Tab(2,i))*sin(Tab(1,i));
        end
        th = 0:pi/50:2*pi;
        xunit = cos(th);
        yunit = sin(th);
        plot(handles.axes1,xunit, yunit,'b');
        hold(handles.axes1,'on');
        plot(handles.axes1,x1,y1,'r');
        axis(handles.axes1,[-1.05 1.05 -1.05 1.05]);
        set(handles.axes1,'DataAspectRatio',[1 1 1]);
        hold(handles.axes1,'off');
end


set(handles.edit1,'String',num2str(r));
set(handles.edit2,'String',num2str(alpha1));
set(handles.edit3,'String',num2str(alpha2));
set(handles.edit4,'String',num2str(epsilon));
set(handles.edit5,'String',num2str(Params(2)));
set(handles.edit6,'String',num2str(Params(3)));
set(handles.edit7,'String',num2str(Params(4)));
set(handles.edit8,'String',num2str(Params(5)));
set(handles.edit9,'String',num2str(Params(6)));



% --- Executes when selected object is changed in uipanel3.
function uipanel3_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel3 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
h = get(eventdata.NewValue, 'Tag');
if (strcmp(h,'radiobutton7'))
    choiceG = 0;
    changeBackgroundColor([0 0 0 1 1],handles);
elseif (strcmp(h,'radiobutton8'))
    choiceG = 1;
    changeBackgroundColor([1 1 1 1 0],handles);
elseif (strcmp(h,'radiobutton9'))
    choiceG = 2;
    changeBackgroundColor([1 1 1 0 0],handles);
elseif (strcmp(h,'radiobutton10'))
    choiceG = 3;
    changeBackgroundColor([1 1 0 0 0],handles);
elseif (strcmp(h,'radiobutton11'))
    choiceG = 4;
    changeBackgroundColor([1 1 1 0 0],handles);
elseif (strcmp(h,'radiobutton12'))
    choiceG = 5;
    changeBackgroundColor([1 1 1 1 1],handles);
elseif (strcmp(h,'radiobutton13'))
    choiceG = 6;
    changeBackgroundColor([1 1 1 1 0],handles);
end
Params = getappdata(handles.figure1,'Params');
Params(7) = choiceG;
setappdata(handles.figure1,'Params',Params);
updatep(handles);


% --- Executes when selected object is changed in uipanel1.
function uipanel1_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel1 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
h = get(eventdata.NewValue, 'Tag');
if (strcmp(h,'radiobutton3'))
    choiceDisp = 0;
elseif (strcmp(h,'radiobutton4'))
    choiceDisp = 1;
end;
setappdata(handles.figure1,'choiceDisp',choiceDisp);
updatep(handles);


% --- Executes when selected object is changed in uipanel2.
function uipanel2_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel2 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
h = get(eventdata.NewValue, 'Tag');
if (strcmp(h,'radiobutton5'))
    anisoHC = 0;
elseif (strcmp(h,'radiobutton6'))
    anisoHC = 1;
end;
Params = getappdata(handles.figure1,'Params');
Params(8) = anisoHC;
setappdata(handles.figure1,'Params',Params);
updatep(handles);


% --- Executes during object creation, after setting all properties.
function uipanel3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

function changeBackgroundColor(M,handles)
Yellow = [1 1 0.6];
Green = [0.6 1 0.6];
for i=1:5
   if M(i) == 0
        set(handles.(sprintf('edit%d', i+4)),'BackgroundColor',Yellow);
   elseif (M(i) == 1)
        set(handles.(sprintf('edit%d', i+4)),'BackgroundColor',Green);
   end
end


% --------------------------------------------------------------------
function uipushtool1_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to uipushtool1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
im_Texture = getframe(handles.axes1);
image(im_Texture.cdata);
countImage = getappdata(handles.figure1,'countImage');
name = strcat('Images/Texture',num2str(countImage),'.jpg');
imwrite(im_Texture.cdata,name);
countImage = countImage + 1;
setappdata(handles.figure1,'countImage',countImage);


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1
Stats = get(hObject,'Value');
setappdata(handles.figure1,'Stats',Stats);