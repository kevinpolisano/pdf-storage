% ------------------------------------------------------------------------
%
% Author : Kevin Polisano
% Email  : kevin.polisano@ensimag.fr
% Adress : LJK Grenoble
%
% Input :
%          the handles of the figure
%          the parameters of these handles
%
%  Update plot (axes) and tools of the GUI, internal function, don't edit
%--------------------------------------------------------------------------
function updateh(handles)

% We get data
I = getappdata(handles.figure1,'I');
as = getappdata(handles.figure1,'as');
Wx = getappdata(handles.figure1,'Wx');
theta_tab = getappdata(handles.figure1,'theta_tab');
angles_tab = getappdata(handles.figure1,'angles_tab');
xout_tab = getappdata(handles.figure1,'xout_tab');
his_tab = getappdata(handles.figure1,'his_tab');
anglemax_tab = getappdata(handles.figure1,'anglemax_tab');
Tab = getappdata(handles.figure1,'Tab');
hissym_tab = getappdata(handles.figure1,'hissym_tab');
k = getappdata(handles.figure1,'k');
tog1 = getappdata(handles.figure1,'tog1');
tog2 = getappdata(handles.figure1,'tog2');
border = 20;
n = size(Wx{1}{1},1)-2*border;
na = length(as);

% We update each plot display

% Plot 1 (top left)
switch(tog1)
    case 0 % texture image
        colormap(handles.axes1,gray);
        imagesc(I,'Parent',handles.axes1);
        title(handles.axes1,'Texture image');
    case 1 % Bands repartition weighted by their Hurst exponent
        s = size(Tab,2);
        x1 = zeros(2*s);
        y1 = zeros(2*s);
        for i=1:s
            x1(2*i-1)=-(1-Tab(2,i))*cos(Tab(1,i));
            y1(2*i-1)=-(1-Tab(2,i))*sin(Tab(1,i));
            x1(2*i)=(1-Tab(2,i))*cos(Tab(1,i));
            y1(2*i)=(1-Tab(2,i))*sin(Tab(1,i));
        end
        th = 0:pi/50:2*pi;
        xunit = cos(th);
        yunit = sin(th);
        plot(handles.axes1,xunit, yunit,'b');
        hold(handles.axes1,'on');
        plot(handles.axes1,x1,y1,'r');
        axis(handles.axes1,[-1.05 1.05 -1.05 1.05]);
        set(handles.axes1,'DataAspectRatio',[1 1 1]);
        title(handles.axes1,['Repartition of the ',int2str(s),' bands weighted by h']);
        hold(handles.axes1,'off');
end

% Plot 2 (bottom left)
idx = 1:(1+floor(n/30)):n;
% squeeze is used to resize matrix MxNx1 in MxN
quiver(handles.axes2,idx,idx,squeeze(theta_tab(k,1,idx,idx)),squeeze(theta_tab(k,2,idx,idx)));
set(handles.axes2,'XLim',[-5,n+5],'YLim',[-5,n+5]);
title(handles.axes2,'Orientation field');


% Plot 3 (top right)
imagesc(squeeze(angles_tab(k,:,:)),'Parent',handles.axes3);
colormap(handles.axes3,hsv);
colorbar('peer',handles.axes3,'location','eastoutside');
title(handles.axes3,'Colormap of the orientations');
% list_angles = squeeze(angles_tab(k,:,:));
% disp 'simple_mean';
% mean(list_angles(:))
% disp 'circ_mean';
% circ_mean(list_angles(:)) % pas de sens!
% [mu kappa] = circ_vmpar(list_angles(:))
%mu = circ_median(list_angles(:)) % couteux!

% Plot 4 (bottom right)
switch(tog2)
    case 0 % histogram
        bar(handles.axes4,xout_tab(k,:),his_tab(k,:),'b');
        hold(handles.axes4,'on');
        plot(handles.axes4,[anglemax_tab(k) anglemax_tab(k)],[0 max(his_tab(k,:))],'--r','LineWidth',2);
        %plot(handles.axes4,[mu mu],[0 max(his_tab(k,:))],'--g','LineWidth',2);
        title(handles.axes4,'Histogramm of the angular repartition');
        hold(handles.axes4,'off');
    case 1 % circular histogram
        if 0
        hh = xout_tab(k,:);
        hb = his_tab(k,:);
        tot = max(hb);
        l = size(hh,2);
        xh = zeros(2*l);
        yh = zeros(2*l);
        for i=1:l-1
            mid = (hh(i)+hh(i+1))/2;
            xh(2*i-1)=-(hb(i)/tot)*cos(mid);
            yh(2*i-1)=-(hb(i)/tot)*sin(mid);
            xh(2*i)=(hb(i)/tot)*cos(mid);
            yh(2*i)=(hb(i)/tot)*sin(mid);
        end
        th = 0:pi/50:2*pi;
        xunit = cos(th);
        yunit = sin(th);
        plot(handles.axes4,xunit, yunit,'b');
        hold(handles.axes4,'on');
        plot(handles.axes4,xh,yh,'b');
        plot(handles.axes4,[cos(anglemax_tab(k)) -cos(anglemax_tab(k))],[sin(anglemax_tab(k)) -sin(anglemax_tab(k))],'--r','LineWidth',2);
        plot(handles.axes4,[cos(mu) -cos(mu)],[sin(mu) -sin(mu)],'--g','LineWidth',2);
        axis(handles.axes4,[-1.05 1.05 -1.05 1.05]);
        set(handles.axes4,'DataAspectRatio',[1 1 1]);
        title(handles.axes4,'Circular histogramm of the angles');
        hold(handles.axes4,'off');
        end
        axes(handles.axes4);
        circ_plot(hissym_tab(k,:),'hist',[],100,false,false);
end

% We edit the textbox with the current value of k
set(handles.edit1,'String',...
    num2str(k));
end