Nous avons utilis� Processing 2.0 afin de r�aliser ce projet, c'est un IDE qui agit comme une surcouche de Java, il est disponible ici:
http://processing.org/download/
une fois installer (i.e. dezipper) il suffit d'executer le fichier Visu qui generera les fichiers necessaire pour le projet. ( image et kml)

Nous avons aussi mit quasiment en ent�te du fichier Visu, toutes les variables interessante � modifier. par exemple si vous voulez tester avec d'autre fichier de donn�e que ce que l'on � utilis�.
ou avec d'autre m�thode d'interpolation.

