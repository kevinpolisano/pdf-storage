%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  En entrée : la trajectoire (x,y,z) + les observations (xob,yob,zob)
%
%  En sortie : Le calcul du coût J mesurant l'écart aux observations
%              Le gradient de J
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [J,nablaJ] = cost(n,h,x,y,z,xob,yob,zob,s,p,b,D,ob_step)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calcul de la fonction coût J(u0)  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

J = 0.0d0;

for i = 1 : ob_step : n
  J = J + 0.5 * ( (x(i)-xob(i))*(x(i)-xob(i))*D(i) ...
        + (y(i)-yob(i))*(y(i)-yob(i))*D(i) ...
        + (z(i)-zob(i))*(z(i)-zob(i))*D(i) );
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calcul du gradient (nabla J)_{u0}  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Variable d'état adjointe u_tilde
x_tilde = zeros(n,1);
y_tilde = zeros(n,1);
z_tilde = zeros(n,1);

x_tilde(n+1) = 0.0d0;
y_tilde(n+1) = 0.0d0;
z_tilde(n+1) = 0.0d0;


% On part du dernier vecteur d'innovation d_n
x_tilde(n) = (x(n)-xob(n))*D(n);
y_tilde(n) = (y(n)-yob(n))*D(n);
z_tilde(n) = (z(n)-zob(n))*D(n);

% Et on remonte à rebours l'évolution de la variable adjointe u_tilde
% jusqu'à i = 1 qui donne u_tilde(0) = (nabla J)_{u0}
for i = n-1 : -1 : 1
    
     % Calcul des coefficients de la matrice adjointe Mi^T
     m11 = 1.0d0+0.5d0*h*(-2.0d0*s+h*s*(s+p-z(i)));
     m12 = 0.5d0*h*(p+(1-s*h)*p-h*y(i)*(x(i)+s*h*(-x(i)+y(i))) ...
            -h*(p-z(i))-z(i)-(1.0d0-s*h)*(z(i)+h*(x(i)*y(i)- ...
            b*z(i))));
     m13 = 0.5d0*h*(y(i)-b*h*y(i)+h*(x(i)+ ...
            s*h*(y(i)-x(i)))*(p-z(i))+(1.0d0-s*h)*(y(i)+ ...
            h*(p*x(i)-y(i)-x(i)*z(i))));
     m21 = 0.5d0*h*s*(2.0d0-h-s*h);
     m22 = 1.0d0+0.5d0*h*(-2.0d0+h+s*h*p-h*x(i)*(x(i)+s*h* ...
             (y(i)-x(i)))-s*h*(z(i)+ ...
             h*(x(i)*y(i)-b*z(i)))) ;
     m23 = 0.5d0*h*(x(i)-b*h*x(i)+(1.0d0-h)* ...
            (x(i)+s*h*(y(i)-x(i)))+ ...
            s*h*(y(i)+h*(p*x(i)-y(i)-x(i)*z(i))));
     m31 =-0.5d0*s*h*h*x(i);
     m32 = 0.5d0*h*(-x(i)+h*x(i)- ...
            (1.0d0-b*h)*(x(i)+s*h*(y(i)-x(i))));
     m33 = 1.0d0+0.5d0*h*(-2.0d0*b+b*b*h-h*x(i)* ...
            (x(i)+s*h*(y(i)-x(i))));
    
     % Calcul de Mi^T*u_tilde(i+1)
     x1_tilde = m11*x_tilde(i+1)+m12*y_tilde(i+1)+m13*z_tilde(i+1);
     y1_tilde = m21*x_tilde(i+1)+m22*y_tilde(i+1)+m23*z_tilde(i+1);
     z1_tilde = m31*x_tilde(i+1)+m32*y_tilde(i+1)+m33*z_tilde(i+1);
    
    % u_tilde(i) = Hi^T*Ri^(-1)*(uobs(i)-Hi*u(i)) + Mi^T*u_tilde(i+1)   
    x_tilde(i) = x1_tilde + (x(i)-xob(i))*D(i);
    y_tilde(i) = y1_tilde + (y(i)-yob(i))*D(i);
    z_tilde(i) = z1_tilde + (z(i)-zob(i))*D(i);
    
end

% En sortie le gradient
nablaJ = [x_tilde(1),y_tilde(1),z_tilde(1)];


