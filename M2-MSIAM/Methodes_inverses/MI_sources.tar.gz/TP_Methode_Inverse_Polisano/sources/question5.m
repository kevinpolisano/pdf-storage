%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%  Résolution du système différentiel de Lorenz défini par les équations  %
%                                                                         %
%       x' = s(y-x)                                                       %
%       y' = px - y -xz                                                   %
%       z' = xy - bz                                                      %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function question5

%%%%%%%%%%%%%%%%
%  Paramètres  %
%%%%%%%%%%%%%%%%

tfinal = 30;                   % Temps de simulation (en ms)
he = 0.01;                     % Pas de discrétisation pour Euler
hr = 0.05;                     % Pas de discrétisation pour Runge-Kutta
festep = tfinal/he;            % Nombre de pas pour Euler
frstep = tfinal/hr;            % Nombre de pas pour Runge-Kutta
uref = [-4.62,-6.61,17.94];    % Conditions initiales et paramètres Lorenz
s = 10;                        % sigma
p = 28;                        % rho
b = 8/3;                       % beta
methode = 0;                   % Méthode de résolution utilisée
                               % 0 : ode45 de Matlab
                               % 1 : Schéma d'Euler
                               % 2 : Runge-Kutta d'ordre 2

if (methode == 0)
    % Résolution du système différentiel par méthode de Runge-Kutta
    display 'Resolution du systeme differentiel de Lorenz via ode45'
    [t,u] = ode45(@(t,u) f(t,u,s,p,b),[0,tfinal],uref);
    % On récupère x,y,z
    x = u(:,1);
    y = u(:,2);
    z = u(:,3);
elseif (methode == 1)
    display 'Resolution du systeme differentiel de Lorenz via Euler'
    t = 0:he:tfinal;
    [x,y,z] = euler(festep,he,uref(1),uref(2),uref(3),s,p,b,1);
elseif (methode == 2)
    display 'Resolution du systeme differentiel de Lorenz via Runge-Kutta'
    t = 0:hr:tfinal;
    [x,y,z] = euler(frstep,hr,uref(1),uref(2),uref(3),s,p,b,2);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Représentation graphique  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subplot(221)
plot(t,x)
xlabel('temps (ms)');
ylabel('x');
axis([0 tfinal -20 20]);

subplot(222)
plot(t,y,'g')
xlabel('temps (ms)');
ylabel('y');
axis([0 tfinal -40 40]);

subplot(223)
plot(t,z,'m')
xlabel('temps (ms)');
ylabel('z');
axis([0 tfinal 0 60]);

subplot(224)
plot(x,z,'r')
xlabel('x');
ylabel('z');
title('Plan de phase xz');
axis([-20 20 0 50]);

end

% On met le système différentiel sous la forme u' = f(u)
% avec u = (x,y,z) appartenant à R^3 et f : R^3 -> R^3
function upoint = f(t,u,s,p,b)

% Image de u par f
upoint(1) = s*(u(2)-u(1));
upoint(2) = p*u(1)-u(2)-u(1)*u(3);
upoint(3) = u(1)*u(2)-b*u(3);

upoint = upoint';

end
