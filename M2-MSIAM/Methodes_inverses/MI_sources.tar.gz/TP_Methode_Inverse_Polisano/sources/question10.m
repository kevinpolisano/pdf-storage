%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%  Assimilation de données par 4D-Var                                     %
%                                                                         %
%  Equations de Lorenz :                                                  %
%                                                                         %
%  x' = -s(x-y)                                                           %
%  y' = px - y - xz                                                       %
%  z' = xy - bz                                                           %
%                                                                         %
%  Vraie condition initiale: u_0ref = (x0r,y0r,z0r) = (-4.62,-6.61,17.94) %
%  Ebauche initiale : u_0b = (x0b,y0b,z0b) = (-5,-7,17)                   %
%  Observations (générées à partir de u_0ref) :                           %
%  u_obs(ti) = (xref(ti),yref(ti),zref(ti))                               %
%                                                                         %
%  Fonction coût (écart aux observations) :                               %
%  J(u0) = (u0-u0b)^t(u0-u0b) + Somme_i (uobs(i)-u(i))^t(uobs(i)-u(i))    %
%  où u = (x,y,z) fonction solution de l'équa diff avec cond init u0      %
%                                                                         %
%  Objectif : Trouver la condition initiale u0 = u_a0 qui minimise J      %
%             en effectuant une descente de gradient, pour estimer u_0ref %
%             La trajectoire correspondante u_a appelée courbe analyse    %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function question10

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Paramètres ajustables par l'utilisateur  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

s = 10;                % sigma
p = 28;                % rho
b = 8/3;               % beta
tassim = 2;            % temps d'assimilation
tforc  = 3;            % temps fin
tfinal = tassim+tforc; % temps de simulation total
h = 0.05;              % pas de temps du schéma numérique
ob_step = 2;           % intervalle de temps entre 2 observations
tstep = tassim/h+1;    % nombre d'itérations sur la fenêtre d'assimilation
fstep = tfinal/h;      % nombre d'itérations sur toute la fenêtre
max_iter = 30;         % nombre maximal d'itérations
tol = 0.001;           % tolérance d'erreur, critère d'arrêt

schema = 2;            % schéma numérique utilisé 
                       %      1 : Euler (prendre h petit)
                       %      2 : Runge-Kutta d'ordre 2
graphe = 3;            % graphique affiché 
                       %      1 : Vraie solution u_ref
                       %      2 : u_ref + Solution ébauche u_b
                       %      3 : u_ref + u_b + Analyse u_a
                
courbes_erreur = 1;    % mettre à 1 pour afficher les courbes d'erreur :
                       %  - Variations de la fonction coût J
                       %  - Variations de la norme du gradient de J
                       
normeL2_erreur = 0;    % Pour calculer l'erreur quadratique finale
                    
% Conditions initiales
u_0ref = [-4.62,-6.61,17.94];     % Vraie solution
u_0b = [-5.00,-7.00,17.00];       % Ebauche

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calcul de la vraie solution uref = (x,y,z) %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[xref,yref,zref] = euler(fstep,h,u_0ref(1),u_0ref(2),u_0ref(3),s,p,b,schema);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calcul de la solution u_b  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[xb,yb,zb] = euler(fstep,h,u_0b(1),u_0b(2),u_0b(3),s,p,b,schema);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Génération des observations  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nobs = (tassim-1)/ob_step +1; %  Nombre d'observations sur l'assimilation
xob = zeros(nobs,1);
yob = zeros(nobs,1);
zob = zeros(nobs,1);
tobs = 1 : ob_step : tstep;   % Date d'observations
D = zeros(tstep,1);           % Vaut 1 pour un indice de d'observation

% Le vecteur d'observation est nul sauf aux temps d'observations tobs
for i = tobs
    xob(i) = xref(i);
    yob(i) = yref(i);
    zob(i) = zref(i);
    D(i) = 1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%
%  Algorithm du 4D-Var  %
%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Initialisation : u0 = u_0b (ébauche)
%
%  Tant que ||nablaJ(u0)||>tol && compteur < max_iter
%       1. Calculer le coût J(u0) et son gradient nablaJ(u0) via "cost"
%          qui fait appel au code adjoint pour calculer le gradient
%       2. Faire une descente de gradient u0 <- u0 - alpha*nablaJ(u0)
%  Fin Tant que
%  
%  Sortie : u0 qui minimise la fonction coût J(u0)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%
%  Initialisation  %
%%%%%%%%%%%%%%%%%%%%

u0x = zeros(max_iter,1);
u0y = zeros(max_iter,1);
u0z = zeros(max_iter,1);

% Initialisation u0 = u_0b
u0x(1) = u_0b(1);
u0y(1) = u_0b(2);
u0z(1) = u_0b(3);

% Trajectoire initiale à partir de l'ébauche
[x,y,z] = euler(tstep,h,u_0b(1),u_0b(2),u_0b(3),s,p,b,schema);

% Calcul initial du coût et du gradient
[J,dJ] = cost(tstep,h,x,y,z,xob,yob,zob,s,p,b,D,ob_step);
dJx = dJ(1);
dJy = dJ(2);
dJz = dJ(3);
k = 1;
dJnorm(k) = sqrt(dJx*dJx+dJy*dJy+dJz*dJz);
cout(k) = J;
alpha(k) = 0.5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Minimisation de la fonction de coût  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

termine = 0;

if (dJnorm(k) < tol)
    termine = 1;
end

while (dJnorm(k) > tol) & (termine == 0)
    % pas de descente initialisé à 0.5
    alpha(k) = 0.5;
  
    % Normalisation du gradient
    jx = dJx/dJnorm(k);
    jy = dJy/dJnorm(k);
    jz = dJz/dJnorm(k);
       
    % On détermine la nouvelle condition initiale
    % par une descente de gradient d'un pas alpha(k)
    u0x(k+1) = u0x(k)-alpha(k)*jx;
    u0y(k+1) = u0y(k)-alpha(k)*jy;
    u0z(k+1) = u0z(k)-alpha(k)*jz;

    % Trajectoire correspondant à la nouvelle condition initiale
    [x,y,z] = euler(tstep,h,u0x(k+1),u0y(k+1),u0z(k+1),s,p,b,schema);
    [J,dJ] = cost(tstep,h,x,y,z,xob,yob,zob,s,p,b,D,ob_step);
    dJx = dJ(1);
    dJy = dJ(2);
    dJz = dJ(3);

    % Norme du nouveau gradient et nouveau coût
    dJnorm(k+1) = sqrt(dJx*dJx+dJy*dJy+dJz*dJz);
    cout(k+1) = J; 
      
    % Si le maximum d'itérations est atteint on termine
  if (k-1 > max_iter)
    termine = 1;
    disp('Maximum iterations atteint sans convergence')
    Norme_du_gradient = dJnorm(k);
    cout_final = cout(k);
    Iteration
  else
    Iteration = k-1;
    % Tant qu'on a pas trouvé un gradient plus petit qu'à l'étape
    % précédente on diminue le pas de descente et on recalcule le
    % nouveau gradient.
    while ((dJnorm(k+1) >= dJnorm(k)) & (alpha(k) > tol) ...
                       & termine == 0)
         % On divise par 2 le pas de descente
         alpha(k) = alpha(k)*0.5;
         u0x(k+1) = u0x(k)-alpha(k)*jx;
         u0y(k+1) = u0y(k)-alpha(k)*jy;
         u0z(k+1) = u0z(k)-alpha(k)*jz;

         % On calcule la trajectoire correspondante
         [x,y,z] = euler(tstep,h,u0x(k+1),u0y(k+1),u0z(k+1),s,p,b,2);
         [J,dJ] = cost(tstep,h,x,y,z,xob,yob,zob,s,p,b,D,ob_step);
         dJx = dJ(1);
         dJy = dJ(2);
         dJz = dJ(3);

         % Norme du nouveau gradient et nouveau coût
        dJnorm(k+1) = sqrt(dJx*dJx+dJy*dJy+dJz*dJz);
        cout(k+1) = J;
        
         % Si la norme du gradient se stabilise on termine
        if (abs((dJnorm(k+1)-dJnorm(k))) < tol)
        disp('Convergence du gradient')
        Nombre_iterations = k-1;
        Norme_du_gradient = dJnorm(k+1);
        cout_final = cout(k);
        termine = 1;
        Iteration
        end
    end
    k = k+1;
  end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Condition initiale optimale et trajectoire associée  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Condition initiale optimale
u0opt(1) = u0x(k);
u0opt(2) = u0y(k);
u0opt(3) = u0z(k)

% Trajectoire associée
[x,y,z] = euler(fstep,h,u0opt(1),u0opt(2),u0opt(3),s,p,b,schema);

% Calcul du coût et du gradient sur tfinal (vérification)
[J,dJ] = cost(tstep,h,x,y,z,xob,yob,zob,s,p,b,D,ob_step);
dJnorm_final = sqrt(dJ(1)*dJ(1)+dJ(2)*dJ(2)+dJ(3)*dJ(3))
J_final = J

if (normeL2_erreur == 1)
    % On termine par donner la norme L^2 de la différence entre la vraie 
    % solution u_ref et l'analyse trouvée u_a = [x,y,z]. ||xref-x_a||_2, etc
    x_assim = x(1:tstep);
    y_assim = y(1:tstep);
    z_assim = z(1:tstep);
    xref_assim = xref(1:tstep);
    yref_assim = yref(1:tstep);
    zref_assim = zref(1:tstep);

    Lx_assim = norm(x_assim-xref_assim,2);
    Ly_assim = norm(y_assim-yref_assim,2);
    Lz_assim = norm(z_assim-zref_assim,2);

    Lx = norm(x-xref,2);
    Ly = norm(y-yref,2);
    Lz = norm(z-zref,2);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  On trace les courbes obtenus  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (graphe >= 1)
    t = 0:fstep;
    vob = 1 : ob_step : tstep;
    tob = vob - 1;
    subplot(221)
    plot(t,xref)
    if (graphe >= 2)
        hold on
        plot(t,xb,'k')
        plot(tob,xob(vob),'g*');
        if (graphe == 3)
            plot(t,x,'r');
        end
    end
    xlabel('iterations');
    ylabel('x');
    axis([0 fstep -20 20]);

    subplot(222)
    plot(t,yref,'b')
    if (graphe >= 2)
        hold on
        plot(t,yb,'k')
        plot(tob,yob(vob),'g*');
        if (graphe == 3)
            plot(t,y,'r');
        end
    end
    xlabel('iterations');
    ylabel('y');
    axis([0 fstep -20 20]);
     
    subplot(223)
    plot(t,zref,'b')
    if (graphe >= 2)
        hold on
        plot(t,zb,'k')
        plot(tob,zob(vob),'g*');
        if (graphe == 3)
            plot(t,z,'r');
        end
    end
    xlabel('iterations');
    ylabel('z');
    axis([0 fstep 0 60]);

    subplot(224)
    plot(xref,zref,'b')
    if (graphe >= 2)
        hold on
        plot(xb,zb,'k')
        plot(xob(vob),zob(vob),'g*');
    end
    if (graphe == 3)
       plot(x,z,'r')
    end
    xlabel('x');
    ylabel('z');
    title('Plan de phase xz');
end

if (courbes_erreur == 1)
   figure;
   iter = 0 : k-1;
   % Variations de la fonction coût
   subplot(2,1,1)
   semilogy(iter,cout(1:k))
   title('Variations de la fonction cout')
   xlabel('iteration')
   ylabel('cout J')
   % Variation du gradient
   subplot(2,1,2)
   semilogy(iter,dJnorm(1:k),'r')
   title('Variation de son gradient')
   xlabel('iteration')
   ylabel('Norme du gradient dJ') 
end
    
end

    
    
    











