%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Code du schéma numérique correspondant à la discrétisation des 
%  équations de Lorenz par différences finies. 
%         -- schema = 1 : Euler (premier ordre)
%         -- schema = 2 : Runge-Kutta (second ordre)
%
%  Entrée : les conditions initiales (x0,y0,z0)
%           le pas de temps h
%           le nombre d'itérations n
%           les paramètres de Lorenz (s,p,b)
%
%  Sortie : la trajectoire (x,y,z)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [x,y,z] = euler(n,h,x0,y0,z0,s,p,b,schema)

x=zeros(n,1);
y=zeros(n,1);
z=zeros(n,1);

% Initialisation
x(1)=x0(1);
y(1)=y0(1);
z(1)=z0(1);

if (schema == 1)      % Schéma d'Euler
    for i = 1 : n
       x(i+1) = x(i) - h*s*(x(i)-y(i));
       y(i+1) = y(i) + h*(p*x(i)-y(i)-x(i)*z(i));
       z(i+1) = z(i) + h*(x(i)*y(i)-b*z(i));
    end
    
elseif (schema == 2)  % Schéma de Runge-Kutta d'ordre 2
    for i = 1 : n
        kx1 = h*s*(y(i)-x(i));
        ky1 = h*(p*x(i)-y(i)-x(i)*z(i));
        kz1 = h*(x(i)*y(i) - b*z(i));

        kx2 = h*s*(y(i)+ky1-x(i)-kx1);
        ky2 = h*(p*(x(i)+kx1)-y(i)-ky1-(x(i)+kx1)*(z(i)+kz1));
        kz2 = h*((x(i)+kx1)*(y(i)+ky1)-b*(z(i)+kz1));

        x(i+1)=x(i)+0.5d0*(kx1+kx2);
        y(i+1)=y(i)+0.5d0*(ky1+ky2);
        z(i+1)=z(i)+0.5d0*(kz1+kz2);
        
        %x(i+1) = x(i) - h*s*(x(i)-y(i)-0.5*h*(s*(x(i)-y(i))+(p*x(i)-y(i)-x(i)*z(i))));
        %y(i+1) = y(i) + h*(p*(x(i)-0.5*h*s*(x(i)-y(i)))-y(i)-0.5*h*(p*x(i)-y(i)-x(i)*z(i))-(x(i)-0.5*h*s*(x(i)-y(i)))*(z(i)+0.5*h*(x(i)*y(i)-b*z(i))));
        %z(i+1) = z(i) + h*((x(i)-0.5*h*s*(x(i)-y(i)))*(y(i)+0.5*h*(p*x(i)-y(i)-x(i)*z(i)))-b*(z(i)+0.5*h*(x(i)*y(i)-b*z(i))));
    end
end



