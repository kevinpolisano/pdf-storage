%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%   Tests du gradient obtenu par le code adjoint                          %
%                                                                         %
%   1er test : compare les quantités : tau = (J(u+alpha*d)-J(u))/alpha    %
%                                 et delta = <dJ,d> pour plusieurs alpha  %
%   2e test : vérifie que (tau-delta)/alpha est constant quand alpha->0   %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function question8

s = 10;      % sigma
p = 2.8;     % rho
b = 8/3;     % beta
h = 0.05;    % pas de temps
nstep = 10;  % nombre d'itérations
obs_f = 1;   % fréquence d'observation
nscale = 12; % nombre de puissances testées : alpha = 10^(-k)

x = zeros(nstep+1,1);
y = zeros(nstep+1,1);
z = zeros(nstep+1,1);
alpha_vec = zeros(nscale,1);
err_vec = zeros(nscale,1);
res_vec = zeros(nscale,1);

% Initialisation
x(1) = -4.62;
y(1) = -6.61;
z(1) = 17.94;
nstep = nstep+1;

% On calcule la trajectoire en nstep points : ih
[x,y,z] = euler(nstep,h,x,y,z,s,p,b,2);

% On génère les observations à partir de celle-ci
D=zeros(nstep,1);
n_obs = (nstep-1)/obs_f + 1;
xob=zeros(n_obs,1);
yob=zeros(n_obs,1);
zob=zeros(n_obs,1);
for i = 1 : obs_f : nstep
  xob(i)=x(i);
  yob(i)=y(i);
  zob(i)=z(i);
  D(i) = 1.;
end

% On choisit un vecteur u aléatoire en lequel on va évaluer J et nabla J
u = rand(1,3);
% Tant qu'à faire on le normalise :
normu = sqrt(u(1)*u(1)+u(2)*u(2)+u(3)*u(3));
u = u/normu;

%%%%%%%%%%%%%%%%%%%%
%  Calcul de J(u)  %
%%%%%%%%%%%%%%%%%%%%

% Initialisation
x(1) = u(1);
y(1) = u(2);
z(1) = u(3);

% On calcule la trajectoire ayant pour condition initiale u
[x,y,z] = euler(nstep,h,x,y,z,s,p,b,2);

% On calcule l'écart aux observations J(u)
% et le gradient nablaJu en remontant à rebours
[Ju,nablaJu] = cost(nstep,h,x,y,z,xob,yob,zob,s,p,b,D,obs_f);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calcul de J(u+alpha*d)  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

alpha = 1;
ub = [-5;-7;17];
u0ref = [-4.62;-6.61;17.94];
d = ub-u0ref;

 % On va ensuite calculer la variation de J perturbée de alpha = 10^(-k)
 % dans la direction d = u_b - u_0ref, c'est-à-dire J(u + alpha*d)
 % et comparer (J(u+alpha*d)-J(u))/alpha à < nablaJu, d >
 for k = 1 : nscale
     
      % u + alpha*d
      ud1 = u(1) + alpha*d(1);
      ud2 = u(2) + alpha*d(2);
      ud3 = u(3) + alpha*d(3);
      
      % Calcul de la trajectoire ayant pour condition initiale u+alpha*d
      [x,y,z] = euler(nstep,h,ud1,ud2,ud3,s,p,b,2);
      
      % Calcul de J(u + alpha*d)
      [Jud,nablaJud] = cost(nstep,h,x,y,z,xob,yob,zob,s,p,b,D,obs_f);

      % Calcul de delta = < nablaJu , d >
      delta(k) = nablaJu(1)*d(1)+nablaJu(2)*d(2)+nablaJu(3)*d(3);
      
      % Calcul de tau = (J(u+alpha*d)-J(u))/alpha
      tau(k) = (Jud - Ju)/alpha;
      
      % Calcul de l'erreur relative e = |tau - delta|/delta
      e = abs((tau(k)-delta(k))/delta(k));
      
      % On stocke le résultat
      alpha_vec(k) = alpha;
      err_vec(k) = e;
      res_vec(k) = (tau(k) - delta(k))/alpha;
      
      alpha = alpha * 0.1;
 end
 
% On trace sur le même graphique tau et delta
figure;
semilogx(alpha_vec,tau,'ro');
hold on
semilogx(alpha_vec,delta);
xlabel('\alpha')
legend('tau (gradient approche)','delta (gradient adjoint)')

% On trace l'erreur relative en fonction de alpha
figure;
semilogx(alpha_vec,err_vec);
title('Test du gradient au premier ordre')
xlabel('\alpha')
ylabel('\epsilon')

% On trace le résidu en fonction de alpha
figure;
semilogx(alpha_vec,res_vec);
title('Test du gradient au second ordre')
xlabel('\alpha')
ylabel('r')


