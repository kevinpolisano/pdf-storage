%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%  Assimilation de données par filtre de Kalman                           %
%                                                                         %
%  Equations de Lorenz :                                                  %
%                                                                         %
%  x' = -s(x-y)                                                           %
%  y' = px - y - xz                                                       %
%  z' = xy - bz                                                           %
%                                                                         %
%  Vraie condition initiale : u_0ref = (x0,y0,z0) = (-4.62,-6.61,17.94)   %
%  Ebauche initiale : u_0b = (x0b,y0b,z0b) = (-5,-7,17)                   %
%  Observations (générées à partir de u_0ref) :                           %
%  u_obs(ti) = (x(ti),y(ti),z(ti))                                        %
%                                                                         %
%  Objectif : A partir de l'ébauche u_0b et des observations u_obs(ti)    %
%             Déterminer l'analyse u_a approchant la solution exacte uref %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function question9;

%%%%%%%%%%%%%%%%
%  Paramètres  %
%%%%%%%%%%%%%%%%

s = 10;              % sigma
p = 28;              % rho
b = 8/3;             % beta
tfinal = 600;        % temps de simulation total
tassim = tfinal/2;   % temps d'assimilation
ob_step = 1;         % intervalle de temps entre 2 observations
var = 1;             % variance du bruit perturbant les observations
h = 0.05;            % pas de temps du schéma numérique
schema = 2;          % schéma numérique utilisé 
                     %      1 : Euler (prendre h petit)
                     %      2 : Runge-Kutta d'ordre 2
graphe = 3;          % graphique affiché 
                     %      1 : Vraie solution u_ref
                     %      2 : u_ref + Solution ébauche u_b
                     %      3 : u_ref + u_b + Analyse u_a
                

% Conditions initiales
u_0ref = [-4.62,-6.61,17.94];
u_0b = [-5,-7,17]; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calcul de la vraie solution uref = (x,y,z) %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x = zeros(tfinal,1);
y = zeros(tfinal,1);
z = zeros(tfinal,1);

% Initialisée à u_0ref
x(1) = u_0ref(1);
y(1) = u_0ref(2);
z(1) = u_0ref(3);

if (schema == 1)           % Schéma d'Euler
    for i = 1 : tfinal-1
       x(i+1) = x(i) - h*s*(x(i)-y(i));
       y(i+1) = y(i) + h*(p*x(i)-y(i)-x(i)*z(i));
       z(i+1) = z(i) + h*(x(i)*y(i)-b*z(i));
    end
    
elseif (schema == 2)       % Schéma de Runge-Kutta d'ordre 2
    for i = 1 : tfinal-1
        x(i+1) = x(i) - h*s*(x(i)-y(i)-0.5*h*(s*(x(i)-y(i)) ...
                 +(p*x(i)-y(i)-x(i)*z(i))));
        y(i+1) = y(i) + h*(p*(x(i)-0.5*h*s*(x(i)-y(i)))-y(i) ...
                 -0.5*h*(p*x(i)-y(i)-x(i)*z(i))-(x(i)-0.5*h*s ... 
                 *(x(i)-y(i)))*(z(i)+0.5*h*(x(i)*y(i)-b*z(i))));
        z(i+1) = z(i) + h*((x(i)-0.5*h*s*(x(i)-y(i))) ...
                 *(y(i)+0.5*h*(p*x(i)-y(i)-x(i)*z(i))) ...
                 -b*(z(i)+0.5*h*(x(i)*y(i)-b*z(i))));
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calcul de la solution u_b  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xb = zeros(tfinal,1);
yb = zeros(tfinal,1);
zb = zeros(tfinal,1);

% Initialisée à u_0b (seul élément qui change par rapport à ce qui précède)
xb(1) = u_0b(1);
yb(1) = u_0b(2);
zb(1) = u_0b(3);

if (schema == 1)      % Schéma d'Euler
    for i = 1 : tfinal-1
       xb(i+1) = xb(i) - h*s*(xb(i)-yb(i));
       yb(i+1) = yb(i) + h*(p*xb(i)-yb(i)-xb(i)*zb(i));
       zb(i+1) = zb(i) + h*(xb(i)*yb(i)-b*zb(i));
    end
    
elseif (schema == 2)  % Schéma de Runge-Kutta d'ordre 2
    for i = 1 : tfinal-1
        xb(i+1) = xb(i) - h*s*(xb(i)-yb(i)-0.5*h*(s*(xb(i)-yb(i)) ...
                  +(p*xb(i)-yb(i)-xb(i)*zb(i))));
        yb(i+1) = yb(i) + h*(p*(xb(i)-0.5*h*s*(xb(i)-yb(i)))-yb(i) ...
                  -0.5*h*(p*xb(i)-yb(i)-xb(i)*zb(i))-(xb(i)-0.5*h*s ...
                  *(xb(i)-yb(i)))*(zb(i)+0.5*h*(xb(i)*yb(i)-b*zb(i))));
        zb(i+1) = zb(i) + h*((xb(i)-0.5*h*s*(xb(i)-yb(i))) ...
                  *(yb(i)+0.5*h*(p*xb(i)-yb(i)-xb(i)*zb(i))) ...
                  -b*(zb(i)+0.5*h*(xb(i)*yb(i)-b*zb(i))));
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Génération des observations  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tassim = tassim+ob_step;  %  Durée d'assimilation

xob = zeros(tassim,1);
yob = zeros(tassim,1);
zob = zeros(tassim,1);

nobs = floor(tassim/ob_step); %  Nombre d'observations sur tassim
tobs = 1 : ob_step : tassim;  %  Dates d'observations

% On génère un bruit gaussien de variance var
std = sqrt(var);
bruitx = std*randn(nobs+1,1);
bruity = std*randn(nobs+1,1);
bruitz = std*randn(nobs+1,1);

% Le vecteur d'observation est nul sauf aux temps d'observations tobs
j = 1;
for i = tobs
    xob(i) = x(i) + bruitx(j);
    yob(i) = y(i) + bruity(j);
    zob(i) = z(i) + bruitz(j);
    j = j+1;
end

% Matrices d'erreurs d'observations
R = zeros(3,3,tfinal);   
for i = 1 : tfinal
    R(:,:,i) = var*eye(3);
end

%%%%%%%%%%%%%%%%%%%%%%
%  Filtre de Kalman  %
%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%
%  Initialisation  %
%  ua(0) = ub      %
%  Pa(0) = I       %
%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Etape k (prévision - correction)                                       %
%                                                                         %
%  uf(k+1) = Mk*ua(k)                           (KF1) schéma numérique    %
%  Pf(k+1) = Mkl*Pa(k)*Mkl^t+Q(k)               (KF2) Mkl matrice tangent %
%  K(k+1)  = Pf(k+1)*(Pf(k+1)+R(k+1))^(-1)      (KF3)                     %
%                                                                         %
%  ua(k+1) = uf(k+1)+K(k+1)*(uobs(k+1)-uf(k+1)) (KF4)                     %
%  Pa(k+1) = Pf(k+1)-K(k+1)Pf(k+1)              (KF5)                     %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% On réserve la place des structures en mémoire
xf = zeros(tfinal);
yf = zeros(tfinal);
zf = zeros(tfinal);
ua = zeros(3,tfinal);
uf = zeros(3,tfinal);        
K = zeros(3,3,tfinal);       % matrice de gain
Pf = zeros(3,3,tfinal);      % matrice de covariance forecast
Pa = zeros(3,3,tfinal);      % matrice de covariance analyse
Ml = zeros(3,3,tfinal);      % matrice linéaire tangente
Q = zeros(3,3,tfinal);       % Q = 0 car modèle supposé parfait

% --- Initialisation --- %

% On part de l'ébauche
xf(1) = xb(1);     
yf(1) = yb(1);
zf(1) = zb(1);
uf(:,1) = [xf(1);yf(1);zf(1)]; % notation vecteur pour opération matrices
x_ob=[xob';yob';zob'];

% Initialisation de la matrice de covariance d'erreur Pf à l'identité
Pf(:,:,1) = eye(3); 

ua(:,1) = uf(:,1); 

% Initialisation de la matrice de gain
K(:,:,1) = Pf(:,:,1)*pinv(Pf(:,:,1)+R(:,:,1));  

% Initialisation de la matrice de covariance Pa
Pa(:,:,1) = (eye(3,3)-K(:,:,1))*Pf(:,:,1);   

% --- Itérations du filtrage --- %
for k = 1 : tfinal-1
    % Si la période d'assimilation est terminée on n'a plus d'observations
    if k >= tassim
        x_ob(:,k+1)=0;
    end
    
    % On récupère l'analyse précédente ua
    xf(k) = ua(1,k);
    yf(k) = ua(2,k);
    zf(k) = ua(3,k);
    
    % On met à jour xf(k+1) ------------------------------- (KF1)
    if (schema == 1)      % Schéma d'Euler
       xf(k+1) = xf(k) - h*s*(xf(k)-yf(k));
       yf(k+1) = yf(k) + h*(p*xf(k)-yf(k)-xf(k)*zf(k));
       zf(k+1) = zf(k) + h*(xf(k)*yf(k)-b*zf(k));
    elseif (schema == 2)  % Schéma de Runge-Kutta d'ordre 2
        xf(k+1) = xf(k) - h*s*(xf(k)-yf(k)-0.5*h*(s*(xf(k)-yf(k)) ...
                  +(p*xf(k)-yf(k)-xf(k)*zf(k))));
        yf(k+1) = yf(k) + h*(p*(xf(k)-0.5*h*s*(xf(k)-yf(k)))-yf(k) ...
                  -0.5*h*(p*xf(k)-yf(k)-xf(k)*zf(k))-(xf(k)-0.5*h*s ... 
                  *(xf(k)-yf(k)))*(zf(k)+0.5*h*(xf(k)*yf(k)-b*zf(k))));
        zf(k+1) = zf(k) + h*((xf(k)-0.5*h*s*(xf(k)-yf(k))) ...
                  *(yf(k)+0.5*h*(p*xf(k)-yf(k)-xf(k)*zf(k))) ...
                  -b*(zf(k)+0.5*h*(xf(k)*yf(k)-b*zf(k))));
    end
    
    % Et on stocke les résultats dans un vecteur
    uf(:,k+1)=[xf(k+1);yf(k+1);zf(k+1)];
    
    % On met à jour Pf(k+1) ------------------------------- (KF2)
    
    % On commence par calculer la matrice tangente linéaire Ml(k)
    Ml(1,1,k)=1.0-(h*s)+(((h*h*s)/2.0)*(p+s-zf(k)));
    Ml(1,2,k)=h*s-(((h*h*s)/2.0)*(1.0+s));
    Ml(1,3,k)=-(h*h*s*xf(k))/2.0;
    Ml(2,1,k)=(h*(p-zf(k)))+(((h*h)/2.0)*(zf(k)-(p*s)-p+(b*zf(k))...
    +(s*zf(k))-(2.0*xf(k)*yf(k))))+(((h*h*h*s)/2.0)*((b*zf(k))-...
    (yf(k)*yf(k))+(2.0*xf(k)*yf(k))));
    Ml(2,2,k)=1.0-h+(((h*h)/2.0)*((s*p)+1.0-(xf(k)*xf(k))-(s*zf(k))))...
    +(((h*h*h*s)/2.0)*((b*zf(k))-(2.0*xf(k)*yf(k))+(xf(k)*xf(k))));
    Ml(2,3,k)=(-h*xf(k))+(((h*h)/2.0)*(xf(k)+(b*xf(k))-(s*yf(k))+...
    (s*xf(k))))+(((h*h*h*s*b)/2.0)*(yf(k)+xf(k)));
    Ml(3,1,k)=(h*yf(k))+(((h*h)/2.0)*((2.0*p*xf(k))-yf(k)-(2.0*xf(k)...
    *zf(k))-(s*yf(k))-(b*yf(k))))+(((h*h*h*s)/2.0)*((p*yf(k))-(yf(k)...
    *zf(k))-(2.0*p*xf(k))+yf(k)+(2.0*xf(k)*zf(k))));
    Ml(3,2,k)=(h*xf(k))+(((h*h)/2.0)*((s*yf(k))-xf(k)-(s*xf(k))-...
    (b*xf(k))))+(((h*h*h*s)/2.0)*((p*xf(k))-(2.0*yf(k))-(xf(k)*zf(k))...
    +xf(k)));
    Ml(3,3,k)=1.0-(h*b)+(((h*h)/2.0)*((b*b)-(xf(k)*xf(k))))+...
    (((h*h*h*s)/2.0)*((xf(k)*xf(k))-(xf(k)*yf(k))));

    Pf(:,:,k+1) = Ml(:,:,k)*Pa(:,:,k)*Ml(:,:,k)'+Q(:,:,k); %(KF2)

    % Si il y a des observations à la date t_k
    if x_ob(:,k+1) ~= 0 
        
        % On met à jour K(k+1) ---------------------------- (KF3)
        K(:,:,k+1) = Pf(:,:,k+1)*pinv(Pf(:,:,k+1)+R(:,:,k+1));
        
        % On calcule l'analyse xa(k+1) -------------------- (KF4)
        ua(:,k+1) = uf(:,k+1)+K(:,:,k+1)*(x_ob(:,k+1)-uf(:,k+1));
        
        % On calcule la matrice de covariance d'analyse Pa  (KF5)
        Pa(:,:,k+1) = (eye(3,3)-K(:,:,k+1))*Pf(:,:,k+1);
    else
        % Sinon on recopie simplement
        ua(:,k+1) = uf(:,k+1);
        Pa(:,:,k+1) = Pf(:,:,k+1);
    end
    
end % fin de la boucle d'itérations

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  On trace les courbes obtenus  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (graphe >= 1)
    t = 0:h:tfinal*h-h;
    subplot(221)
    plot(t,x)
    if (graphe >= 2)
        hold on
        plot(t,xb,'k')
        plot(h*(tobs(2:nobs)-1),xob(tobs(2:nobs)),'g*');
        if (graphe == 3)
            plot(t,ua(1,:),'r');
        end
    end
    xlabel('temps (ms)');
    ylabel('x');

    subplot(222)
    plot(t,y,'b')
    if (graphe >= 2)
        hold on
        plot(t,yb,'k')
        plot(h*(tobs(2:nobs)-1),yob(tobs(2:nobs)),'g*');
        if (graphe == 3)
            plot(t,ua(2,:),'r');
        end
    end
    xlabel('temps (ms)');
    ylabel('y');

    subplot(223)
    plot(t,z,'b')
    if (graphe >= 2)
        hold on
        plot(t,zb,'k')
        plot(h*(tobs(2:nobs)-1),zob(tobs(2:nobs)),'g*');
        if (graphe == 3)
            plot(t,ua(3,:),'r');
        end
    end
    xlabel('temps (ms)');
    ylabel('z');

    subplot(224)
    plot(x,z,'b')
    if (graphe >= 2)
        hold on
        plot(xb,zb,'k')
        plot(xob(tobs(2:nobs)),zob(tobs(2:nobs)),'g*');
    end
    if (graphe == 3)
       plot(ua(1,:),ua(3,:),'r')
    end
    xlabel('x');
    ylabel('z');
    title('Plan de phase xz');
end
    
end

    
    
    











