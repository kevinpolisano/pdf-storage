#include "pointsToSurface.h"
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <fstream> // pour la lecture de fichier version C++
#include <cfloat> // pour le DBL_MAX
#include <stack> // pour la pile de traitement des noeuds de _acm

// mode automatique
#define AUTO 1

// mode manuel (AUTO � 0)
#define NB_VOISINS 250
#define LISSAGE 0.03
#define PAS 70
#define ISO_VAL 0
#define MARGE 0.2

using namespace std;

PointsToSurface::PointsToSurface(const QString &filename) : _acm(0) {
  if(!readInputFile(filename)) {
    cout << "Error while loading" << filename.toStdString() << endl;
    exit(0);
  }
}

PointsToSurface::~PointsToSurface() {
  _points.clear();
}

void PointsToSurface::computeNonOrientedNormals() {
  unsigned int k = nbVoisins;
  // pour tous les points de l'espace
  for(unsigned int i=0;i<_points.size();++i) {
    // 1. on d�termine les k-voisins
    v_Point3D pts = kneighborhoodPoints(_points[i],_points,k);
    // 2. on d�termine le barycentre B des points de pts
    Point3D B(0,0,0);
    for (unsigned int j=0;j<k;++j) {
      B += pts[j];
    }
    B /= pts.size();
    // 3. On forme la liste des points pts-B
    for (unsigned int j=0;j<k;++j) {
      pts[j] -= B;
    }
    // On cr�� la matrice M 3x3
    double M[3][3];
    for (unsigned int ii=0;ii<3;ii++) {
      for (unsigned int jj=ii;jj<3;jj++) {
	M[ii][jj] = 0;
	for (unsigned int kk=0;kk<k;kk++) {
	  double temp[3];
	  temp[0] = pts[kk].x;
	  temp[1] = pts[kk].y;
	  temp[2] = pts[kk].z;
	  M[ii][jj] += temp[ii]*temp[jj];
	}
      }
    }
    // on calcule le rep�re local associ�
    Point3D u(0,0,0);
    Point3D v(0,0,0);
    Point3D n(0,0,0);
      
    calcul_repere_vecteurs_propres(M[0][0],M[0][1],M[0][2],
				   M[1][1],M[1][2],M[2][2],
				   u,v,n);
    // on ajoute la normale � la liste
    _noNormals.push_back(n);
  }
}

void PointsToSurface::computeMinimalSpanningTree() {
  unsigned int nbNoeuds = _points.size();
  Graphe * G = new Graphe(nbNoeuds); // graphe de proximit�
  double r = 2*_maxDist; // rayon de recherche des voisins
  double d = 0; // distance entre pi et pj
  double v = 0; // valuation de l'arr�te (i,j) = 1 - |<ni,nj>|
  for (unsigned int i=0;i<_points.size()-1;i++) {
    for (unsigned int j=i+1;j<_points.size();j++) {
      d = distance_(_points[i],_points[j]);
      if (d <= r) {
       	v = 1 - produit_scalaire(_noNormals[i],_noNormals[j]);
       	G->ajouter_arc(i,j,v);
      }
    }
  }
  _acm = G->arbre_couvrant_minimal();
}

l_int PointsToSurface::noeudsVoisins(unsigned int i) {
  l_int la = _acm.noeud(i).la; // liste des arretes partant du noeud i
  l_int voisins;
  Arc arcCourant;
  unsigned int n1,n2;
  // on parcourt les arretes
  for (list<unsigned int>::iterator it = la.begin(); it != la.end();++it) {
    arcCourant = _acm.arcs()[*it];
    n1 = arcCourant.n1;
    n2 = arcCourant.n2;
    if (i == n1)
      voisins.push_back(n2);
    else
      voisins.push_back(n1);
  }
  return voisins;
}

void PointsToSurface::computeOrientedNormals() {
  _oNormals =_noNormals;
  unsigned int nbNoeuds = _acm.noeuds().size(); // nombre de noeuds dans _acm
  stack<size_t> pile;                           // noeuds � traiter
  vector<bool> fait(nbNoeuds, false);           // noeuds trait�s

  // on commence par traiter le noeud 0
  pile.push(0);
  fait[0] = true;

  // pour chaque noeud non trait�
  while (!pile.empty())
    {
      // on r�cup�re le premier de la pile
      const size_t i = pile.top();
      pile.pop();

      // on r�cup�re ses voisins
      l_int voisins = noeudsVoisins(i);
      // on r�cup�re la normale au point correspondant au noeud trait�
      const Point3D & N = _oNormals[i];

      // on ajoute les voisins � la pile des sommets � traiter.
      for (list<unsigned int>::iterator it = voisins.begin(); 
	   it != voisins.end();++it) {
	  const size_t voisinCour = *it;
	  // s'il n'est pas d�j� trait�
	  if (!fait[voisinCour]) {
	      // on l'ajoute
	      pile.push(voisinCour);
	      fait[voisinCour] = true;
	      // si la normale associ�e est invers�e, on la retourne.
	      Point3D &Nv = _oNormals[voisinCour];  
	      if (produit_scalaire(N, Nv) < 0)
		Nv *= -1;
	    }
	}
    }
}

double PointsToSurface::computeImplicitFunc(double x,double y,double z) {
  double resultat = 0;
  double poidsTotal = 0;
  double sigma = coefLissage;
  double xi,yi,zi,nx,ny,nz,wi;
  // on parcourt tous les points et on forme P-Pi = (xi,yi,zi)
  // et les normales aux points parcourus sont not�es ni = (nx,ny,nz)
  for (unsigned int i=0;i<_points.size();i++) {
    xi = x - _points[i].x;
    yi = y - _points[i].y;
    zi = z - _points[i].z;
    nx = _oNormals[i].x;
    ny = _oNormals[i].y;
    nz = _oNormals[i].z;
    wi = exp(-(xi*xi+yi*yi+zi*zi)/(sigma*sigma));
    poidsTotal += wi;
    resultat += (nx*xi+ny*yi+nz*zi)*wi;
  }
  return resultat/poidsTotal;
}

void PointsToSurface::afficheTriangles(v_Triangle3D & V) {
  for (unsigned int i=0;i<V.size();i++) {
    cout <<"{ "<< V[i].S0 <<" ; "<<V[i].S1<<" ; "<< V[i].S2<<" }"<<endl;
  }
}

void PointsToSurface::computeNormalsFromImplicitFunc() {
  double e = 0.01;
  double xi,yi,zi,nx,ny,nz;
  // on parcourt tous les points de la SURFACE (donc les triangles)
  for (unsigned int i=0;i<_surfacep.size();i++) {
    // pour chaque triangle on r�cup�re les trois points
    v_Point3D face;
    face.push_back(_surfacep[i].S0);
    face.push_back(_surfacep[i].S1);
    face.push_back(_surfacep[i].S2);
    // on reforme un triangle dont les points sont les nouvelles normales
    Triangle3D normales;
    for (unsigned int j=0;j<face.size();j++) {
      xi = face[j].x;
      yi = face[j].y;
      zi = face[j].z;
      // calcul des nouvelles normales via le gradient de la fct implicite
      nx = computeImplicitFunc(xi-e,yi,zi)-computeImplicitFunc(xi+e,yi,zi);
      ny = computeImplicitFunc(xi,yi-e,zi)-computeImplicitFunc(xi,yi+e,zi);
      nz = computeImplicitFunc(xi,yi,zi-e)-computeImplicitFunc(xi,yi,zi+e);
      Point3D Pn = normalise(Point3D(nx,ny,nz));
      if (j == 0) {
	normales.S0 = Pn;
      } else if (j == 1) {
	normales.S1 = Pn;
      } else {
	normales.S2 = Pn;
      }	  
    }
    // on ajoute le triangle � _surfacen
    _surfacen.push_back(normales);
  }
}

void PointsToSurface::computeMesh() {
  // cr�ation de la grille 3D
  Point3D pmin = _boundingBox[0];
  Point3D pmax = _boundingBox[1];
  double m = margeBoundingBox; // marge
  double x_min = pmin.x-m, y_min = pmin.y-m, z_min = pmin.z-m; 
  double x_max = pmax.x+m, y_max = pmax.y+m, z_max = pmax.z+m;
  unsigned int nx = padx;
  unsigned int ny = pady;
  unsigned int nz = padz;
  Grille3D grille = Grille3D(x_min,y_min,z_min,
			     x_max,y_max,z_max,
			     nx,ny,nz);

  // cr�ation du tableau vf de la fonction aux sommets de la grille
  //  vf[i+DIM_X*(j+DIM_Y*k)] = f(G.x(i),G.y(j),G.z(k))
  unsigned int DIM_X = nx+1, DIM_Y = ny+1, DIM_Z = nz+1;
  double * vf = new double[DIM_X*DIM_Y*DIM_Z];
  bool * ind = new bool[DIM_X*DIM_Y*DIM_Z];
  for (unsigned int i=0; i<nx; i++) {
      for (unsigned int j=0; j<ny; j++) {
	  for (unsigned int k=0; k<nz; k++) {
	    vf[i+DIM_X*(j+DIM_Y*k)] = computeImplicitFunc(grille.x(i),
							  grille.y(j),
							  grille.z(k));
	    ind[i+DIM_X*(j+DIM_Y*k)] = true;
	    // pour exclure les bords de la bounding box
	    if ((i == nx-1) || (j == ny-1) || (k == nz-1)) {
	      ind[i+DIM_X*(j+DIM_Y*k)] = false;
	     }

	  }
      }
  }

  // cr�ation des t�tra�dres via isovaleur de la fonction implicite 3D
  double iso_val = isoValeur;
  SurfaceIsovaleurGrille S = SurfaceIsovaleurGrille();
  S.surface_isovaleur(_surfacep,grille,vf,iso_val,ind);
  // afficheTriangles(_surfacep);
}

void PointsToSurface::computeSurface() {
  // appelle toutes les fonctions pour reconstruire la surface 
  cout << "computing non-oriented normals..." << endl;
  computeNonOrientedNormals();
  cout << "computing minimal spanning tree..." << endl;
  computeMinimalSpanningTree();
  cout << "computing oriented normals..." << endl;
  computeOrientedNormals();
  cout << "computing mesh surface..." << endl;
  computeMesh();
  cout << "computing final normals..." << endl;
  computeNormalsFromImplicitFunc();
}

v_Point3D  PointsToSurface::kneighborhoodPoints(const Point3D &p,const v_Point3D &pts,unsigned int k) const {

  v_Point3D neighbors;

  if(k==0) return neighbors;

  if(pts.size()<k) k=pts.size();
  neighbors.resize(k);
  
  std::vector<double> dist(pts.size());
  unsigned int imax = 0;

  for(unsigned int i=0;i<pts.size();++i) {
    dist[i]=distance_(p,pts[i]);
    
    if(dist[i]>dist[imax]) 
      imax=i;
  }


  for(unsigned int i=0;i<k;++i) {
    unsigned int index=0;
    
    // calcule l'index de la distance minimale � p
    for(unsigned int j=0;j<pts.size();++j) {
      if(dist[j]<dist[index]) 
	index=j;
    }

    neighbors[i]=pts[index];
    dist[index] = dist[imax]+1; // pour que cet index ne soit plus pris
  }

  return neighbors;
}

bool PointsToSurface::readInputFile(const QString &filename) {

  _points.clear();
  
  unsigned int nS;
  double r, xx, yy, zz;
 
  std::string str = filename.toStdString();
  const char * name = filename.toStdString().c_str();
  std::ifstream file(name);
  cout << "Lecture du fichier " << str << "..." << endl;
  file >> nS;
  file >> r;
  _points.resize(nS);
  for (unsigned int i = 0; i < nS; i++)
    {
      file >> xx;
      file >> yy;
      file >> zz;
      if (file.good() || file.eof()) {
	_points[i].x = xx;
	_points[i].y = yy;
	_points[i].z = zz;
      }
    }
  
  boite_englobante(_points,_boundingBox[0],_boundingBox[1]);

  // mean of the min distance between 2 points
  _meanDist = 0.0;
  _maxDist = DBL_MIN;
  double temp = 0;
  for(unsigned int i=0;i<_points.size();++i) {
    v_Point3D pts = kneighborhoodPoints(_points[i],_points,2);
    temp = distance_(pts[0],pts[1]);
    _meanDist = _meanDist+temp;
    if (temp > _maxDist)
      _maxDist = temp;
  }
  _meanDist = _meanDist/(double)_points.size();

  // fermeture du fichier
  file.close();
  cout << "Chargement des donnees termine..." << endl;

  // D�termination des param�tres ad�quats en fonction des donn�es entr�es
  std::string data1 = "data/donnees1.160.pno.txt";
  std::string data2 = "data/donnees2.1242.pno.txt";
  std::string data3 = "data/donnees3.1682.pno.txt";
  std::string cactus = "data/cactus.3337.pts.txt";
  std::string club = "data/club71.16864.pts.txt";
  std::string cat = "data/cat10.10000.pts.txt";
  std::string mannequin = "data/mannequin.12772.pts.txt";
  std::string selle = "data/selle.441.pts.txt";

  // Mode automatique, param�tres optimals relatifs � chaque fichier
  if (AUTO) {
    // par d�faut
    nbVoisins = 5;
    isoValeur = 0;
    coefLissage = 0.4;
    margeBoundingBox = 0.2;
    padx = 20;
    pady = 20;
    padz = 20;
    // personnalis�s
    if ((str == data1) || (str == data2) || (str == data3) || (str == selle))
      {
      coefLissage = 0.3;
      margeBoundingBox = 0.5;
      padx = 50;
      pady = 50;
      padz = 50;
    } else if (str == club) {
      nbVoisins = 12;
      coefLissage = 0.1;
      margeBoundingBox = 0.15;
    } else if (str == cactus) {
      nbVoisins = 50;
      coefLissage = 0.05;
      margeBoundingBox = 0.2;
    } else if ((str == mannequin) || (str == cat)) { //!\\ BUG, mettre la
      nbVoisins = 250;                                //variable center (0,0,0)
      coefLissage = 0.03;
      margeBoundingBox = 0.2;
      padx = 70;
      pady = 70;
      padz = 70;
    } 
  } else { // Mode manuel, les param�tres sont initialis�s dans les #define
     coefLissage = LISSAGE;
     margeBoundingBox = MARGE;
     nbVoisins = NB_VOISINS;
     isoValeur = ISO_VAL;
     padx = PAS;
     pady = PAS;
     padz = PAS;
  }
  
  afficheParam(str);
	
  return true;
}

void PointsToSurface::afficheParam(std::string name) {

  cout << 
    "Les parametres utilises pour les donnees " << name << " sont :" << endl
       << 
    "   - coefLissage = " << coefLissage << endl
       <<
    "   - nbVoisins = " << nbVoisins << endl
       <<
    "   - margeBoundingBox = " << margeBoundingBox << endl
       <<
    "   - isoValeur = " << isoValeur << endl
       <<
    "   - padx = " << padx << endl
       <<
    "   - pady = " << pady << endl
       <<
    "   - padz = " << padz << endl;
}


