#include "Image.h"

using namespace std;

//Dialogue debug=Dialogue(true);
//Dialogue talk=Dialogue(true);
ostream & debug=cout;
ostream & talk=cout;
////////////////////////////////////////////////////////////////////////////////////
// Constructs
	
Image::Image(unsigned int const col,unsigned int const lig):numcols(col),numrows(lig),vmax(1),name("defaut.pgm"),buffer(col*lig,0)
{}
Image::Image(unsigned int const col,unsigned int const lig,unsigned int max):numcols(col),numrows(lig),vmax(max),name("defaut.pgm"),buffer(col*lig,0)
{}
Image::Image(unsigned int const col,unsigned int const lig,unsigned int max, string nom):numcols(col),numrows(lig),vmax(max),name(nom),buffer(col*lig,0)
{}

//TODO handle comments
Image::Image(string filename):name(filename)
{	
	const char* truc = filename.c_str();
  ifstream file(truc);
	
  string inputLine = "";

  /*
    Methode de lecture d'un fichier:
    Ligne par ligne en utilisant getline().
    Mot par mot en utilisant les chevrons >>.
    Caract�re par caract�re en utilisant get().
  */
	
  getline(file,inputLine);
  /*
  if(inputLine.compare("P2") != 0) cerr << "Version error" << endl;
  else talk << "Version : " << inputLine << endl; */

  getline(file,inputLine);
  //talk << "Comment : " << inputLine << endl;
	
  file >> numcols >> numrows >> vmax;
  //talk << numcols << " colonnes et " << numrows << " lignes" << endl << "valeur max:" << vmax << endl;

  unsigned int j=0;
  for(unsigned int i = 0; i < numrows*numcols; i++)
    {	file >> j;
      assert(j<=vmax);
      buffer.push_back(j);
      //debug << buffer[i];
    }
		
  //debug <<endl << "creation du buffer OK" << endl;

  file.close();
		
  //debug << "lecture du fichier OK" <<endl;
	
}

Image::~Image(void){}

////////////////////////////////////////////////////////////////////////////////////
// Getter

//get (3,5)
const int& Image::at(unsigned int col,unsigned int lig) const
{	assert(col<numcols);
  assert(lig<numrows);
  return buffer[lig*numcols+col];
}
unsigned int Image::getNumcols()const 
{	return numcols;}
unsigned int Image::getNumrows()const 
{	return numrows;}
unsigned int Image::getVmax()const 
{	return vmax;}
string Image::getName()const 
{	return name;}

vector<int> Image::getBuffer()const
{	return buffer;}

vector<int> Image::getVoisin(int n, int x,int y)
{
vector<int> truc;
n=n/2;

for(int i=-n;i<=n;i++)
	for(int j=-n;j<=n;j++)
		truc.push_back(at(x+i,y+j));
return truc;
}

int Image::getNbComp() const {
  return composantes.size();
}

vector<int> Image::getComp() const {
  return composantes;
}

const int& Image::at(unsigned int i) const
{	
  return buffer[i];
}

vector<int> Image::getVoisin(Image masque,unsigned int x,unsigned int y)
{
	int my = masque.getNumrows();
	int mx = masque.getNumcols();
	assert(mx%2==1);
	assert(my%2==1);
	assert(x<numcols);
	assert(y<numrows);
	vector<int> truc;
	unsigned int k=0,l=0;
	for(int i=-mx/2;i<=mx/2;i++)
	{	for(int j=-my/2;j<=my/2;j++)
		{  
			if(masque(k,l)  && x+i<numcols && y+j<numrows)
				truc.push_back(at(x+i,y+j));
			l++;
		}
		l=0;
		k++;
	}
	
	return truc;
	
}
////////////////////////////////////////////////////////////////////////////////////
// Setter

//allow this.at(3,5)=3
int& Image::at(unsigned int col,unsigned int lig)
{	assert(col<numcols);
  assert(lig<numrows);
  return buffer[lig*numcols+col];
}
void Image::setVmax(unsigned int i)
{ vmax=i;}

int& Image::at(unsigned int i)
{	
  return buffer[i];
}

////////////////////////////////////////////////////////////////////////////////////
// Surcharge operateur

//call at
 int &Image::operator()(unsigned int col,unsigned int lig)
{	return this->at(col,lig);	
}
//call const at
int const &Image::operator()(unsigned int col,unsigned int lig)const
{	return this->at(col,lig);	
}

std::ostream& operator<<( std::ostream &flux, Image & img )
{
  img.afficher(flux);
  return flux;
}
//TODO definir le =
void Image::operator*= (Image masque)
{
  Image img = Image(numcols,numrows);
  int n = masque.getNumcols();
  debug << n << " | " << -n/2 << endl;
  assert((unsigned int)n==masque.getNumrows());
  assert(n%2==1);
  for(unsigned int i=n/2; i<numcols-n/2;i++)
    for(unsigned int j=n/2; j<numrows-n/2;j++)	
      {	debug <<"("<< i <<","<<j <<"):";
	for(int k=-n/2;k<=n/2;k++)
	  {	for(int l=-n/2;l<=n/2;l++)
	      {
		//cout <<"("<< k <<","<< l <<"):"; 
		img(i,j)+= masque(k+n/2,l+n/2)*at(i+k,j+l);
		debug << masque(k+n/2,l+n/2) << " | ";
	      }
	  }
	debug << at(i,j) << "," << img(i,j) <<endl;
      }
					  
  buffer= img.getBuffer();
  vmax=vmax*masque.getVmax();
}
int &Image::operator[](unsigned int i)
{	return this->at(i);	
}
//call const at
int const &Image::operator[](unsigned int i)const
{	return this->at(i);}	
////////////////////////////////////////////////////////////////////////////////////
// Tool

void Image::afficher(std::ostream &flux)
{
  flux << "P2" << endl << "#" << name << endl << numrows << " " <<numcols << endl << vmax << endl;
  for(unsigned int lig = 0; lig < numrows; lig++)
    {for (unsigned int col = 0; col < numcols; col++) 
	flux << at(col,lig) <<" ";
      flux <<endl;
    }
}
void Image::save(string filename)
{
  name=filename;
  const char* truc = filename.c_str();
  ofstream myfile (truc);
  if (myfile.is_open())
    {	
      myfile << *this;
      myfile.close();
      // debug << "Sauvegarde du fichier " << filename << " OK" << endl;
    }
  else cout << "Unable to open file";
}
void Image::save()
{save(name);}


void Image::addm(Image &masque)
{
	//cout << "addm" << endl;
	vector<int> buffertemp=buffer;
	vector<int> voisin;
	for(unsigned int i=0;i<buffertemp.size();i++)
	{
		voisin=getVoisin(masque,i%numcols,i/numcols);
		sort(voisin.begin(),voisin.end());
		buffertemp[i]=voisin[voisin.size()-1];
	}
	buffer=buffertemp;
}

void Image::subm(Image &masque)
{	
	//cout << "subm" << endl;
	vector<int> buffertemp = buffer;
	vector<int> voisin;
	for(unsigned int i=0;i<buffertemp.size();i++)
	{	voisin=getVoisin(masque,i%numcols,i/numcols);
		sort(voisin.begin(),voisin.end());
		buffertemp[i]=voisin[0];
	}
	buffer=buffertemp;
}

void Image::sub(Image &img)
{
	//cout << "sub" << endl;
	assert(buffer.size()==img.getBuffer().size());

	for(unsigned int i=0;i<buffer.size();i++)
	{
		buffer[i] = buffer[i]-img[i];
	}
}


////////////////////////////////////////////////////////////////////////////////////
// Method

void Image::seuil( int inf, int sup)
{
  assert((unsigned int)inf<=vmax);
  assert((unsigned int)sup<=vmax);
  assert(inf<=sup);
  for(unsigned int i=0; i < buffer.size();i++)
    buffer[i] = (buffer[i]<inf) ? inf : ((buffer[i]>sup) ? sup : buffer[i]);
}

void Image::seuilBin(int seuil)
{
  for(unsigned int i=0; i < buffer.size();i++)
    buffer[i] = (buffer[i]<seuil) ? 0 : 1;

  vmax = 1;
}

void Image::negatif()
{
  for(unsigned int i=0; i < buffer.size();i++)
    buffer[i] = vmax-buffer[i];
}


////////////////////////////////////////////////////////////////////////////////////
// 


Image Image::compConnexe()
	{
	  //cout << "debut"<<endl;
	int west,nWest,north,nEast,etiwest,etinWest,etinorth,etinEast;
	int etiquette=0;
	
	Image imgout=Image(numcols,numrows);
	/* nombre de composantes connexes max = numcols*numrows/4 (demi damier) */
	vector<vector<bool> > equiv;
	vector<bool> vide;
	equiv.push_back(vide);
	equiv[0].push_back(false);
	
	for(unsigned int y = 1; y < numrows-1; y++)
	{	for (unsigned int x = 1; x < numcols-1; x++) 
		{	/* Pour chaque pixel "objet" (�gal � 1) */
			if(at(x,y)==1)
			  {	//debug <<"("<< x <<","<<y<<"):";

				/* valeurs 8-voisins haut et gauche */ 
				west=at(x-1,y);
				nWest=at(x-1,y-1);
				north=at(x,y-1);
				nEast=at(x+1,y-1);
				/* �tiquettes de ces voisins */
				etiwest=imgout(x-1,y);
				etinWest=imgout(x-1,y-1);
				etinorth=imgout(x,y-1);
				etinEast=imgout(x+1,y-1);
		
				/* Si les voisins valent tous 0*/		
				if(west+nWest+north+nEast==0)
				{	
				  //debug << "pas de voisin"<<endl;
					/* nouvelle �tiquette */
					etiquette++;
					equiv.push_back(vide);
					for(int i=0;i<etiquette;i++)//augmentation de la taille de la matrice d'equivalence
					{	
						equiv[etiquette].push_back(false);
						equiv[i].push_back(false);
					}
					equiv[etiquette].push_back(true);
					imgout(x,y)=etiquette;
				}
			
				/* Si un seul voisin est �gal � 1 */	
				else if(west+nWest+north+nEast==1)
				{
				  //	debug << "un voisin"<<endl;
					/* On attribue l'�tiquette de ce voisin */
					imgout(x,y)=etiwest+etinWest+etinorth+etinEast;			
				}
				else
				{
				  //	debug << "plusieurs voisins";
					if(west)
					{	
						imgout(x,y)=etiwest;
						//debug<<":W";
					}
					if(nWest)
					  {//	debug<<":NW";
						if( imgout(x,y) != 0 && imgout(x,y) != etinWest )
						{
							equiv[imgout(x,y)][etinWest]=true;
							equiv[etinWest][imgout(x,y)]=true; // j'ai sym�tris�
						}
						imgout(x,y)=etinWest;
					}

					if(north)
					  {//	debug<<":N";
					if( imgout(x,y) != 0 && imgout(x,y) != etinorth )
						{
							equiv[imgout(x,y)][etinorth]=true;
							equiv[etinorth][imgout(x,y)]=true; // j'ai sym�tris�
						}
						imgout(x,y)=etinorth;
					}

					if(nEast)
					  {//	debug<<":NE";
						if( imgout(x,y) != 0 && imgout(x,y) != etinEast )
						{
							equiv[imgout(x,y)][etinEast]=true;
							equiv[etinEast][imgout(x,y)]=true; // j'ai sym�tris�
						}
						imgout(x,y)=etinEast;
					}
					//debug <<endl;
				}		
			}			
		}	//debug << endl;			
	}

 
	//debug << "end for" << endl;

	/* Fermeture de la matrice d'�quivalence */
	for(unsigned int j=1;j<equiv.size();j++)
	{	for(unsigned int i=1;i<equiv.size();i++)
		{   
			if(equiv[i][j])
			{
				for(unsigned int k=1;k<equiv.size();k++)
				{
					equiv[i][k]=equiv[i][k] | equiv[j][k];	
				}
			}
		}
		
	}

		
	vector<int>table_assoc(1,0);
	/* Pour chaque num�ro i de composante connexe */
	for(unsigned int i=1;i<equiv.size();i++)
	  /* On cherche si elle est �quivalente � une autre j */
	{	for(unsigned int j=1;j<equiv.size();j++)
		{   
			if(equiv[i][j])
			{
				table_assoc.push_back(j);
				//	cout << i << "<=>" << j << endl;
				/* On sort d�s qu'on a trouv� la plus
				 * petite �quivalente, au pire j=i */
				break; 
			}
		}
	}

	/* table_assoc contient donc la correspondance entre un
	 * num�ro de composante et la composante �quivalente de
	 * num�ro minimum */

	/* On met � jour les �tiquettes en prenant donc � chaque
	 * fois la plus petite �quivalente */
	imgout.setVmax(equiv.size());
	for(unsigned int y = 1; y < numrows-1; y++)
		for (unsigned int x = 1; x < numcols-1; x++) 
			imgout(x,y)=table_assoc[imgout(x,y)];

	/* On va maintenant stocker les �tiquettes effectives qui servent
	 * � s�parer les diff�rentes composantes connexes */
	/* On trie le vecteur table_assoc */
	sort (table_assoc.begin(),table_assoc.end());
	int cour = table_assoc[0];
	for (unsigned int l = 1; l < table_assoc.size(); l++) {
	  if (table_assoc[l] != cour) {
	    cour = table_assoc[l];
	    composantes.push_back(cour);
	  }
	}

	/* Affichage des composantes connexes */
	for (unsigned int l = 0; l < composantes.size(); l++)
	  {
	    // cout << "composante n�" << l+1 << " a pour valeur " << composantes[l] << endl;
	  }
	
	return imgout;
	
}
