//#pragma once
#include <iostream> // cout, cerr
#include <fstream> // ifstream
#include <sstream> // stringstream
#include <cmath>
#include <cassert>
#include <algorithm>
#include <string>
#include <vector>
//#include "Dialogue.h"
using namespace std;



class Image
{

private:
////////////////////////////////////////////////////////////////////////////////////
// Attributs

	unsigned int numcols;
	unsigned int numrows;
	unsigned int vmax;
	string name;
	vector<int> buffer;
	vector<int> composantes;

public:

////////////////////////////////////////////////////////////////////////////////////
// Constructs

	Image(unsigned int const col,unsigned int const lig);
	Image(unsigned int const col,unsigned int const lig,unsigned int const vmax);
	Image(unsigned int const col,unsigned int const lig,unsigned int max, string nom);
	Image(string filename);
	~Image(void);

////////////////////////////////////////////////////////////////////////////////////
// Getter

	int const & at(unsigned int col, unsigned int lig) const;
	unsigned int getNumcols()const ;
	unsigned int getNumrows()const ;
	unsigned int getVmax()const ;
	string getName()const;
	vector<int> getBuffer()const;
	vector<int> getVoisin(int n, int x,int y);
	int getNbComp() const;
	vector<int> getComp() const;
	int const & at(unsigned int i) const;
	vector<int> getVoisin(Image masque,unsigned int x,unsigned int y);
////////////////////////////////////////////////////////////////////////////////////
// Setter

	int & at(unsigned int col, unsigned int lig);
	void setVmax(unsigned int i);
	int & at(unsigned int i);
////////////////////////////////////////////////////////////////////////////////////
// Surcharge operateur

	int const & operator()(unsigned int col, unsigned int lig)const;
	int & operator()(unsigned int col, unsigned int lig);
	void operator*= (Image masque);
	int const & operator[](unsigned int i)const;
	int & operator[](unsigned int i);
	
////////////////////////////////////////////////////////////////////////////////////
// Tool

	void afficher(ostream &flux);
	void afficher();
	void save(string filename);
	void save();
	void addm(Image &masque);
	void subm(Image &masque);
	void sub(Image &masque);
////////////////////////////////////////////////////////////////////////////////////
// Method

	void seuil(int inf,int sup);
	void seuilBin(int seuil);
	void negatif();
		
////////////////////////////////////////////////////////////////////////////////////
// 

	Image compConnexe();




};

ostream& operator<<( ostream &flux, Image & img);


