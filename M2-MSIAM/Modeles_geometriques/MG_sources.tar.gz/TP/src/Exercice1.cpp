#include <iostream>
#include <string>
#include <locale>
#include <algorithm>
#include"Image.h"
using namespace std;



int main(int argc, char *argv[])
{

  /* Exercice 1 */

  Image objets = Image("../images/objets.pgm");
  int nl = objets.getNumrows();
  int nc = objets.getNumcols();
  cout << "Analyse de l'image " << objets.getName() << endl;

  /* On seuille l'image en binaire */
  objets.seuilBin(50);
  objets.save("objets_seuil.pgm");

  /* Visualisation des composantes connexes coloriées différemment */
  Image comp_connexe = objets.compConnexe();
  comp_connexe.save("objets_comp.pgm"); // attention mettre à jour vmax

  /* Comptage du nombre de composantes connexes de l'image */
  cout << "L'image " << objets.getName() 
       << " comporte " << objets.getNbComp()
       << " composantes connexes" << endl;

  /* Extraction des composantes connexes */
  vector<int> composantes = objets.getComp();
  cout << "Extraction des objets de l'image" << endl;
  
  /* Pour chaque composantes connexe (objet) on compte le nombre de trous */
  for (unsigned int i = 0; i < composantes.size(); i++) {
    Image temp = Image(nc,nl);
    int val = composantes[i];
    /* On construit une image temp ne contenant que l'objet traité */
    for(unsigned int lig = 0; lig < nl; lig++) {
      for (unsigned int col = 0; col < nc; col++) {
	if (comp_connexe(col,lig) == val) {
	  temp(col,lig) = 1;
	}
      }
    } 
    temp.setVmax(1);
    std::ostringstream os;
    os << i+1;
    std::string num = os.str();
    temp.save("objet_"+num+".pgm");
    /* On compte ensuite le nombre de trous de l'objet */
    temp.negatif();
    Image inutile = temp.compConnexe();
    int nbTrous = temp.getNbComp()-1;
    if (nbTrous <= 0)
      nbTrous = 0;
    cout << "L'objet n°" << num
	 << " possède " << nbTrous
	 << " trous !" << endl;
  }

}
