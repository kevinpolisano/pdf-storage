#include <iostream>
#include <string>
#include <locale>
#include <algorithm>
#include"Image.h"
using namespace std;



int main(int argc, char *argv[])
{
        /* Exercice 2 */

	string name="riz";
	string extension="pgm";
	cout << "Analyse de l'image " << name << "." << extension << endl;

	/* Paramètres à ajuster */
	string num="35"; // taille du masque
	string numbruit="7"; // taille du masque pour éliminer le bruit
	int seuil=2; // niveau de seuillage
	
	ostringstream toString;
	toString << seuil;
	string Seuil=toString.str();

	Image base=Image("../images/"+name+"."+extension);
	Image masque=Image("../images/masque"+num+".pnm");
	Image masquebruit=Image("../images/masque"+numbruit+".pnm");
	
	Image img=base;
	cout << "Correction du fond (halo lumineux)" << endl;
	//ouverture	
	img.subm(masque);
	img.addm(masque);
	//correction de fond
	base.sub(img);	
	base.save(name+"_fondcorrig."+extension);

	cout << "Debruitage de l'image" << endl;
	img=base;
	img.seuilBin(seuil);
	img.save(name+"_fondcorrig_seuil"+Seuil+"."+extension);
	//Debruitage
	img=base;
	Image img2=img;
	img.subm(masquebruit);
	img.addm(masquebruit);
	img2.sub(img);//on obtient la carte des bruits	
	base.sub(img2);
	base.save(name+"_fondcorrig_debruit"+"."+extension);
	
	cout << "Seuillage de l'image" << endl;
	base.seuilBin(seuil);// seuillage binaire
	base.save(name+"_fondcorrig_debruit_seuil"+Seuil+"."+extension);

	cout << "Comptage des composantes connexes" << endl;
	Image imgcompco=base.compConnexe();
	imgcompco.save(name+"_compCo."+extension);

	cout <<"Nombre de grains de riz dans l'image : " << base.getNbComp() <<endl;
	
}
