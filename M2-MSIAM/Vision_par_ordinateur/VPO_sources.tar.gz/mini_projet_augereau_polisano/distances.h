#ifndef _DISTANCES_H
#define _DISTANCES_H

#include <vector>

using namespace std;

inline double euclidienne(vector<double> * P1,vector<double> * P2) {
  assert(P1->size() == P2->size());
  double res = 0;
  for (unsigned int i = 0; i < P1->size(); i++) {
    res += pow((*P1)[i]-(*P2)[i],2);
  }
  return sqrt(res);
}

#endif

/* Note : le "inline" est nécessaire sinon on a une erreur de redéfinition
 * au moment du linkage, car Noyau.h inclus Distance.h qui inclus distances.h
 * bizarre vu la précaution des ifndef. Apparemment voir internal and external
 * linkage */
