#ifndef _OPERATIONS_H
#define _OPERATIONS_H

#include <vector>

using namespace std;

double distanceVect(vector<double> x, vector<int> y);

double distanceVect(vector<double> x, vector<double> y);

/* Donne parmi tous les centroïdes K, l'indice de celui le plus proche de v */
int argmin(vector<int> v, vector<vector<double> > & K);

//definition des operations de vector. si jamais tu sais comment faire un template avec les type numeriques je suis preneur ^^. mais bon ca fonctionne bien en attendant
vector<double> operator+(vector<double>  x,vector<double>  y);

vector<double> operator+(vector<double>  x,vector<int>  y);

vector<double> operator-(vector<double>  x,vector<double>  y);

vector<double> operator-(vector<double>  x,vector<int>  y);

vector<double> operator*(double lambda,vector<int>v);

vector<double> operator*(double lambda,vector<double>v);

vector<double> operator*(int lambda,vector<double>v);

vector<double> operator*(int lambda,vector<int>v);


/* Copy d'une liste de vecteur entier dans une liste de vecteur double */
vector<vector<double> > copy(vector<vector<int> > truc);

/* Calcule une itération de la procédure de déplacement d'un point
   y vers le maximum local de la fonction de densité K */
vector<double> moveOneStep(vector<double> y, 
			   vector<vector <double> > voisins,
			   double K(vector<double> x,double hs,double hr),
			   double hs, double hr);

vector<double> move(vector<double> x,
		    double K(vector<double> x,double hs,double hr),
		    double hs, double hr, double tol);


#endif
