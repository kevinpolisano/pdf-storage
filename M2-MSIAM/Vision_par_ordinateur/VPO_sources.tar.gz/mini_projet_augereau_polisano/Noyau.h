#ifndef _NOYAU_H
#define _NOYAU_H

#include <vector>
#include <math.h>
#include <assert.h>
#include <iostream>
#include "Distance.h"
#include "operations.h"
#include "Pixel.h"

using namespace std;

inline double uniforme(vector<double> & x, double hs, double hr) {
  // cout << "uniforme" << endl;
  double res;
  //if (p && c) {
  double s = (x[0]*x[0]+x[1]*x[1])/(hs*hs); // ||x^s/hs||²
  double r = (x[2]*x[2]+x[3]*x[3]+x[4]*x[4])/(hr*hr); // ||x^r/h^r||²
  // on suppose s et r < 1 par hypothèse
  // noyau Epanechnikov
  res = 9*(1-s*s)*(1-r*r)/(16*hs*hs*hr*hr*hr);
  return res;
}

class Noyau {

 private:
  bool color;
  bool pos;
  double hs;
  double hr;
  Distance * Dist;
  double (*K)(vector<double> & x, double hsi, double hri);

 public:
  Noyau(bool c, bool p, double hsi, double hri, Distance * D,
	double N(vector<double> & x, double hsi, double hri));
  double operator()(vector<double> & x);
  Distance * getDist();

};

#endif
