#ifndef _PIXEL_H
#define _PIXEL_H

#include <vector>
#include <ostream>
#include <iostream>

using namespace std;

class Pixel {

 private:

  

 public:
  vector<double> vect;
  vector<double *>all;
  unsigned int classe;
  Pixel(vector<double> vect);
  vector<double> getVect() const;
  void display();
};

std::ostream & operator<<(std::ostream &flux, Pixel & P);

//Pixel * operator-(Pixel const & x, Pixel const & y);

#endif
