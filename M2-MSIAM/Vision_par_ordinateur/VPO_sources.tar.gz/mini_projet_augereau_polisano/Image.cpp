#include "Image.h"
#include "operations.h"

using namespace std;

ostream & debug=cout;
ostream & talk=cout;

/* Constructeurs */
	
Image::Image(unsigned int const col,unsigned int const lig)
 :numcols(col),numrows(lig),vmax(1),name("defaut.pgm"),buffer(col*lig,0),
  red(1,0),green(1,0),blue(1,0),color(false){}

Image::Image(unsigned int const col,unsigned int const lig,unsigned int max):numcols(col),numrows(lig),vmax(max),name("defaut.pgm"),buffer(col*lig,0),
red(1,0),green(1,0),blue(1,0),color(false){}

Image::Image(unsigned int const col, unsigned int const lig,
	     unsigned int max, string nom)
 :numcols(col),numrows(lig),vmax(max),name(nom),buffer(col*lig,0),
  red(1,0),green(1,0),blue(1,0),color(false){}

Image::Image(unsigned int const col,unsigned int const lig,
	     unsigned int max,bool color2)
 :numcols(col),numrows(lig),vmax(max),name("defaut.pgm"),buffer(col*lig,0),
  red(col*lig,0),green(col*lig,0),blue(col*lig,0),color(color2){}

Image::Image(string filename):name(filename)
{	
  cout << "Lecture de l'image " << name << endl;
  const char* truc = filename.c_str();
  ifstream file(truc); //flux representant le fichier	
  string inputLine = "";

  /*
    Methode de lecture d'un fichier:
    Ligne par ligne en utilisant getline().
    Mot par mot en utilisant les chevrons >>.
    Caract�re par caract�re en utilisant get().
  */
	
  getline(file,inputLine);
  if(inputLine.compare("P2") == 0 || inputLine.compare("P3") == 0 ) {
    talk << "Version : " << inputLine << endl;
  } else {	
    cerr << "Version error" << endl;
  }
  if(inputLine.compare("P2") == 0)
    {color=false;
      red.push_back(0),green.push_back(0),blue.push_back(0);
    }		
  else
    {color=true;
      buffer.push_back(0);
    } 
  getline(file,inputLine);
  talk << "Comment : " << inputLine << endl;
	
  file >> numcols >> numrows >> vmax;
  talk << numcols << " colonnes et " << numrows << " lignes" << endl 
       << "valeur max:" << vmax << endl;

  int j=0;
  for(unsigned int i = 0; i < numrows*numcols; i++)
    {	
      vector<double> comp;
      comp.push_back(i/numcols);
      comp.push_back(i%numcols);
      if(!color)
    	{ 	file >> j;
      
	  buffer.push_back(j);
	  comp.push_back(j);
	}    
      else
	{
	  file >> j;
	  red.push_back(j);
	  comp.push_back(j);
	  file >> j;
	  green.push_back(j);
	  comp.push_back(j);
	  file >> j;
	  blue.push_back(j);
	  comp.push_back(j);
        	
	}
      Pixel * pixCour = new Pixel(comp);
      //	cout << pixCour << endl;
      //pixCour->display();	
      espace.push_back(pixCour);
    }
		
  // debug <<endl << "creation du buffer OK" << endl;

  file.close();
		
  //debug << "lecture du fichier OK" <<endl;
}

Image::~Image(void){}

/* Accesseurs */

const int& Image::at(unsigned int col,unsigned int lig) const
{ assert(col<numcols);
  assert(lig<numrows);
  return buffer[lig*numcols+col];
}

const int& Image::at(unsigned int i) const
{	
  return buffer[i];
}

Pixel * Image::getPix(unsigned int i) const
{
  return espace[i];
}

unsigned int Image::getNumcols()const 
{	return numcols;}
unsigned int Image::getNumrows()const 
{	return numrows;}
unsigned int Image::getVmax()const 
{	return vmax;}
string Image::getName()const 
{	return name;}

vector<int> Image::getBuffer()const
{	return buffer;}

bool Image::getColor()const
{ return color;}

/* Mutateurs */

int& Image::at(unsigned int col,unsigned int lig)
{ assert(col<numcols);
  assert(lig<numrows);
  return buffer[lig*numcols+col];
}

vector<int> Image::atc(unsigned int col,unsigned int lig)
{ assert(col<numcols);
  assert(lig<numrows);
  vector<int> truc(3,0);
  truc[0]=red[lig*numcols+col];
  truc[1]=green[lig*numcols+col];
  truc[2]=blue[lig*numcols+col];
  return truc;
}


int& Image::at(unsigned int i)
{	
  return buffer[i];
}

vector<int> Image::atc(unsigned int i)
{	
  vector<int> truc(3,0);
  truc[0]=red[i];
  truc[1]=green[i];
  truc[2]=blue[i];
  return truc;
}
void Image::setColor(unsigned int i,vector<int> color)
{
  red[i]=color[0];
  green[i]=color[1];
  blue[i]=color[2];
}

void Image::setVmax(unsigned int i)
{ vmax=i;}

/* Surcharge d'op�rateurs */

int &Image::operator()(unsigned int col,unsigned int lig)
{	return this->at(col,lig);	
}

int const &Image::operator()(unsigned int col,unsigned int lig)const
{	return this->at(col,lig);	
}

int &Image::operator[](unsigned int i)
{	return this->at(i);	
}

int const &Image::operator[](unsigned int i)const
{	return this->at(i);	
}

/* Outils */

void Image::afficher(std::ostream &flux)
{
  if(!color)
    {  flux << "P2" << endl << "#" << name << endl << numcols
	    << " " <<numrows << endl << vmax << endl;
      for(unsigned int lig = 0; lig < numrows; lig++)
	{for (unsigned int col = 0; col < numcols; col++) 
	    flux << at(col,lig) <<" ";
	  flux <<endl;
	}
    }
  else
    {flux << "P3" << endl << "#" << name << endl << numcols << " " 
	  <<numrows << endl << vmax << endl;
      for(unsigned int lig = 0; lig < numrows; lig++)
	{for (unsigned int col = 0; col < numcols; col++) 
	    flux << atc(col,lig)[0] <<" " << atc(col,lig)[1] << " "
		 << atc(col,lig)[2] <<" ";
	  flux <<endl;
	}
    }
}
void Image::save(string filename)
{
  name=filename;
  const char* truc = filename.c_str();
  ofstream myfile (truc);
  if (myfile.is_open())
    {	
      myfile << *this;
      myfile.close();
      debug << "Sauvegarde du fichier " << filename << " OK" << endl;
    }
  else cout << "Unable to open file";
}

void Image::save()
{save(name);}

void Image::reset()
{}

/* M�thodes annexes */

void Image::seuil(int inf,int sup)
{
  assert(inf<=(int)vmax);
  assert(sup<=(int)vmax);
  assert(inf<=sup);
  for(unsigned int i=0; i < buffer.size();i++)
    buffer[i] = (buffer[i]<inf) ? inf : ((buffer[i]>sup) ? sup : buffer[i]);
}
void Image::seuilinf(int inf)
{  
  for(unsigned int i=0; i < buffer.size();i++)
    buffer[i] = (buffer[i]<inf) ? 0 : 1;
}
void Image::negatif()
{
  for(unsigned int i=0; i < buffer.size();i++)
    buffer[i] = vmax-buffer[i];
}

void Image::recal(int Vmax)
{int maxi=0,mini=0;
  for(unsigned int i=0;i<buffer.size();i++)
    {maxi=(maxi<buffer[i])?buffer[i]:maxi;
      mini=(mini>buffer[i])?buffer[i]:mini;}
  for(unsigned int i=0;i<buffer.size();i++)
    buffer[i]=(buffer[i]-mini)*Vmax/(maxi-mini);
  vmax=Vmax;
}

vector<int> Image::histogramme()
{
  vector<int>histo(vmax+1,0);
  for(unsigned int i=0;i<buffer.size();i++)
    histo[buffer[i]]++;
  return histo;
}

void Image::seuilp(int pourcent)
{
  double limit = (double)numrows*numcols*pourcent/100.;
  vector<int>histo=histogramme();
  int j=0;
  for(unsigned int i=0;i<=vmax;i++)
    {
      j+=histo[i];
      cout << j << " | ";
      if(j>limit)
	{j=i;break;}
    }
  cout <<endl<< j << endl;
  seuil(j,vmax);
  recal(vmax);

}

vector<unsigned int> Image::getCoord(unsigned int pixel)
{
  vector <unsigned int> coord(2,0);
  coord[0]=pixel%numcols;
  coord[1]=pixel/numcols;
  return coord;
}

/* M�thodes de segmentation */

void Image::constructTree(bool pos)
{
  //int comptage=1;
  debug << "Creation de l'arbre de recherche ..."<<endl;
  int dim=(color)?5:3;
  //cout << "plop" << comptage++ << endl;
  root = new node();
  root->depth=(pos)?0:2;
  //cout << "plop" << comptage++ << endl;
  int d=floor(nthRoot(numrows*numcols,dim-root->depth));
  // cout << d << endl;
  d=8;
  vector<int>Hmax(5,0);
  Hmax[0]=numrows;
  Hmax[1]=numcols;
  Hmax[2]=256;
  Hmax[3]=256;
  Hmax[4]=256;
	
  //cout << "plop" << comptage++ << endl;
  root->feuille=espace;
	
  list<node*> stack;
  stack.push_back(root);

  vector<int> machinbidule(6,0);
  int oldepth=0;
  while(stack.size()>0)
    {

      node * N = stack.front();
      if(oldepth<N->depth)
	{//cout << oldepth << ":" << machinbidule[oldepth]<<endl;oldepth++;
	}
      machinbidule[oldepth]++;
		
      stack.pop_front();
      if(N->depth< dim && N->feuille.size()>(unsigned int)d)
	{
	  vector<int>histo(Hmax[N->depth],0);
	  //on calcule l'histogramme
	  for(unsigned int i=0;i<N->feuille.size();i++)
	    {
	      histo[(unsigned int)*(N->feuille[i]->all[N->depth])]++;
	    }
	  //on calcule l'histogramme cumul� pour le counting sort
	  for(int m=1;m<Hmax[N->depth];m++)
	    {	
	      histo[m]+=histo[m-1];
	    }

	  vector<Pixel*>fTriNew=N->feuille;
	  //insertion des feuilles au bon endroit dans le tableau
	  for(unsigned int i=0;i<fTriNew.size();i++)
	    {
	      Pixel * tLeaf = fTriNew[i];
				
	      histo[(int)*(tLeaf->all[N->depth])]--;
	      int tA = histo[(int)*(tLeaf->all[N->depth])];
	      //double test = tLeaf->get(N->depth);
	      //tLeaf->ri=sqrt(pow(tLeaf->ri,2)-pow(test,2));
	      N->feuille[tA]=tLeaf;
	    }

	  //creation des nodes enfants
	  int compteur=0;
	  for(int i=0;i<d;i++)
	    {
	      node * Node = new node(N);
	      for(int j = compteur;j<compteur+ceil((N->feuille.size()-compteur)/(d-i));j++)
		{
		  Node->feuille.push_back(N->feuille[j]);
		}
	      compteur+=ceil((N->feuille.size()-compteur)/(d-i));
	      if(i!=0 && i!=d-1)
		{ 
		  Node->min=*(Node->feuille.front()->all[N->depth]);
		  Node->max=*(Node->feuille.back()->all[N->depth]);
		}
	      else if(i==0)
		{
		  Node->min=0;
		  Node->max=*(Node->feuille.back()->all[N->depth]);
		}
	      else if(i==d-1)
		{
		  Node->min=*(Node->feuille.front()->all[N->depth]);
		  Node->max=Hmax[Node->depth-1];
		}
	      stack.push_back(Node);
	    }
			
	  N->feuille.clear();	
	}
		
    }
  /*
    cout << "___________"<<endl;
    cout << "0:" << machinbidule[0]<<endl;
    cout << "1:" << machinbidule[1]<<endl;
    cout << "2:" << machinbidule[2]<<endl;
    cout << "3:" << machinbidule[3]<<endl;
    cout << "4:" << machinbidule[4]<<endl;
    cout << "5:" << machinbidule[5]<<endl;
  */
  // debug << "DONE"<< endl;
}

vector<Pixel *> Image::getVoisinsLocal(vector<double> & x, Noyau * K, double b) {
  vector<Pixel * > result;
  Distance * D = K->getDist();

  if (true) {
    vector <double>truc(5,0);
    searchOST(root,x,0,(*D)(&x,&truc),b*b,&result);
  } else {
	
    //vector<double> xv = x;
    Pixel * temp;
    for (unsigned int i = 0; i < espace.size(); i++) {
      temp = espace[i];
      vector<double> tempv = temp->getVect();
      if ((*D)(&x,&tempv) < b) {
	result.push_back(temp);
	// cout << "pix" << i << endl;
      }
    }
  }
  
  //cout <<"size:" <<  result.size()<< "|" <<voisins.size()<<endl;
  
  /*for(int i=0;i<result.size();i++)
    {
    result[i]->display();
    }
    cout << endl;
    for(int i=0;i<voisins.size();i++)
    {
    voisins[i]->display();
    }
  */
  
  
  return result;
  
}

void Image::searchOST(node * N,vector<double> & Q,double dLB,double rq,double dk,vector<Pixel *> * result)
{
  /*
    for(int i = 0;i<N->depth;i++)
    cout << "|  ";
    cout << N->depth<< "(" << N->min << "-" << N->max << ")"<< N->enfant.size() << endl;
    for(int i = 0;i<N->depth;i++)
    cout << "|  ";
    cout << "dLB=" << dLB << " | rq="<<rq <<endl;
  */
  if(N->enfant.size()==0)
    {
      for(unsigned int i =0;i<N->feuille.size();i++)
	{
			
	  Pixel * it = N->feuille[i];
	  /*for(int i = 0;i<N->depth;i++)
	    cout << "|  ";
	    cout << dk<< ">" << dLB <<"+"<<rq<<"�("<<pow(rq,2)<<")["<< dLB+pow(rq,2) <<"]"<<endl;*/
	  if(dk>dLB+pow(rq,2))
	    {
	      vector <double>machin = it->getVect();
	      vector <double>bidule = Q;
	      double truc=0;
	      for(unsigned int i=0;i<machin.size();i++)
		truc+=pow(machin[i]-bidule[i],2); 
	      if(truc<=dk)
		result->push_back(it);
	    }
	}
    }
  else
    {
      // j'ai chang� un truc ici
      double q = Q[N->depth];
      rq=sqrt(abs(pow(rq,2)-pow(q,2)));
      int middle = N->getArgmin(Q,dLB);
      if(middle>=0)
	{
	  searchOST(N->enfant[middle],Q,dLB,rq,dk,result);
	  unsigned int left=middle-1,right=middle+1;
	  double dleft,dright;
	  while(true)
	    {
	      if(left>=N->enfant.size())
		dleft=left;
	      else
		dleft=q-N->enfant[left]->max;
		
	      if(right>=N->enfant.size())
		dright=(unsigned int)-1;
	      else
		dright=N->enfant[right]->min-q;
	      if(dleft == (unsigned int)-1  && dright == (unsigned int )-1)
		break;
	      if(dleft<=dright)
		{
		  double d=pow(dleft,2)+dLB;
		  if(dk<=d)
		    {left--;}
		  else
		    {
		      searchOST(N->enfant[left],Q,d,rq,dk,result);
		      left--;
		    }
		}
	      else
		{
		  double d=pow(dright,2)+dLB;
		  if(dk<=d)
		    {right++;}
		  else
		    {
		      searchOST(N->enfant[right],Q,d,rq,dk,result);
		      right++;
		    }
		}
	    }
	}
    }
}

/* Entr�e x, calculs barycentriques, sortie stock�e dans y */
void Image::moveOneStep(vector<double> & x, vector<double> & y, Noyau * K, double b) {
  /* On d�termine les voisins de x */
  vector<Pixel *> v = this->getVoisinsLocal(x,K,b);
  
  /* On r�initialise le vecteur de sortie y � z�ro */
  for (unsigned int i = 0; i < y.size(); i++)
    y[i] = 0;

  /* On d�clare un vecteur temporaire diff contenant la diff�rence x-voisin*/
  vector<double> diff(x.size(),0);
  double s = 0;
  double poids = 0;
  for (unsigned int i = 0; i < v.size(); i++) {
    /* On calcule le vecteur diff�rence x-voisin */
    for (unsigned int k = 0; k < x.size(); k++) {
      diff[k] = x[k]-(v[i]->getVect())[k];
    }
    /* On calcule le poids */
    poids = (*K)(diff);
    /* On ajoute la contribution du voisin � la sortie */
    for (unsigned int j = 0; j < y.size(); j++) {
      y[j] += poids*(v[i]->getVect())[j];
    }
    s += poids;
  }
  /* On divise le tout par le poids total s */
  for (unsigned int j = 0; j < y.size(); j++) {
    y[j] /= s;
  }
}


/* Ecrit dans xc le r�sultat de la convergence de x */
void Image::move(vector<double> & x, vector<double> & xc, Noyau * K, double tol, double b) {
  vector<double> temp = x; // pour switcher
  /* On �crit le r�sultat de la premi�re it�ration dans xc */
  moveOneStep(temp,xc,K,b);
 
  int k = 1;
  while ((*(K->getDist()))(&temp,&xc) > tol) {
    //cout << "y"1 << k << " = " << *yj << endl;
    if (k % 2 == 1) {
      moveOneStep(xc,temp,K,b);
    } else {
      moveOneStep(temp,xc,K,b);
    }
    k++;
  } 
  //cout << "nombre iterations = " << k << endl;
}

/* Algorithmes de segmentation */

Image Image::Kmean(double cond_arret, int k, bool pos) {
  cout << "*** Segmentation Kmeans de l'image " << name << " ***" << endl;
  //img.save(name+"2"+extension);

  /* Arr�t de la boucle quand la plus grande distance entre un point
   * et son centro�de est < cond_arret */
  bool color = this->getColor(); //niveau de gris ou RGB

  /*
    pos=false & color=false => niveau de gris
    pos=true & color=false =>  niveau de gris + position
    pos=false & color=true => espace RVB
    pos=true & color=true => espace RVB + position
  */

  vector<int> temp; // sert a initialiser vecteurs de vecteurs
	
  /* Ensemble des points de l'espace, �gal au nombre de pixels de l'image
   * vus comme des vecteurs RGB (ou RGB+position) */
  vector<vector<int> > espace(this->getNumrows()*this->getNumcols(),temp);

  /* Stocke les points de l'espace en leur associant un centro�de */
  vector<int> table(espace.size(),0); // plut�t un int ici non ??
	
  vector<double>tempd;
  vector< vector<double> > K(k,tempd); //sert a stocker les centroides
	

  //initialisation des points de l'espace
  unsigned int numcols=this->getNumcols();
  unsigned int numrows=this->getNumrows();
  // cout << "initialisation des points"<<endl;
  /* On parcourt les pixels de l'image et on les ajoute � l'espace */
  for(unsigned int i=0;i<numcols*numrows;i++)
    {	
      //cout<< i;
      if(color)
	{
	  temp=this->atc(i);
	  espace[i].push_back(temp[0]);
	  espace[i].push_back(temp[1]);
	  espace[i].push_back(temp[2]);
	}		
      else
	espace[i].push_back((*this)[i]); // surcharge this->buffer[i]
      if(pos)
	{
	  espace[i].push_back(i%numcols);
	  espace[i].push_back(i/numcols);
	}
    }

  //initialisation des centroides
  /*
    /!\ le resultat de l'algorithme depend fortement de l'initialisation des centroides. donc ce seras LA partie sur laquelle il faudras experimenter
  */
  srand ( time(NULL) );
  // cout << "initialisation des centroides"<< endl;
  for(int i=0;i<k;i++)
    {	

      /* Choix d'un pixel al�atoire dans l'image */
	  
      unsigned int xalea = rand() % numrows;
      unsigned int yalea = rand() % numcols;
      //  cout << "centroide n�" << i << " : (" << xalea << "," << yalea << ")" << endl;
      unsigned int gris;
      vector<int> couleur;

      if (color)
	couleur = this->atc(yalea,xalea);
      else
	gris = (*this)(xalea,yalea);

      if(color)
	{	
	  // K[i].push_back((100*i)%255);
	  // K[i].push_back((15*i)%255);
	  // K[i].push_back((37*i)%255);
	  K[i].push_back(couleur[0]);
	  K[i].push_back(couleur[1]);
	  K[i].push_back(couleur[2]);
	}
      else
	K[i].push_back(gris);
      //	K[i].push_back((255/k)*i+255/(k*2));//niveau de gris �quirepartie
      if(pos)//position equirepartie sur la diagonale
	{
	  // K[i].push_back((numcols/k)*i+numcols/(numcols*2));
	  // K[i].push_back((numrows/k)*i+numrows/(numrows*2));
	  K[i].push_back(xalea);
	  K[i].push_back(yalea);
	}
    }

  int arret=0;
	
  int tour=0;
  //Calcul des composantes de segmentation
  // cout <<"calcul des composantes de segmentation"<<endl;
  while(!arret)
    {   
      vector<int> Kpoid(k,0);//sert a stocker les poids des centroide lors de leur maj
      tour++;
      //    cout << tour ;

      //associe � chaque element le centroide le plus proche
      // cout << " | assoc";
      for(unsigned int i=0;i<espace.size();i++)
	table[i]=argmin(espace[i],K);

      // cout << " | copy";
      vector<vector<double> > Ktemp=K;

      /*
	for(unsigned int i = 0; i <K.size();i++)
	{
	for(unsigned int j = 0; j <K[i].size();j++)
	cout << K[i][j] << "," ;
	cout << endl;
	}*/

      //calcul de la position des nouveaux centroides

      // Soit j un des k clusters.
      // Chaque point de l'espace index� par i dans l'espace et tel que
      // table[i] = j, c'est-�-dire qui appartient au cluster j, contribue
      // � d�placer l'isobarycentre K[j] du cluster. 
      // Pour le premier point P1 du cluster rencontr�, K[j] = espace[i] = P1 car Kpoid initialis� � 0.
      // Pour le deuxi�me point P2 on a K[j] = 1/2(P1+P2)
      // Pour le troisi�me point P3 on a K[j] = 1/3[ (2*1/2(P1+P2)+P3 ] = 1/3(P1+P2+P3) et ainsi de suite.
      // A la fin on a calcul� le nouvel isobarycentre du cluster j. Et ce pour tous les clusters.
      // cout << " | update";
      for(unsigned int i=0;i<espace.size();i++)
	{
	  //cout << table[i] << ",";

	  K[table[i]]=(1/(Kpoid[table[i]]+1.))  *  (  (Kpoid[table[i]]*K[table[i]]  ) + espace[i] );
	  Kpoid[table[i]]++;

	}
      //calcul du plus grand deplacement d'un centroide
      double max=0;
      double dist;
      // cout << " | max"<< endl;
      for(unsigned int i=0;i<K.size();i++)
	{
	  // on compare ancienne position - nouvelle position
	  dist=distanceVect(K[i],Ktemp[i]);
	  //cout << dist << ",";
	  if(dist>max)
	    max=dist;
	}
      //  cout << endl;
      //determine l'arret ou non de l'algorithme
      if(max<=cond_arret)
	arret++;
		
    }
	
  //sauvegarde de la nouvelle image
  Image imgseg=Image(numcols,numrows,k,this->getColor());
  for(unsigned int i=0;i<espace.size();i++)
    {
      if(color)
	{	
	  vector<int> truc(3,0);
	  /* On associe au point i la couleur de son centro�de */
	  truc[0]=K[table[i]][0];
	  truc[1]=K[table[i]][1];
	  truc[2]=K[table[i]][2];
	  imgseg.setColor(i,truc);
	  imgseg.setVmax(255);
	}
      else
	imgseg[i]=table[i]; // pour chaque pixel on lui donne la couleur de l'�tiquette de son centroide
      // imgseg[i]=(int)K[table[i]][0];//pour chaque pixel on lui donne la couleur de son centroide
    }


  return imgseg;
}

Image Image::MeanShift(Noyau * K, double b, double tol) {
  cout << "*** Segmentation Mean Shift de l'image " << name << " ***" << endl;
  int numClasse = 0;
  int nbPix = numcols*numrows;
  int percent = 0;
   vector <Pixel *>Klass(1,espace[0]);
   for(int i = 0; i < nbPix; i++)
    {	
      if ((i % (nbPix/100)) == 0) {
	cout << percent << "%" << endl;
	percent += 1;
      }
      // si le pixel est d�j� class� on passe au pixel suivant
      if(espace[i]->classe != (unsigned int)-1) {
	//cout << ">>" << i << "#class:"<< numClasse << " me:"<< img.getPix(i)->classe<<endl;
	continue;
      }		
      // cout << i << "#class:"<< numClasse << " me:"<< espace[i]->classe<<endl;
      Pixel * Pix = espace[i];
      
      /* Convergence du pixel Pix */
      vector<double> Pixc(5,0);
      vector<double> Pixv = Pix->getVect();
      move(Pixv,Pixc,K,tol,b);
	
      vector<Pixel *> vois = getVoisinsLocal(Pixc, K, b*2);
      //cout << vois.size()<< endl;
	
      set<unsigned int> classe;
      // si un des voisins est d�j� class� on garde la plus petite
      // pas notion distance si deux classes diff�rentes ?
		for(unsigned int j=0;j<vois.size(); j++) 
		{	
			if(vois[j]->classe < (unsigned int)-1)
		  	{
			 	classe.insert(vois[j]->classe);
		  	}
      }
      //  cout <<"		>>"<< classe << endl;
      // si on en a trouv� un
      Pixel * node = new Pixel(Pixc);
      if(classe.size()>0) 
      {
	set<unsigned int>::iterator it;
	int truc;
	int oldtruc=b*8;
	unsigned int argclass=-1;
	unsigned int Num=0;
	
	for(it=classe.begin();it!=classe.end();it++)
	{
	  Num=*it; 
	  truc=0;
	 for(unsigned int k=2;k<5;k++)
		truc+=pow(Klass[Num]->vect[k]-node->vect[k],2); 
	  if(truc < oldtruc)
	  {	oldtruc=truc;
	       argclass=Num;
	    
	  }
	 
	}
	 
	 if(argclass!=(unsigned int)-1 )
	 {
	// on met Pix dans cette classe et tous les voisins de Pixc aussi
			for(unsigned int j=0;j<vois.size();j++) 
			{
			  if(vois[j]->classe==(unsigned int) -1)
			    vois[j]->classe=Num;
			}
			espace[i]->classe=Num;
			delete(node);
	}
	else
	  goto plop;
      }
      
      // sinon on cr�� une nouvelle classe et on fait de m�me
      else 
      {	
	plop:
			numClasse++;
			Klass.push_back(node);
			for(unsigned int j=0;j<vois.size();j++) 
			{
			  if(vois[j]->classe==(unsigned int) -1)
			    vois[j]->classe=numClasse;
			}
			espace[i]->classe=numClasse;
      }	 
    }
  //cout << "fini"<<endl;

// au lieu de la classe lui affecter la moyenne des couleurs des pixels
// de la classe

//

Image imgseg = Image(numcols,numrows,numClasse);
for(unsigned int i = 0; i < numcols*numrows; i++) 
{
	   imgseg[i]=espace[i]->classe;
 }

 return imgseg;
}

/* M�thodes hors classe */

std::ostream& operator<<( std::ostream &flux, Image & img )
{
  img.afficher(flux);
  return flux;
}

double nthRoot(double x, double n){
  return exp(log(abs(x))/n);
}

void saveMS(Image & imgseg, string name, string extension,
	    string d_name, string k_name,
	    bool pos, double hs, double hr, double b, double tol) 
{
	
	
	string option = "";
	if (pos)
	  option+="_pos";
	option+="_";
	option+=d_name;
	option+="_";
	option+=k_name;
	option+="_";
	std::ostringstream oss;
	// �crire un nombre dans le flux
	oss << hs << "_" << hr << "_" << b << "_" << tol;
	// r�cup�rer une cha�ne de caract�res
	std::string result = oss.str();
	option+=result;
	imgseg.save(name+"_segMS"+option+extension);
}

void saveKM(Image & imgseg, string name, string extension,
	    double cond_arret, int nb_clusters, bool pos) {
	string option="";
	if(pos)
		option+="_pos";
	option+="_";
	std::ostringstream oss;
	// �crire un nombre dans le flux
	oss << nb_clusters << "_" << cond_arret;
	// r�cup�rer une cha�ne de caract�res
	std::string result = oss.str();
	option+=result;
	imgseg.save(name+"_segKM"+option+extension);
}


