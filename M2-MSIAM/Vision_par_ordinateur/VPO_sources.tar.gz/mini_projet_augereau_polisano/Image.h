#ifndef _IMAGE_H
#define _IMAGE_H

#include <iostream> 
#include <fstream> 
#include <sstream> 
#include <cmath>
#include <cassert>
#include <algorithm>
#include <string>
#include <vector>
#include <list>
#include <set>
#include "Pixel.h"
#include "Noyau.h"
#include "node.h"

using namespace std;

class Image
{

private:
 
        /* Attributs */
	unsigned int numcols;
	unsigned int numrows;
	unsigned int vmax;
	string name;
	vector<int> buffer;

	bool color;
	
public:
	vector<int> red;
	vector<int> green;
	vector<int> blue;
	vector<Pixel *> espace;
	node * root;

	/* Constructeurs et destructeur */
	Image(unsigned int const col, unsigned int const lig);
	Image(unsigned int const col, unsigned int const lig,
	      unsigned int const vmax);
	Image(unsigned int const col, unsigned int const lig, 
	      unsigned int max, bool color);
	Image(unsigned int const col, unsigned int const lig,
	      unsigned int max, string nom);
	Image(string filename);
	~Image(void);

	/* Accesseurs */
	int const & at(unsigned int col, unsigned int lig) const;
	int const & at(unsigned int i) const;
	unsigned int getNumcols()const ;
	unsigned int getNumrows()const ;
	unsigned int getVmax()const ;
	string getName()const;
	vector<int> getBuffer()const;
	bool getColor()const;
	Pixel * getPix(unsigned int i) const;

	/* Mutateurs */
	int & at(unsigned int col, unsigned int lig);
	int & at(unsigned int i);
	vector<int> atc(unsigned int col, unsigned int lig);
	vector<int> atc(unsigned int i);
	void setColor(unsigned int i,vector<int> color);
	void setVmax(unsigned int i);

	/* Surcharge d'opérateurs */
	int const & operator()(unsigned int col, unsigned int lig)const;
	int & operator()(unsigned int col, unsigned int lig);
	int const & operator[](unsigned int i)const;
	int & operator[](unsigned int i);

	/* Outils */
	void afficher(ostream &flux);
	void afficher();
	void save(string filename);
	void save();
	void reset();

	/* Méthodes annexes */
	void seuil(int inf,int sup);
	void seuilinf(int inf);
	void negatif();
	void recal(int max);
	vector<int> histogramme();
	void seuilp(int pourcent);
	vector<unsigned int> getCoord(unsigned int pixel);

	/* Méthodes pour la segmentation */
	void constructTree(bool pos);	
	vector<Pixel *> getVoisinsLocal(vector<double> & x, Noyau * K,
					double b);
	void searchOST(node * N,vector<double> & Q, double dLB,
		       double rq, double dk, vector<Pixel *> * result);
	void moveOneStep(vector<double> & x, vector<double> & y,
			 Noyau * K, double b);
	void move(vector<double> & x, vector<double> & xc,
		  Noyau * K, double tol, double b);

	/* Algorithmes de segmentation */
	Image Kmean(double cond_arret, int k, bool pos);
	Image MeanShift(Noyau * K, double b, double tol);

};

/* Méthodes externes à la classe */
ostream& operator<<( ostream &flux, Image & img);
double nthRoot(double x, double n);
void saveMS(Image & imgseg, string name, string extension,
	    string d_name, string k_name,
	   bool pos, double hs, double hr, double b, double tol);
void saveKM(Image & imgseg, string name, string extension,
	    double cond_arret, int nb_clusters, bool pos);

#endif
