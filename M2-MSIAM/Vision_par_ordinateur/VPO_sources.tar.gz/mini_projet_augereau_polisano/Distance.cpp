#include "Distance.h"

using namespace std;

Distance::Distance(bool c, bool p, double d(vector<double> * P1,vector<double> * P2)):color(c),pos(p),dist(d)
{ }

double Distance::operator()(vector<double> * P1, vector<double> * P2)
{
  return (*dist)(P1,P2);
}
