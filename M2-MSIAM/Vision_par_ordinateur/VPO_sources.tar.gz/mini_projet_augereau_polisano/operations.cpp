#include "operations.h"
#include "Pixel.h"
#include <float.h>
#include <assert.h>
#include <math.h>



double distanceVect(vector<double> x, vector<int> y)
{
	assert(x.size()==y.size());
	double result=0;
	for(unsigned int i=0;i<x.size();i++)
		result+=pow(x[i]-y[i],2);
	return result;
}

double distanceVect(vector<double> x, vector<double> y)
{
	assert(x.size()==y.size());
	double result=0;
	for(unsigned int i=0;i<x.size();i++)
		result+=pow(x[i]-y[i],2);
	return result;
}

/* Donne parmi tous les centroïdes K, l'indice de celui le plus proche de v */
int argmin(vector<int> v, vector<vector<double> > & K)
{	int argmin=0;
	double argmindist=DBL_MAX;
	double dist=0;
	for(unsigned int i =0;i<K.size();i++)
	{	dist=distanceVect(K[i],v);
		if(dist<argmindist)
			{argmin=i;
			argmindist=dist;
			}
	}
	return argmin;
}
//definition des operations de vector. si jamais tu sais comment faire un template avec les type numeriques je suis preneur ^^. mais bon ca fonctionne bien en attendant
vector<double> operator+(vector<double>  x,vector<double>  y)
{	assert(x.size()==y.size());
	vector<double>result;
	for(unsigned int i=0;i<x.size();i++)
		result.push_back(x[i]+y[i]);
	return result;
}

vector<double> operator+(vector<double>  x,vector<int>  y)
{	assert(x.size()==y.size());
	vector<double>result;
	for(unsigned int i=0;i<x.size();i++)
		result.push_back(x[i]+y[i]);
	return result;
}

vector<double> operator-(vector<double>  x,vector<double>  y)
{	assert(x.size()==y.size());
	vector<double>result;
	for(unsigned int i=0;i<x.size();i++)
		result.push_back(x[i]-y[i]);
	return result;
}

vector<double> operator-(vector<double>  x,vector<int>  y)
{	assert(x.size()==y.size());
	vector<double>result;
	for(unsigned int i=0;i<x.size();i++)
		result.push_back(x[i]-y[i]);
	return result;
}

vector<double> operator*(double lambda,vector<int>v)
{
	vector<double>result;
	for(unsigned int i=0;i<v.size();i++)
		result.push_back(lambda*v[i]);
	return result;
}

vector<double> operator*(double lambda,vector<double>v)
{
	vector<double>result;
	for(unsigned int i=0;i<v.size();i++)
		result.push_back(lambda*v[i]);
	return result;
}
vector<double> operator*(int lambda,vector<double>v)
{
	vector<double>result;
	for(unsigned int i=0;i<v.size();i++)
		result.push_back(lambda*v[i]);
	return result;
}

vector<double> operator*(int lambda,vector<int>v)
{
	vector<double>result;
	for(unsigned int i=0;i<v.size();i++)
		result.push_back(lambda*v[i]);
	return result;
}


/* Copy d'une liste de vecteur entier dans une liste de vecteur double */
vector<vector<double> > copy(vector<vector<int> > truc)
{
	vector<vector<double> > result;
	vector<double>temp;
	for(unsigned int i =0; i<truc.size();i++)
	{
		result.push_back(temp);
		for(unsigned int j=0;j<truc[i].size();j++)
			result[i].push_back((double)truc[i][j]);
	}
	return result;
}


