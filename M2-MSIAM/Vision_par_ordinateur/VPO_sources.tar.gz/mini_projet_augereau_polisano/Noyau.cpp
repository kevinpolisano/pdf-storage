#include "Noyau.h"

using namespace std;

Noyau::Noyau(bool c, bool p, double hsi, double hri, Distance * D,
	     double N(vector<double> & x, double hsi, double hri)) : color(c),pos(p),hs(hsi),hr(hri),Dist(D)
 {
   if (c == 1 && p == 1) {
     K = N;
   }
 }

double Noyau::operator()(vector<double> & x)
{
  return (*K)(x,hs,hr);
}

Distance * Noyau::getDist() {
  return Dist;
}
