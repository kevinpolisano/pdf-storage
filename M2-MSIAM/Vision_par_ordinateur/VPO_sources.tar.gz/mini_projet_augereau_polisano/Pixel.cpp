#include "Pixel.h"
#include "assert.h"

using namespace std;

Pixel::Pixel(vector<double> v):vect(v)
{
classe=-1;
all.push_back(&vect[0]);
all.push_back(&vect[1]);

all.push_back(&vect[2]);
all.push_back(&vect[3]);
all.push_back(&vect[4]);

}


vector<double> Pixel::getVect() const {
  return vect;
}

std::ostream & operator<<(std::ostream &flux, Pixel & P)
{
  flux << "x = " << (P.getVect())[0] << endl;
  flux << "y = " << (P.getVect())[1] << endl;
  flux << "r = " << (P.getVect())[2] << endl;
  flux << "g = " << (P.getVect())[3] << endl;
  flux << "b = " << (P.getVect())[4] << endl;
  return flux;
}


void Pixel::display()

	{ std::cout <<"("<< vect[0] << "," << vect[1] << "):"<< vect[2] <<"," << vect[3] << "," << vect[4] << endl;}
