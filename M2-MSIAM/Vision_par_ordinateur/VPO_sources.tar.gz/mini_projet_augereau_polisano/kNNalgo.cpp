#include <iostream>
#include <vector>
#include <cstdlib>
#include "node.h"
#include <ctime>

using namespace std;

void tab(int dim)
{
for(int i = 0;i<dim;i++)
				cout << "|  ";
}

double dist(leaf * A, leaf * B)
{
	return pow(A->x-B->x,2)+pow(A->y-B->y,2)+pow(A->r-B->r,2)+pow(A->v-B->v,2)+pow(A->b-B->b,2);
}
void searchOST(node * N,leaf * Q,double dLB,double rq,double dk,vector<leaf*> * result)
{
	tab(N->depth);
	cout << N->depth<< "(" << N->min << "-" << N->max << ")"<<endl;
	if(N->enfant.size()==0)
	{
		/*list<leaf*>::iterator it;
		for ( it=N->feuille.begin() ; it !=N->feuille.end(); it++ )
		{
			if(dk>dLB+pow(sqrt((*it)->ri) -rq,2))
			{
				if(dist(*it,Q)<=dk)
					result->push_back(*it);
			}
		}
		*/
		for(int i =0;i<N->feuille.size();i++)
		{
			
			leaf * it = N->feuille[i];
			/*if(dist(it,Q)<=dk)
			{
			tab(N->depth+1);
			it->display();
			tab(N->depth+1);
			cout <<"rq:"<<rq << " ri: " <<it->ri<< " dLB:"<<dLB<<endl;
			}*/
			if(dk>dLB+pow(it->ri-rq,2))
			{
				double truc= dist(it,Q);
				if(truc<=dk)
					result->push_back(it);
			}
		}
	}
	else
	{
		double q = Q->get(N->depth);
		rq=sqrt(pow(rq,2)-pow(q,2));
		int middle = N->getArgmin(Q,dLB);
		if(middle>=0)
		{
			searchOST(N->enfant[middle],Q,dLB,rq,dk,result);
			unsigned int left=middle-1,right=middle+1;
			double dleft,dright;
			while(true)
			{
				if(left>=N->enfant.size())
					dleft=left;
				else
					dleft=q-N->enfant[left]->max;
		
				if(right>=N->enfant.size())
					dright=(unsigned int)-1;
				else
					dright=N->enfant[right]->min-q;
				if(dleft == (unsigned int)-1  && dright == (unsigned int )-1)
					break;
				if(dleft<=dright)
				{
					double d=pow(dleft,2)+dLB;
					if(dk<=d)
						{left--;}//break;}
					else
					{
						searchOST(N->enfant[left],Q,d,rq,dk,result);
						left--;
					}
				}
				else
				{
					double d=pow(dright,2)+dLB;
					if(dk<=d)
						{right++;}//break;}
					else
					{
						searchOST(N->enfant[right],Q,d,rq,dk,result);
						right++;
					}
				}
			}
		}
	}
}



int main(int argc,char* argv[])
{
	int dim=5,width=256,height=256;
	int d=4,h=16,v=16,H=256;
	vector<leaf*>truc;
	truc.reserve(width*height);
	std::cout << "Cr�ation de l'arbre de recherche  ...  ";

	node root = node();
	for(int i=0;i<height;i++)
	for(int j=0;j<width;j++)
	{	
		leaf * pixel =new leaf(i,j,rand()%H,rand()%H,rand()%H);
		//pixel->resi(dim);
		root.feuille.push_back(pixel);
		truc.push_back(pixel);
		//pixel->display();
	}
	
	list<node*> stack;
	stack.push_back(&root);
	while(stack.size()>0)
	{
		node * N = stack.front();
		stack.pop_front();
		if(N->depth< dim && N->feuille.size()>d)
		{
			vector<int>histo(H,0);
			//on calcule l'histogramme
			for(int i=0;i<N->feuille.size();i++)
			{
				histo[(unsigned int)N->feuille[i]->get(N->depth)]++;
			}
			//on calcule l'histogramme cumul� pour le counting sort
			for(int m=1;m<H;m++)
			{	
				histo[m]+=histo[m-1];
			}

			vector<leaf*>fTriNew=N->feuille;
			//insertion des feuilles au bon endroit dans le tableau
			for(unsigned int i=0;i<fTriNew.size();i++)
			{
				leaf * tLeaf = fTriNew[i];
				histo[tLeaf->get(N->depth)]--;
				int tA = histo[tLeaf->get(N->depth)];
				double test = tLeaf->get(N->depth);
				//tLeaf->ri=sqrt(pow(tLeaf->ri,2)-pow(test,2));
				N->feuille[tA]=tLeaf;
			}

			//creation des nodes enfants
			int compteur=0;
			for(int i=0;i<d;i++)
			{
				node * Node = new node(N);
				for(int j = compteur;j<compteur+ceil((N->feuille.size()-compteur)/(d-i));j++)
				{
					Node->feuille.push_back(N->feuille[j]);
				}
				compteur+=ceil((N->feuille.size()-compteur)/(d-i));
				Node->min=Node->feuille.front()->get(N->depth);
				Node->max=Node->feuille.back()->get(N->depth);
				stack.push_back(Node);
			}	
		}
	}


	cout << "DONE"<< endl;

	//root.display();

	leaf * pixel;
	pixel = truc[truc.size()/2];
	vector<leaf*> result;
	cout << "Recherche en cours ..."<< endl;

	int machin=600;
	clock_t t;
	t=clock();
	searchOST(&root,pixel,0,sqrt(dist(pixel,&leaf(0,0,0,0,0))),machin,&result);
	t=clock()-t;
	cout << " (" << pixel->x << "," << pixel->y << "):" << pixel->r << "," << pixel->v << "," << pixel->b<< endl;
	cout << endl << "result PAT ( "<< t << " ):" << result.size()<<endl;
	for(unsigned int i=0;i<result.size();i++)
	{
		cout << dist(result[i],pixel) << ":" ;
		result[i]->display();
	}

	vector<leaf*>result2;
	clock_t s;
	s=clock();
	for(unsigned int i=0;i<truc.size();i++)
		if(dist(truc[i],pixel)<=machin)
			result2.push_back(truc[i]);
	s=clock()-s;
	cout << endl << "result FSA( "<< s << " ):"<< result2.size()<<endl;
	for(unsigned int i=0;i<result2.size();i++)
	{
		cout << dist(result2[i],pixel) << ":" ;
		result2[i]->display();
	}
cout << endl << "result PAT ( "<< t << " ):" << result.size()<<endl;
cout << endl << "result FSA( "<< s << " ):"<< result2.size()<<endl;

}

