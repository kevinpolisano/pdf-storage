#include <list>
#include <vector>
#include "Pixel.h"


using namespace std;
class node
{
public:
	node *parent;
	vector<node*> enfant;
	vector<Pixel*> feuille;
	double min,max;
	int depth;
	
	node(void)
	{	
		parent=0;
		depth=0;
	}

	node(node * tempParent)
	{
		parent=tempParent;
		depth=tempParent->depth+1;
		tempParent->enfant.push_back(this);
		/*for(int i = 0;i<depth;i++)
				cout << "	";
		cout << depth<<endl;//<< "@" << this <<endl;*/
	}

	~node(void)
	{}
	void display()
	{

		for(int i = 0;i<depth;i++)
				cout << "|  ";
		cout << depth <<"(" << min << "-" << max << ")"<<" child:" << enfant.size() << " | " << feuille.size()<<endl;
		
		for(unsigned int j=0;j< feuille.size();j++)
			{
				for(int i = 0;i<=depth;i++)
						cout << "|  ";
				feuille[j]->display();
			}

		for(unsigned int j=0;j< enfant.size();j++)
			{
				enfant[j]->display();
			}

	}
	
	
	int getArgmin(vector<double> & Q,double dLB)
	{
		int result=-2;

		if(enfant.size()==0)
			result=-1;
		else
		  {
		    // j'ai changé ici
			double q=Q[depth];
			for(unsigned int i=0;i<enfant.size();i++)
			{
				if(q<=enfant[i]->max)
				{
					result=i;
					break;
				}
			}
		}
		
		if(result==-2)
			result=enfant.size()-1;

		return result;
	}
};

