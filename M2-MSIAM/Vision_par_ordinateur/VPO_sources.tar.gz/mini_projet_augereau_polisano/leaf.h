#include <list>
#include <vector>

using namespace std;

class leaf
{
public:
	double x,y,r,v,b,ri;

	leaf(double tX,double tY,double tR,double tV,double tB):x(tX),y(tY),r(tR),v(tV),b(tB),ri(0)//sqrt(tX*tX+tY*tY+tR*tR+tV*tV+tB*tB))
	{}
	~leaf(void)
	{
	}

	void resi(int dim)
	{
		switch(dim)
		{
		case 5:ri+= x*x+y*y;
		case 3:ri+= v*v+b*b;
		case 1:ri+= r*r;
		default:ri=sqrt(ri);
		}
	}
	
	void display()

	{
	 cout <<"("<<x << "," <<y << "):"<<r<<"," <<v << "," << b << endl; 
	}

	double get(int depth)
	{
		double result=0;
		switch(depth)
		{	
			case 0: result= y;break;
			case 1: result= x;break;
			case 2: result= r;break;
			case 3: result= v;break;
			case 4: result= b;break;
		}
		return result;
	}
};

 