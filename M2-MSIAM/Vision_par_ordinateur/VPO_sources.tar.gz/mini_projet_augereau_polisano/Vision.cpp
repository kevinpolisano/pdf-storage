#include <iostream>
#include <cstring>
#include <float.h>
#include <string>
#include <locale>
#include <algorithm>
#include <stdlib.h>
#include <time.h>
#include "Image.h"
#include "Distance.h"
#include "distances.h"
#include "Noyau.h"

using namespace std;

int main()
{
        /* Choix de l'image */
	string name = "grenouillemini";
	string extension = ".ppm";
	Image img = Image("images/"+name+extension);
	
	bool pos = true;
	img.constructTree(pos);
	bool color = img.getColor();
	

	// Choix des param�tres de segmentation MS 
	double tol = 0.1;
	double b = 15;
	double hs = b;
	double hr = b;

	// Choix des param�tres de segmentation KM 
	double cond_arret = 100;
	int nb_clusters = 5;

	// Choix de la distance 
	string d_name = "euclidienne";
	string k_name = "uniforme";
	
	Distance d = Distance(pos,color,euclidienne);

	// Choix du noyau 
	
	Noyau * K = new Noyau(pos,color,hs,hr,&d,uniforme);

	// Segmentation de l'image 
	Image imgseg = img.MeanShift(K,b,tol);
	saveMS(imgseg,name,extension,d_name,k_name,pos,hs,hr,b,tol);
	//	Image imgsegKM = img.Kmean(cond_arret,nb_clusters,pos);
	//	saveKM(imgsegKM,name,extension,cond_arret,nb_clusters,pos);
	
	/* Pour avoir le rendu en couleur, on affecte le barycentre des couleurs d'une m�me classe */
	int numclass= imgseg.getVmax()+1;
		
	vector<vector<double> >Kclasse;
	vector<int> Kpoid(numclass,0);
	vector<double>temp(3,0);
		
	for(int i = 0; i < numclass;i++)
	{	
		Kclasse.push_back(temp);		
	}
	
	for(unsigned int i=0;i<img.getNumcols()*img.getNumrows();i++)
	{
			int ind=imgseg[i];
			int poid = Kpoid[ind];
			//cout << "indice: " << ind << " " << "poid: "<< poid << " " << img.red[i] << "," << img.green[i] << "," << img.blue[i]<< "	";
			//cout << Kclasse[ind][0] << "," << Kclasse[ind][1] << "," << Kclasse[ind][2]<< "			";
			
		 	Kclasse[ind][0]=1/(double)(poid+1)*(poid*Kclasse[ind][0] + img.red[i] );
		 	Kclasse[ind][1]=1/(double)(poid+1)*(poid*Kclasse[ind][1] + img.green[i] );
		 	Kclasse[ind][2]=1/(double)(poid+1)*(poid*Kclasse[ind][2] + img.blue[i] );
		 	//
		 	//cout << Kclasse[ind][0] << "," << Kclasse[ind][1] << "," << Kclasse[ind][2] << endl;
		 	
			Kpoid[ind]++;

	}
	
	for(int i = 0; i < numclass;i++)
	{
		Kclasse[i][0]=floor(Kclasse[i][0]);
		Kclasse[i][1]=floor(Kclasse[i][1]);
		Kclasse[i][2]=floor(Kclasse[i][2]);		
	}

	for(unsigned int i=0;i<img.getNumcols()*img.getNumrows();i++)
	{
		int ind=imgseg[i];
		img.red[i]=Kclasse[ind][0];
		img.green[i]=Kclasse[ind][1];	
		img.blue[i]=Kclasse[ind][2];
		//
		
	}
	

	img.save(name+"_seg_color"+extension);

}
