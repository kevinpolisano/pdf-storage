#ifndef _DISTANCE_H
#define _DISTANCE_H

#include <vector>
#include <math.h>
#include <assert.h>
#include "distances.h"

using namespace std;

class Distance {

 private:
  bool color;
  bool pos;
  double (*dist)(vector<double> * P1, vector<double> * P2);

 public:
  Distance(bool c, bool p, double d(vector<double> * P1,vector<double> * P2));
  double operator()(vector<double> * P1, vector<double> * P2);

};

#endif
