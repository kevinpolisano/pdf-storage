#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>

#include <iostream>

#include "client_cubtile.h"

ClientCubtile::ClientCubtile(const char * hostname, unsigned int num_port){
	sock = socket(AF_INET, SOCK_DGRAM, 0);
	if(sock == -1) {
		perror("Erreur dans l'initialisation de la socket()");
		exit(errno);
	}

	struct hostent *hostinfo = NULL;

	addr_serv_size = sizeof(struct sockaddr_in);

	hostinfo = gethostbyname(hostname);
	if (hostinfo == NULL) {
		fprintf (stderr, "Unknown host %s.\n", hostname);
		exit(EXIT_FAILURE);
	}

	addr_serv.sin_addr = * (struct in_addr *) hostinfo->h_addr;
	addr_serv.sin_port = htons(num_port);
	addr_serv.sin_family = AF_INET;
	
}

void ClientCubtile::sendInfo(const char typeEvent, ID_FACE f, int id, double posX, double posY){
	
// 	strcpy(buffer, "test");

// 	unsigned int curseur=0;
// 	memcpy((void*) buffer, (void*) &typeEvent, sizeof(char));
// 	curseur+=sizeof(char);
// 	memcpy((void*) (buffer+curseur), (void*) &f, sizeof(f));
// 	curseur+=sizeof(f);
// 	memcpy((void*) (buffer+curseur), (void*) &id, sizeof(id));
// 	curseur+=sizeof(id);
// 	memcpy((void*) (buffer+curseur), (void*) &posX, sizeof(posX));
// 	curseur+=sizeof(posX);
// 	memcpy((void*) (buffer+curseur), (void*) &posY, sizeof(posY));
// 	curseur+=sizeof(posY);
	
// 	memcpy((void*) buffer+sizeof(char)+sizeof(f), id);
// 	memcpy((void*) buffer+sizeof(char)+sizeof(f)+sizeof(int), posX);
// 	memcpy((void*) buffer+sizeof(char)+sizeof(f)+sizeof(int)+sizeof(double), posY);
	
// 	if( sendto(sock, buffer, strlen(buffer)+1, 0, (struct sockaddr *) &addr_serv, addr_serv_size) < 0) {
// 		perror("sendto()");
// 		exit(errno);
// 	}
	
	Paquet p;
	p.typeEvent = typeEvent;
	p.face = f;
	p.id = id;
	p.posX = posX;
	p.posY = posY;
	std::cout << "Paquet a envoyer\n";
	std::cout << " typeEvent=" << p.typeEvent;
	std::cout << " face=" << p.face;
	std::cout << " id=" << p.id;
	std::cout << " posX=" << p.posY;
	std::cout << " posY=" << p.posX << std::endl;

	if( sendto(sock, &p, sizeof(p), 0, (struct sockaddr *) &addr_serv, addr_serv_size) < 0) {
		perror("sendto()");
		exit(errno);
	}
}