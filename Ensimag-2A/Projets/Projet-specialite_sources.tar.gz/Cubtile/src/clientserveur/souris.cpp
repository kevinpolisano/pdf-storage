
#include <X11/Xlib.h>
#include <X11/Xutil.h>

#include "souris.H"

Souris::Souris(){ 
	x=1000;
	y=1000;
}

void Souris::move(int dx, int dy){
	x+=dx;
	y+=dy;
	
	Display *dpy;
	Window root_window;
	dpy = XOpenDisplay(0);
	root_window = XRootWindow(dpy, 0);
	XSelectInput(dpy, root_window, KeyReleaseMask);
	XWarpPointer(dpy, None, root_window, 0, 0, 0, 0, x, y);
	XFlush(dpy); // Flushes the output buffer, therefore updates the cursor's position. Thanks to Achernar.
}