/**
 * @file main.cpp
 * @brief Le programme principal
 */

#include <iostream>
#include <ctime>

#include "simple_event.H"
#include "cubtile.H"
#include <pthread.h>


volatile bool arret = false;

void *arretThread(void * a) {
	int b;
	std::cout<<"Tapez sur une touche pour quitter"<<std::endl;
	std::cin>>b;
	arret = true;
  return NULL;
}

int main(int argc, char * argv[]){

	Cubtile cubtile(argc, argv);
	
	cubtile.calibrer();


	
	cubtile.addEventMotionAll(eMotion);
	cubtile.addEventAppearAll(eAppear);
	cubtile.addEventDisappearAll(eDisappear);

	pthread_t thread;

	pthread_create(&thread, NULL, arretThread, NULL);


	cubtile.mainLoop(arret, FACEB, TRACK, BARYCENTRE_VALEURS_PX);


	return 0;
}

