#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <netdb.h>
#include <string.h>

#include <iostream>
enum ID_FACE{
	FACEH,
	FACEB,
	FACEM,
	FACED,
	FACEG
};

typedef struct _paquet
{
	char typeEvent;
	ID_FACE face;
	int id;
	double posX;
	double posY;
} Paquet;

int main(int argc, char* argv []){
	int sock = socket(AF_INET, SOCK_DGRAM, 0);
	if(sock == -1) {
		perror("socket()");
		exit(errno);
	}

	struct sockaddr_in sin;
	sin.sin_addr.s_addr = htonl(INADDR_ANY);
	sin.sin_family = AF_INET;
	sin.sin_port = htons(25555);

	if(bind (sock, (struct sockaddr *) &sin, sizeof sin) == -1)
	{
		perror("bind()");
		exit(errno);
	}


	char buffer[1024];
	struct sockaddr_in socket_client;
	socklen_t socket_client_size = sizeof(struct sockaddr_in);

	int n=0;
	while(1){
		n=0;
// 		if((n = recvfrom(sock, buffer, sizeof(buffer) - 1, 0, (struct sockaddr *) &socket_client, &socket_client_size)) < 0) {
// 			perror("recvfrom()");
// 			exit(errno);
// 		}
// 		
// 		char chaine[n];
// 		
// 		strncpy(chaine, buffer, n);
// 		std::cout << "Nombre octets recus : " << n << std::endl;
// 		std::cout << "Message recu : " << chaine << std::endl;
// 		memset(buffer, 0, 1024*sizeof(char));

		Paquet p;
		
		if(( n = recvfrom(sock, &p, sizeof(p), 0, (struct sockaddr *) &socket_client, &socket_client_size)) < 0) {
			perror("recvfrom()");
			exit(errno);
		}
		std::cout << "Nombre octets recus : " << n << std::endl;
		std::cout << "Paquet recu - typeEvent=" << p.typeEvent << " face=" << p.face << " id=" << p.id << " posX=" << p.posY << " posY=" << p.posX << std::endl;
/*
		char chaine[n];
		sprintf(chaine, "%c", buffer[0]);
		
		sprintf(chaine+1, "%i", buffer[1]);
		sprintf(chaine+1, "%d", a);
		sprintf(chaine+1, "%d", a);
		sprintf(chaine+1, "%d", a);
		
		unsigned int curseur=0;
		memcpy((void*) buffer, (void*) &typeEvent, sizeof(char));
		curseur+=sizeof(char);
		memcpy((void*) (buffer+curseur), (void*) &f, sizeof(f));
		curseur+=sizeof(f);
		memcpy((void*) (buffer+curseur), (void*) &id, sizeof(id));
		curseur+=sizeof(id);
		memcpy((void*) (buffer+curseur), (void*) &posX, sizeof(posX));
		curseur+=sizeof(posX);
		memcpy((void*) (buffer+curseur), (void*) &posY, sizeof(posY));
*/
	}
}
