#ifndef CLIENT_CUBTILE_H
#define CLIENT_CUBTILE_H

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>

#include "util.H"

typedef struct _paquet
{
	char typeEvent;
	ID_FACE face;
	int id;
	double posX;
	double posY;
} Paquet;

class ClientCubtile
{
private:
	int sock;
	struct sockaddr_in addr_serv;
	int addr_serv_size;
	
	char buffer[32];
public:
	ClientCubtile(const char * hostname, unsigned int num_port);
	void sendInfo(const char typeEvent, ID_FACE face, int id, double posX, double posY);
};

#endif
