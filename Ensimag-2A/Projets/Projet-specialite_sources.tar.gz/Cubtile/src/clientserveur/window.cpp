Window::Window() : QMainWindow()
{
	setFixedSize(600, 400);
// 	panneauPrincipal
}