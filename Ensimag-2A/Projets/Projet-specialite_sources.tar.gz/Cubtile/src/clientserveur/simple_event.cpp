#include <iostream>

#include "util.H"
#include "simple_event.H"
#include "client_cubtile.h"

 static ClientCubtile cc("localhost", 25555);
//static ClientCubtile cc("192.168.146.130", 25555);

static int appear = 0;
static int disappear = 0;
static int motion = 0;

void eAppear(InfoEvent I){
	std::cout<<"\nAppear-----------------"<<std::endl;
	I.afficher();
	
	cc.sendInfo('a', I.face, I.idPoint, I.pos.x, I.pos.y);
	appear++;
	
}

void eDisappear(InfoEvent I){
	std::cout<<"\nDisappear--------------"<<std::endl;
	I.afficher();
	
	cc.sendInfo('d', I.face, I.idPoint, I.pos.x, I.pos.y);
	disappear++;
}

void eMotion(InfoEvent I){
	std::cout<<"\nMotion-----------------"<<std::endl;
	I.afficher();

	cc.sendInfo('m', I.face,  I.idPoint, I.pos.x, I.pos.y);
	
	motion++;
}

int getNbAppear(){
	return appear;
}
int getNbDisappear(){
	return disappear;
}
int getNbMotion(){
	return motion;
}
