#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>

#include <iostream>

// #include "util.h"

int main(int argc, char* argv []){
	int sock = socket(AF_INET, SOCK_DGRAM, 0);
	if(sock == -1) {
		perror("socket()");
		exit(errno);
	}

	struct hostent *hostinfo = NULL;
	struct sockaddr_in addr_serv;

	const char *hostname = "localhost";
	int addr_serv_size = sizeof(struct sockaddr_in);

	hostinfo = gethostbyname(hostname);
	if (hostinfo == NULL) {
		fprintf (stderr, "Unknown host %s.\n", hostname);
		exit(EXIT_FAILURE);
	}

	addr_serv.sin_addr = * (struct in_addr *) hostinfo->h_addr;
	addr_serv.sin_port = htons(25555);
	addr_serv.sin_family = AF_INET;
	
	char buffer[1024];
	
	int i=0;
// 	while(1){
// 		if(i%150==0){
	// 		std::cout << "Donnez une chaine : " << std::endl;
	// 		std::cin.getline(buffer, 1024);
// 			strcpy(buffer, argv[1]);


			char typeEvent = 'm';
			int f = 4;
			int id = 0;
			double posX = 111.1111;
			double posY = 333.3333;
			
			unsigned int curseur=0;
			memcpy((void*) buffer, (void*) &typeEvent, sizeof(char));
			curseur+=sizeof(char);
			memcpy((void*) (buffer+curseur), (void*) &f, sizeof(f));
			curseur+=sizeof(f);
			memcpy((void*) (buffer+curseur), (void*) &id, sizeof(id));
			curseur+=sizeof(id);
			memcpy((void*) (buffer+curseur), (void*) &posX, sizeof(posX));
			curseur+=sizeof(posX);
			memcpy((void*) (buffer+curseur), (void*) &posY, sizeof(posY));
			
			if( sendto(sock, buffer, strlen(buffer)+1, 0, (struct sockaddr *) &addr_serv, addr_serv_size) < 0) {
				perror("sendto()");
				exit(errno);
			}
			
			buffer[0] = '\0';
// 		}
// 		i++;
// 	}
}