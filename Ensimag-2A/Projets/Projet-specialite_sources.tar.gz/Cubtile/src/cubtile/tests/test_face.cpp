#include <iostream>
#include "face.H"



int main(int argc, char * argv[]){


	FaceH f;
	Matrx img, img2;

	if(argc<2){
		std::cout<<"Usage: main <image-file-name>"<<std::endl;
		exit(0);
	}

	// load an image  
	img2=Matrx(cv::imread(argv[1], 1));
	if(!img2.data){
		std::cout << "Could not load image file: " << argv[1] << std::endl;
		exit(0);
	}

	// On passe de 3 à 1 seul canal
	if(img2.channels()>1)
		cvtColor(img2, img, CV_RGB2GRAY);


	f.configurer();
	f.configurerAffichage( PROPRE, 0);

	f.initNextFrame(img);

	f.redresser();

	/**
		Manque choses...
		*/

	f.tracker(false);


	std::cout<<"Ne fonctionne pas"<<std::endl;
	exit(1);
}

