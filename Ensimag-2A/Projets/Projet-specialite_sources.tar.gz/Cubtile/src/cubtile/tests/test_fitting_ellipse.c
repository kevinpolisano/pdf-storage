#include "fitting_ellipse.h"

void test_initMatFit(){
	matFitting* A = initMatfit(3,3);
	afficher(A);
}

void test_initFit(){
	fitting* B = initFit();
	B->qDesignM.mat[1][1] = 0;
}

void test_matProduit(){
	int i,j;
	matFitting* A = initMatfit(3,3);
	matFitting* C = initMatfit(3,3);
	afficher(A);
	for( i = 0; i < A->lineUsed; ++i){
		for ( j = 0; j < A->colUsed;++j){
			A->mat[i][j] = C->mat[i][j] = 1;
		}
	}
	matFitting* prod = produitMat(A,C);
	afficher(prod);
}

void test_allouemat(){
	double ** test =alloue_mat(3,3);
	test[2][1] = 4;
}

void test_transpose(){
	matFitting* A = initMatfit(2,3);
	matFitting* C = transpose(A);
	afficher(C);
}

void test_determinant(){
	int i,j;
	matFitting* A = initMatfit(3,3);
	for( i = 0; i < A->lineUsed; ++i){
		for ( j = 0; j < A->colUsed;++j){
			A->mat[i][j] = 1;
		}
	}
	printf("%f \n",determinant(A));
	matFitting* C = initMatfit(3,3);
	for( i = 0; i < C->lineUsed; ++i){
		C->mat[i][i] = 1;
	}
	printf("%f \n",determinant(C));
	C->mat[0][0] =3 ; C->mat[0][1] =1 ; C->mat[0][2] =8 ;
	C->mat[1][0] =2 ; C->mat[1][1] =-5 ; C->mat[1][2] =4 ;
	C->mat[2][0] =-1 ; C->mat[2][1] =6 ; C->mat[2][2] =-2 ;
	printf("%f \n",determinant(C));
}

void test_inverse(){
	int i;
	// inverse de la matrice identité
	matFitting* C = initMatfit(3,3);
	for( i = 0; i < C->lineUsed; ++i){
		C->mat[i][i] = 1;
	}
	afficher(C);
	matFitting* A;
	A = inv(C);
	afficher(A);
	C->mat[0][0] =-1 ; C->mat[0][1] =3 ; C->mat[0][2] =-3 ;
	C->mat[1][0] =0 ; C->mat[1][1] =-6 ; C->mat[1][2] =5 ;
	C->mat[2][0] =-5 ; C->mat[2][1] =-3 ; C->mat[2][2] =1 ;
	A = inv(C);
	afficher(A);

}

int main(){
	test_allouemat();
	test_initMatFit();
	test_initFit();
	test_matProduit();
	test_transpose();
	test_determinant();
	test_inverse();
	return 0;
}
