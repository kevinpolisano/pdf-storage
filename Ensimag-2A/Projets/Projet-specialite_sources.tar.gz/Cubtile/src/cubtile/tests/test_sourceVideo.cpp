#include "sourceVideo.H"



int main(int argc,char* argv[]){
	SourceVideo2 S(argc, argv);


	Matrx frame(S);
	S.demarrer();
	cv::namedWindow("superimage",1);
	for(int i = 0; i<100; i++){
		S.dequeueFrame(&frame);
		cv::imshow( "Video",frame);
		S.enqueueFrame(&frame);
		if(cv::waitKey(30) >= 0) break;
	}
	S.arreter();
}
