#include <iostream>
#include "face.H"



int main(int argc, char * argv[]){
	

	FaceH f;
	Matrx img, img2;

	if(argc<2){
		std::cout<<"Usage: main <image-file-name>"<<std::endl;
		exit(0);
	}

	// load an image  
	img2=Matrx(cv::imread(argv[1], 1));
	if(!img2.data){
		std::cout << "Could not load image file: " << argv[1] << std::endl;
		exit(0);
	}
	
	// On passe de 3 à 1 seul canal
	if(img2.channels()>1)
		cvtColor(img2, img, CV_RGB2GRAY);



	f.configurer();
	f.configurerAffichage(NOPERSP, 0);

	f.initNextFrame(img);

	int L = 200; // plus tard faire un accesseur pour f.imageRecadree.cols;

	int xe = 86;
	int ye = L-88;
	int xf = 162;
	int yf = L-88;

	f.supprPersp(xe,ye,xf,yf);

}

