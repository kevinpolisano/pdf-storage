#include "eventsCubtile.H"
#include <iostream>

int i = 0;

void appel(InfoEvent I){
	//I.tact.afficher();
	std::cout<<"Je suis appele"<<::std::endl;
	i = 1;
}

int main(){

	EventsCubtile E;

	
	Tact t(cv::Point2d(1, 1), clock());

	E.addEventMotion(Event(&appel));

	E.callEventMotion(InfoEvent(FACEH, 1, t.getPos()));

	if(i!=1) return 1;
	else return 0;

}
