#ifndef __PARSER__
#define __PARSER__

#include <string>
#include <stdio.h>
#include <iostream>
#include <vector>

typedef struct _Point{
	double x;
	double y;
}Point;

std::vector<Point> parse(std::string filename);



#endif
