#include <iostream>
#include <fstream>
#include <string>

#include <vector>
#include "parser.h"
#include <RInside.h>

using namespace std;

vector<Point> parse(string filename){
	FILE* fichier;
	fichier = fopen(filename.c_str(),"r");
	int retval = 1;
	double d;
	vector<Point> vec;
	Point p;
	if ( fichier != NULL){
		while(retval){
			if ((retval=fscanf(fichier,"%lg",&d)!=EOF) && retval) {
				p.x = d;
			} else {
				break;
				std::cout << "erreur fichier erroné" << std::endl;
			}
			if ((retval=fscanf(fichier,"%lg",&d)!=EOF) && retval) {
				p.y = d;
			} else {
				std::cout << "erreur fichier erroné" << std::endl;
				break;
			}
			vec.push_back(p);
		}
	} else {
		std::cout << "Erreur à l'ouverture" << std::endl;
	}
	fclose(fichier);
	return vec;
}


int main(int argc, char *argv[])
{
	// create a vector
	vector<Point> p;
	string name = argv[1];
	p = parse(name);

	vector<double> vx,vy;
	for ( unsigned i = 0 ; i < p.size(); ++i){
		vx.push_back(p[i].x);
		vy.push_back(p[i].y);
	}	
	
	// create an embedded R instance
	RInside R(argc, argv);

	// create a variable points contening the vector points	
	R.assign(vx,"px");
	R.assign(vy,"py");

	// create a variable contening the size of the vector points
	R.parseEval("size<-length(px)");

	// create a vector contening the points 1..size
	R.parseEval("x<-c(1:size)");

	// do the linear regression
	R.parseEval("regx<-lm(px~x)");
	R.parseEval("regy<-lm(py~x)");

	/*
	 * Uncomment the three following lines to save the plot result
	 * of the regression in a pdf file
	 */

	R.parseEval(" pdf('reg_linaire_x.pdf') ");
	R.parseEval("plot(px~x)");R.parseEval("abline(regx)");
	R.parseEval("dev.off()");
	R.parseEval(" pdf('reg_linaire_y.pdf') ");
	R.parseEval("plot(py~x)");R.parseEval("abline(regy)");


	// extract the residual vector
	R.parseEval("resix<-residuals(regx)");
	R.parseEval("resiy<-residuals(regy)");

	//extract the maximum
	R.parseEval("maxResx<-max(resix)");
	R.parseEval("maxResy<-max(resiy)");

	double precisionx = R["maxResx"];
	double precisiony = R["maxResy"];

	cout << " L'application est avec une précision de " << precisionx << " pixels selon x!" << endl;
	cout << " L'application est avec une précision de " << precisiony << " pixels selon y!" << endl;



	


}
