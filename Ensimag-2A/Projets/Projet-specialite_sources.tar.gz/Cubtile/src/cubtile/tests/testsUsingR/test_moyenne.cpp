#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include <RInside.h>

#include "parser.h"


using namespace std;


vector<Point> parse(string filename){
	FILE* fichier;
	fichier = fopen(filename.c_str(),"r");
	int retval = 1;
	double d;
	vector<Point> vec;
	Point p;
	if ( fichier != NULL){
		while(retval){
			if ((retval=fscanf(fichier,"%lg",&d)!=EOF) && retval) {
				p.x = d;
			} else {
				break;
				std::cout << "erreur fichier erroné" << std::endl;
			}
			if ((retval=fscanf(fichier,"%lg",&d)!=EOF) && retval) {
				p.y = d;
			} else {
				std::cout << "erreur fichier erroné" << std::endl;
				break;
			}
			vec.push_back(p);
		}
	} else {
		std::cout << "Erreur à l'ouverture" << std::endl;
	}
	fclose(fichier);
	return vec;
}




int main(int argc, char *argv[])
{
	
	// create a vector
	vector<Point> p;
	string name = argv[1];
	p = parse(name);

	vector<double> vx,vy;
	for ( unsigned i = 0 ; i < p.size(); ++i){
		vx.push_back(p[i].x);
		vy.push_back(p[i].y);
	}	
	
	// mean of the points
	double moyx, moyy;

	// create an embedded R instance
	RInside R(argc, argv);

	R.assign(vx,"x");
	R.assign(vy,"y");

	// compute the mean of the vector
	R.parseEval("moyx<-mean(x)");
	moyx=R["moyx"];
	R.parseEval("moyy<-mean(y)");
	moyy=R["moyy"];

	cout <<  moyx << " " << moyy << endl;
	
	return 0;
}
