#include "parser.h"

using namespace std;

vector<Point> parse(string filename){
	FILE* fichier;
	fichier = fopen(filename.c_str(),"r");
	int retval = 1;
	double d;
	vector<Point> vec;
	Point p;
	if ( fichier != NULL){
		while(retval){
			if ((retval=fscanf(fichier,"%lg",&d)!=EOF) && retval) {
				p.x = d;
			} else {
				break;
				std::cout << "erreur fichier erroné" << std::endl;
			}
			if ((retval=fscanf(fichier,"%lg",&d)!=EOF) && retval) {
				p.y = d;
			} else {
				std::cout << "erreur fichier erroné" << std::endl;
				break;
			}
			vec.push_back(p);
		}
	} else {
		std::cout << "Erreur à l'ouverture" << std::endl;
	}
	fclose(fichier);
	return vec;
}

int main(int argc, char *argv[]){
	string name = argv[1];
	vector<Point> v = parse(name); 
	for ( unsigned i = 0; i < v.size(); ++i){
		std::cout << v[i].x << " " << v[i].y << std::endl;
	}
	
	return 1;
}
