#include <iostream>
#include <fstream>
#include "cubtile.H"
#include "util.H"
#include <pthread.h>
#include <string>
#include <stdio.h>


using namespace std;

ofstream myfile;

void fonction(InfoEvent I){
	myfile<<I.pos.x<<" "<<I.pos.y<<std::endl;
}


volatile bool arret = false;

void *arretThread(void * a) {
	int b;
	std::cout<<"Tapez sur une touche pour quitter"<<std::endl;
	std::cin>>b;
	arret = true;
	return NULL;
}




int main (int argc, char * argv[]) {

	CHOIX_ALGO algo = BARYCENTRE;

	if ( argc > 2 ) {
		int param = atoi(argv[2]);
		algo = CHOIX_ALGO(int(algo)+param);
	}

	Cubtile Cube(argc, argv);

	// le nombre d'itérations pour calculer la variation
	Cube.calibrer();

	myfile.open("positions_motions.dat");

	Cube.addEventMotion(FACEG, &fonction);

	Cube.mainLoopMesure(arret, FACEG, TRACK, algo,4); 
	myfile.close();

	return 0;
	}
