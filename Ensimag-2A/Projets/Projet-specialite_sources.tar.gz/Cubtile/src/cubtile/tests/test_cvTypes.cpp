

#include <cv.h>
#include <iostream>

int main(){
	std::cout<<"CV_8UC1 : "<<CV_8UC1<<std::endl;
	std::cout<<"CV_8SC1 : "<<CV_8SC1<<std::endl;
	std::cout<<"CV_16UC1 : "<<CV_16UC1<<std::endl;
	std::cout<<"CV_16SC1 : "<<CV_16SC1<<std::endl;
	std::cout<<"CV_32SC1 : "<<CV_32SC1<<std::endl;
	std::cout<<"CV_32FC1 : "<<CV_32FC1<<std::endl;
	std::cout<<"CV_64FC1 : "<<CV_64FC1<<std::endl;




	return 0;
}
