#include <iostream>

#include "extraction.H"


int main(int argc, char * argv[]){


	Matrx img, img2,img3;

	if(argc<2){
		std::cout<<"Usage: main <image-file-name>"<<std::endl;
		exit(0);
	}

	// load an image  
	img2=Matrx(cv::imread(argv[1], 1));
	if(!img2.data){
		std::cout << "Could not load image file: " << argv[1] << std::endl;
		exit(0);
	}
	
	// On passe de 3 à 1 seul canal
	if(img2.channels()>1)
		cvtColor(img2, img, CV_RGB2GRAY);

	Extraction extra;

	extra.configurer(img, true);
	
	std::vector<cv::Point2d> vec;

	extra.extrairePoints(vec, img, DISQUE);

	for( unsigned int i=0 ; i< vec.size() ; ++i ){
		circle(img, vec[i], 3, cv::Scalar_<int>(100, 100) );
		circle(img, vec[i], 4, cv::Scalar_<int>(150, 150) );
	}
	//img.afficher(0);





}
