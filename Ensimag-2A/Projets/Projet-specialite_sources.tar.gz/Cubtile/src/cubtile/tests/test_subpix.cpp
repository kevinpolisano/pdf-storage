#include "matx.H"



int main(){

	Matrx m(11, 11, CV_16SC1);


	std::cout<<m<<std::endl;


	m.getPx<short>(5, 5) = 1;
	m.getPx<short>(4, 5) = 1;
	m.getPx<short>(6, 5) = 1;
	m.getPx<short>(5, 4) = 1;
	m.getPx<short>(5, 6) = 1;
	
	m.getPx<short>(0, 10) = 3;
	std::cout<<m<<std::endl;

	std::cout<<m.getSubPx<short>(0, 10);

}
