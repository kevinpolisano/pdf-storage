


#include <iostream>

#include "extraction.H"


int main(int argc, char * argv[]){


	Matrx img, img2, img3, image, pattern;

	if(argc<3){
		std::cout<<"Usage: main <image-file-name>"<<std::endl;
		exit(0);
	}

	// load an image  
	img2=Matrx(cv::imread(argv[1], 1));
	img3=Matrx(cv::imread(argv[2], 1));
	if(!img2.data||!img3.data){
		std::cout << "Could not load image file: " << argv[1] << std::endl;
		exit(0);
	}
	
	// On passe de 3 à 1 seul canal
	if(img2.channels()>1){
		cvtColor(img2, image, CV_RGB2GRAY);
		cvtColor(img3, pattern, CV_RGB2GRAY);
	}

	Extraction extra;

	extra.configurer(image, true);

	std::vector<cv::Point2d> vec;

	std::cout<<image.type()<<pattern.type();

	cv::Point2d depart;
	cv::Point2d arrivee;
	depart.y = image.rows/2.;

	depart.x = image.cols/2.+0.03;

	arrivee = extra.blockMatching(image, pattern, depart, 0.02, 3);

	circle(image, arrivee, 10, cv::Scalar_<int>(100, 100) );
	
	std::cout<<arrivee<<std::endl;

	image.afficher(0);





}
