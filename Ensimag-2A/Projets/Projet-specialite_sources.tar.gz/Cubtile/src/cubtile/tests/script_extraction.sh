tabNom=(MAX_DIST_TRANS BARYCENTRE	BARYCENTRE_PONDERE_GAUSS BARYCENTRE_VALEURS_PX	ACANDIDATS XY_PROJ_ELLIPSE_FIT CUBTILE_DATA DISQUE GRADIENT_FLOU MEDIAN)

#on compile l'éxécutable
make test_sortie_motion
rm -r pos/
mkdir pos/
rm res.txt
touch res.txt
cd testsUsingR
make
cd ../
executable=${exe}" "${name}
for i in `seq 0 8`;
do
	./test_sortie_motion ~/Desktop/Cubtile/videos/doigtbougepascote.mov $i
	cd testsUsingR
	./test_variance ../positions_motions.dat >> ../res.txt
	cd ../
	mv positions_motions.dat pos/${tabNom[$i]}
done


