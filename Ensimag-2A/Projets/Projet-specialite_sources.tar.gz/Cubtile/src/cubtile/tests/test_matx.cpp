#include <sstream>
#include "matx.H"
#include <string>
#include <iostream>

void test_projectX(){
	// on crée une matrice test
	Matrx m(3,3,CV_8UC1);
	// on remplit la matrice
	m.at<unsigned char>(0,0) = 0; m.at<unsigned char>(0,1) =255 ; m.at<unsigned char>(0,2) = 0 ;
	m.at<unsigned char>(1,0) = 255; m.at<unsigned char>(1,1) = 0; m.at<unsigned char>(1,2) = 255;
	m.at<unsigned char>(2,0) = 255; m.at<unsigned char>(2,1) = 0; m.at<unsigned char>(2,2) = 0;
	Matrx hist;
	hist = m.getProjectedHistoX();
	for (int j = 0; j < 3; ++j){
		std::cout <<(int)hist.at<unsigned char>(1,j) << std::endl;
	}
}

void test_projectY(){
	// on crée une matrice test
	Matrx m(3,3,CV_8UC1);
	// on remplit la matrice
	m.at<unsigned char>(0,0) = 0; m.at<unsigned char>(0,1) =255 ; m.at<unsigned char>(0,2) = 0 ;
	m.at<unsigned char>(1,0) = 255; m.at<unsigned char>(1,1) = 0; m.at<unsigned char>(1,2) = 255;
	m.at<unsigned char>(2,0) = 255; m.at<unsigned char>(2,1) = 0; m.at<unsigned char>(2,2) = 0;


	Matrx hist;
	hist = m.getProjectedHistoY();
	for (int j = 0; j < 3; ++j){
		std::cout << (int)hist.at<unsigned char>(j,1) << std::endl;
	}


}
	void test_histo(){
		Matrx m(3,3,CV_8UC1);
	// on remplit la matrice
	m.at<unsigned char>(0,0) = 0; m.at<unsigned char>(0,1) =255 ; m.at<unsigned char>(0,2) = 0 ;
	m.at<unsigned char>(1,0) = 255; m.at<unsigned char>(1,1) = 0; m.at<unsigned char>(1,2) = 255;
	m.at<unsigned char>(2,0) = 255; m.at<unsigned char>(2,1) = 0; m.at<unsigned char>(2,2) = 0;
	m.histo();

	}

void test_seuilLineaire(){
	Matrx m(3,3,CV_8UC1);
	// on remplit la matrice
	m.at<unsigned char>(0,0) = 70; m.at<unsigned char>(0,1) =120 ; m.at<unsigned char>(0,2) = 70 ;
	m.at<unsigned char>(1,0) = 70; m.at<unsigned char>(1,1) = 120; m.at<unsigned char>(1,2) = 70;
	m.at<unsigned char>(2,0) = 70; m.at<unsigned char>(2,1) = 110; m.at<unsigned char>(2,2) = 70;
	Matrx res;
	seuilLineaire(m, res, 50,150);
	for ( int i = 0 ; i < res.rows ; i++){
		for ( int j = 0; j < res.cols ; ++j){
			std::cout << (int)res.at<unsigned char>(i,j) << " ";
		}
		std::cout << std::endl;
	}
}

int main(int argc, char * argv[]){

	Matrx img, img2;

	Matrx imgRedressee(200,200,CV_8UC1);

	if(argc<2){
		std::cout<<"Usage: main <image-file-name>"<<std::endl;
		exit(0);
	}

	// load an image  
	img2=Matrx(cv::imread(argv[1], 1));
	if(!img2.data){
		std::cout << "Could not load image file: " << argv[1] << std::endl;
		exit(0);
	}
	
	// On passe de 3 à 1 seul canal
	if(img2.channels()>1)
		cvtColor(img2, img, CV_RGB2GRAY);

	Matrx a(2, 1, CV_8UC1);

	a.getPx<unsigned char>(0, 0) = 10;
	a.getPx<unsigned char>(1, 0) = 15;

	//std::cout<<a;

	Matrx b(2, 1, CV_64FC1);

	b.getPx<double>(0, 0) = 10;
	b.getPx<double>(1, 0) = 15;

	//	imshow("bakl", b);
	//	b.afficher(0);
	//		std::cout<<b.type();

	for (int i = 0; i < img.cols; i++) {
		img.getPx<unsigned char>(10,i) = i % 255;
	}

	//	imshow("essai",img);
	//img.afficher(0);

	std::cout << "nombre de colonnes : " << imgRedressee.cols << std::endl;
	std::cout << "nombre de lignes : " << imgRedressee.rows << std::endl;

	int L = imgRedressee.cols;
	int xe = 86;
	int ye = L-88;
	int xf = 162;
	int yf = L-88;

	double xs = (L-yf)*L*xe/((double) L*(xe-ye-xf+L)+ye*xf-yf*xe);
	double h = (L*(yf+xs-xf)-yf*xs)/((double) L-xf);
	double l = ((L-xs)*yf)/((double) L*(xf-xs));
	double xM, yM;

	std::cout << "(xs,h,l) = (" << xs << "," << h << "," << l << "," << ")" <<  std::endl;

	int val = 20;

	int i,j;

	i = 149;
	j = 199;
	xM = (h/((l-1)*(L-i)+h))*(j-xs)+xs;
	yM = (h*l*(L-i))/((l-1)*(L-i)+h);
	//	val =  img.getPx<unsigned char>((int) L-yM,(int) xM);
	std::cout << "yM = " << yM << std::endl;
	std::cout << "xM = " << xM << std::endl;

	std::cout << "(" << i << "," << j << ") : " << val <<  std::endl;


	
	for (int i = 0; i < imgRedressee.rows; i++) {
			for (int j = 0; j < imgRedressee.cols; j++) {
				xM = (h/((l-1)*(L-i)+h))*(j-xs)+xs;
				yM = (h*l*(L-i))/((l-1)*(L-i)+h);
				val =  img.getSubPx<unsigned char>(L-yM,xM);
			   	//val =  img.getPx<unsigned char>((int) L-yM,(int) xM);
				std::cout << "(" << i << "," << j << ") : " << val <<  std::endl;
				imgRedressee.getPx<unsigned char>(i,j) = (unsigned char)val;
			}
	}

	imshow("redressement",imgRedressee);
	imgRedressee.afficher(0);

	std::cout << "(xs,h,l) = (" << xs << "," << h << "," << l << "," << ")" <<  std::endl;

	// test projection histogramme
	/*test_projectX();
	test_projectY();*/

	// test histogramme
	//test_histo();


		test_seuilLineaire();
}
