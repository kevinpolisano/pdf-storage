

#include "tact.H"
#include <iostream>
#include <cstdlib>

int main(){

	clock_t t = clock();
	int k;
	for(int i=0; i<10000000; i++){
		k++;
	}
	clock_t t2 = clock();

	std::cout<<"Nombre de ticks : "<<t2-t<<std::endl;

	cv::Point2d p1(0, 1);
	cv::Point2d p2(0, 1.5);

	Tact doigt(p1, (clock_t) t);

	
	doigt.afficher();

	doigt.maj(p2, t2);
	for(int i=0; i<10000000; i++){
		k++;
	}

	doigt.afficher();

}
