



#include <iostream>
#include <fstream>
#include "cubtile.H"
#include <pthread.h>



using namespace std;

int compteur = 0;

ofstream myfile;

void fonction(InfoEvent I){
	compteur++;
	myfile<<I.pos.x<<" "<<I.pos.y<<std::endl;
	//std::cout << I.tact.getPos() << std::endl;
	std::cout << compteur << std::endl;
}


volatile bool arret = false;

void *arretThread(void * a) {
	int b;
	std::cout<<"Tapez sur une touche pour quitter"<<std::endl;
	std::cin>>b;
	arret = true;
  return NULL;
}



int main (int argc, char * argv[]) {

	Cubtile Cube(argc, argv);


	Cube.calibrer();

	myfile.open ("positions_appear.dat");


	Cube.addEventAppear(FACEM, &fonction);

	pthread_t thread;

	pthread_create(&thread, NULL, arretThread, NULL);

	Cube.mainLoop(arret, FACEG, TRACK, BARYCENTRE_VALEURS_PX);

	myfile.close();
	return 0;
}
