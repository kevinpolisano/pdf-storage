data = read.table("/Users/sabativi/Desktop/Cubtile/src/cubtile/tests/histo.txt",header = T)
pdf('histo.pdf')
plot(data[,1],data[,2])
dev.off()

