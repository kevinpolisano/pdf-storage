R -q --vanilla < generer_histo.r
open histo.pdf
