#include<iostream>
#include "tracker.H"
#include "examples_event.H"
#include <iostream>




int main(){

	Tracker track(0.1);

	track.addEventMotion(Event(FACEM, eMot));
	track.addEventAppear(Event(FACEM, eApp));
	track.addEventDisappear(Event(FACEM, eDisapp));

	std::vector<cv::Point2d> pts1;

	pts1.push_back(cv::Point2d(0, 0));
	pts1.push_back(cv::Point2d(0, 1));
	pts1.push_back(cv::Point2d(1, 0));

	track.mettreAJour(pts1, clock());
	std::cout<<std::endl;
	track.signaler();
	std::cout<<std::endl;

	std::vector<cv::Point2d> pts2;

	clock_t t = clock();
	while(clock()-t<100000){
		
	}

	pts2.push_back(cv::Point2d(0, 0.05));
	pts2.push_back(cv::Point2d(10, 0));

	std::cout<<std::endl;
	track.mettreAJour(pts2, clock());
	std::cout<<std::endl;
	track.signaler();

	

	if(getNbApp() != 4){
		std::cout<<"Problème sur les appears : "<<std::endl;
		exit(1);
	}

	if(getNbMot() != 1){
		std::cout<<"Problème sur les motion"<<std::endl;
		exit(1);
	}

	if(getNbDisapp() != 1){
		std::cout<<"Problème sur les disappear"<<std::endl;
		exit(1);
	}

	return 0;

}
