#include <iostream>
#include <math.h>

#include "transformation.H"

double distance(coordPix p1, coordPix p2){
	return(sqrt((p1.x-p2.x)*(p1.x-p2.x) +(p1.y-p2.y)*(p1.y-p2.y)));
}


/* Renvoie le centre du cercle passant par P1,P2,P3 */
coordPix cercleTroisPts(coordPix P1, coordPix P2, coordPix P3) {
	double x1 = P1.x;
	double y1 = P1.y;
	double x2 = P2.x;
	double y2 = P2.y;
	double x3 = P3.x;
	double y3 = P3.y;

	double xc = x3*x3*(y1-y2)+x2*x2*(y3-y1)+x1*x1*(y2-y3);
	xc += y3*y3*(y1-y2)+y2*y2*(y3-y1)+y1*y1*(y2-y3);
	xc /= 2*(x3*(y1-y2)+x2*(y3-y1)+x1*(y2-y3));

	double yc = ((x1*x1-x2*x2-2*xc*(x1-x2))/(y1-y2)+y1+y2)/2;

	coordPix C;
	C.x = xc;
	C.y = yc;

	return C;

}

/* Renvoie le coefficient directeur et l'ordonnée à l'origine de la droite
 * passant par les points P1 et P2 */
coordPix droiteDeuxPts(coordPix P1, coordPix P2) {
	double x1 = P1.x;
	double y1 = P1.y;
	double x2 = P2.x;
	double y2 = P2.y;

	double a = (y2-y1)/(x2-x1);
	double b = y1 - a*x1;
	coordPix params;
	params.x = a;
	params.y = b;

	return params; 

}

/* Renvoie le point d'intersection des droites d1 et d2 (non parallèles) */
coordPix interDeuxDroites(coordPix d1, coordPix d2) {
	double a = d1.x;
	double b = d1.y;
	double c = d2.x;
	double d = d2.y;

	double x = (d-b)/(a-c);
	double y = a*x + b;

	coordPix inter;
	inter.x = x;
	inter.y = y;

	return inter;
}

double variationRayon(double x) {
	return 14.00695652+0.6518729097*x+0.03963210702*x*x;
}


double interpolRayonQuad(double r1, double r2, double alpha) {
	double a = variationRayon(1);
	double b = variationRayon(25);
	double h1 = (r2-r1)/(b-a);
	double h2 = r1 - h1*a;
	return h1*(variationRayon(24*alpha+1))+h2;
}

double interpolRayon(double r1, double r2, double alpha,
					 double * Lrayon, int tailleMap, int methode) {
	double res = 0;
	if (methode == 0) {
		res = (1-alpha)*r1 + alpha*r2;
	} else if (methode == 1) {
		res = interpolRayonQuad(r1,r2,alpha);
	} else if (methode == 2) {
		res = Lrayon[(int)floor((tailleMap-1)*alpha)];
	}
	return res;

}

coordPix interpolCentre(coordPix c1, coordPix c2, double alpha,
						coordPix * Lcentre, int tailleMap, int methode) {	
	coordPix res;
	if (methode == 2) {
		res = Lcentre[(int)floor((tailleMap-1)*alpha)];
	} else {
		res.x = alpha*c2.x + (1-alpha)*c1.x;
		res.y =	alpha*c2.y + (1-alpha)*c1.y;
	}
	return res;
}

double fctRepartition(double x, int tailleMap) {
	double a = variationRayon(1);
	double b = variationRayon(25);
	double h1 = 1/(b-a);
	double h2 = -h1*a;
	double g1 = (25-1)/(double)(tailleMap-1);
	double g2 = 1 - g1*1;
	return h1*(variationRayon(g1*x+g2))+h2;
}

void GenRepartition(coordPix P1, coordPix P2, coordPix * L, int tailleMap) {
	double x1 = P1.x;
	double y1 = P1.y;
	double x2 = P2.x;
	double y2 = P2.y;
	double PPx = x2-x1;
	double PPy = y2-y1;
	coordPix cour;
	for (int i = 0; i < tailleMap; i++) {
		cour.x = x1 + fctRepartition(i+1, tailleMap)*PPx;
		cour.y = y1 + fctRepartition(i+1, tailleMap)*PPy;
		L[i] = cour;
	}
}

/* Calcul un point du maillage, résultant de l'intersection d'un cercle (obtenu
 * par interpolation linéaire de coefficient alpha des cercles c1 et c2)
 * et d'une droite passant par G inclinée d'un angle theta par rapport 
 * à la droite (AD) passant également par G et de coefficient directeur a */
coordPix calculNoeud(double alpha, double theta, 
					 double a, coordPix G,
					 coordPix c1, coordPix c2, 
                     double r1, double r2, int tailleMap,
					 coordPix * Lcentre, double * Lrayon) {


	/* Calcul du centre interpolé linéairement par c1 et c2 */
	coordPix centre = interpolCentre(c1,c2,alpha,Lcentre,tailleMap,1);
	double x_alpha = centre.x;
	double y_alpha = centre.y;

	/* Calcul du rayon interpolé par r1 et r2 */
	double r_alpha = interpolRayon(r1,r2,alpha,Lrayon,tailleMap,1);

	/* Calcul de la droite passant par G faisant un angle theta avec dAD */
	double xG = G.x;
	double yG = G.y;
	double a_theta = (a+tan(theta))/(1-a*tan(theta));

	/* vecteur directeur de la droite d_theta précédente */
	double ux = -1;
	double uy = -a_theta;

	/* L'intersection du cercle C_alpha avec la droite d_theta est donnée 
	 * par la résolution d'une équation du second degré dont les coefficients
	 * sont : */
	double ak = ux*ux + uy*uy;
	double bk = 2*((xG - x_alpha)*ux + (yG - y_alpha)*uy);
	double ck = (xG-x_alpha)*(xG-x_alpha)+(yG-y_alpha)*(yG-y_alpha);
	ck -= r_alpha*r_alpha;

	double delta = bk*bk - 4*ak*ck;
	double k1, k2;
	coordPix n1;
	coordPix n2;

	k1 = (-bk - sqrt(delta))/(2*ak);
	n1.x = k1*ux + xG;
	n1.y = k1*uy + yG;


	k2 = (-bk + sqrt(delta))/(2*ak);
	n2.x = k2*ux + xG;
	n2.y = k2*uy + yG;

	if(alpha<0.8){
		if(distance(n1, c2)>distance(n2, c2)){
			return n1;
		}
		else{
			return n2;
		}
	}
	else{
		if(distance(n1, c1)<distance(n2, c1)){
			return n1;
		}
		else{
			return n2;
		}
	}

}

