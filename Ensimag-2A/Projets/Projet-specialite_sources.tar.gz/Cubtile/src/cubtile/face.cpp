#include "face.H"
#include "transformation.H"
#include <iostream>



Face::Face():
	affichage(NONE),
	temps_affichage(1),
	image(1, 1, CV_8UC1), // forcer le type de la matrice
	imageRedressee(1, 1, CV_8UC1),
	imageDroite(imageRecadree.cols,imageRecadree.cols,CV_8UC1)
{
}

void Face::configurer(){
	affichage = NONE;
	temps_affichage = 1;
	track.configurer();
}

void Face::configurerAffichage(AFFICHAGE_FACE aff, unsigned int temps_aff){
	affichage = aff;
	temps_affichage = temps_aff;
	extract.configurerAffichage(aff, temps_aff);
	track.configurerAffichage(aff, temps_aff);
}

void Face::initNextFrame(Matrx nextFrame){
	nextFrame.copyTo(imageRedressee);
}


void Face::extraction(CHOIX_ALGO algo){
	extract.extrairePoints(detection, imageRedressee, algo);
}

void Face::extractionMesure(CHOIX_ALGO algo, int r){
	extract.extrairePoints(detection, imageRedressee, algo,r);
}

void Face::tracker(bool echelle){
	if(affichage == TRACK){

		for( unsigned int i=0 ; i<detection.size() ; ++i ){
			circle(imageRedressee, detection[i], 3, cv::Scalar_<int>(100, 100) );
			circle(imageRedressee, detection[i], 4, cv::Scalar_<int>(150, 150) );
		}
		imageRedressee.afficher(temps_affichage); 
	}

	if(!echelle){  
		track.mettreAJour(detection, clock(), idf,1);
	}
	else{
		track.mettreAJour(detection, 
		                  clock(), 
		                  idf, 
		                  1/fmax(imageRedressee.rows,imageRedressee.cols));
	}

}

void Face::signaler(){
	track.signaler();
}

void Face::addEventMotion(Event E){
	track.addEventMotion(E);
}
void Face::addEventAppear(Event E){
	track.addEventAppear(E);
}
void Face::addEventDisappear(Event E){
	track.addEventDisappear(E);
}


void FaceH::redresser(){
	warpAffine(image,
			imageRedressee,
			getRotationMatrix2D(cv::Point2d(image.cols/2., image.rows/2.), 180, 1),
			cv::Size(image.cols, image.rows));
}

void FaceC::configurer() {
	Face::configurer();
	extract.configurer(imageRedressee,true);
}

void Face::setMap(int nbDiscretisation, int pasNbPix) {
	tailleMap = nbDiscretisation;
	h = pasNbPix;
	imageTransformee = Matrx(h*(tailleMap-1)+1,h*(tailleMap-1)+1,CV_8UC1);
	std::cout << "SETMAP : "<<imageTransformee.cols<< " x "<< imageTransformee.rows<<std::endl;
	Map = new coordPix*[tailleMap];
	for (int i = 0; i < tailleMap; i++) {
		Map[i] = new coordPix[tailleMap];
	}
}

void Face::setCoord(double xA, double yA,
		double xB, double yB,
		double xC, double yC,
		double xD, double yD,
		double xE, double yE,
		double xF, double yF) {

	/* Coordonnées des points de contrôles (plus tard par calibrage) */
	A.x = xA;
	A.y = yA;
	B.x = xB;
	B.y = yB;
	C.x = xC;
	C.y = yC;
	D.x = xD;
	D.y = yD;
	E.x = xE;
	E.y = yE;
	F.x = xF;
	F.y = yF;

}

void FaceB::configurer() {
	Face::configurer();
	extract.configurer(imageRedressee,false);
}

void FaceH::configurer() {
	Face::configurer();
	extract.configurer(imageRedressee,false);
}

void FaceD::configurer() {
	Face::configurer();
	extract.configurer(imageRedressee,false);
}

void FaceG::configurer() {
	Face::configurer();
	extract.configurer(imageRedressee,false);
}

void FaceB::redresser()
{
	image.copyTo(imageRedressee);
}

void FaceG::redresser()
{
	warpAffine(image,
			imageRedressee,
			getRotationMatrix2D(cv::Point2d(image.cols/2., image.cols/2.), 90, 1),
			cv::Size(image.rows, image.cols));
}

void FaceD::redresser()
{
	warpAffine(image,
			imageRedressee,
			getRotationMatrix2D(cv::Point2d(image.rows/2., image.rows/2.), -90, 1),
			cv::Size(image.rows, image.cols));
}


void FaceC::redresser(){
	image.copyTo(imageRedressee);
} 


/* Pour la face du milieu la transformation est inutile, on se contente
 * de recopier l'image redressée dans l'attribut imageTransformee */
void FaceC::transforme(){
	imageRedressee.copyTo(imageTransformee);	
	if(affichage == TRANSF){
		imageTransformee.afficher(temps_affichage);
	}
}

/*
void Face::mapping(coordPix A, coordPix B, coordPix C,
		coordPix D, coordPix E, coordPix F) {

	coordPix c1 = cercleTroisPts(A,B,E);
	coordPix c2 = cercleTroisPts(C,D,F);
	double r1 = sqrt((c1.x-A.x)*(c1.x-A.x)+(c1.y-A.y)*(c1.y-A.y));
	double r2 = sqrt((c2.x-C.x)*(c2.x-C.x)+(c2.y-C.y)*(c2.y-C.y));

	coordPix dAD = droiteDeuxPts(A,D);
	coordPix dBC = droiteDeuxPts(B,C);
	double a = dAD.x; // coefficient directeur de la droite (AD)
	double c = dBC.x; // coefficient directeur de la droite (BC)

	double ouverture = atan((c-a)/(a*c+1)); // angle entre les 2 droites

	coordPix G = interDeuxDroites(dAD,dBC); // intersec entre les 2 droites

	for (int i = 0; i < tailleMap; i++) {
		for (int j = 0; j < tailleMap; j++) {
			Map[i][j] = calculNoeud(i/(double)(tailleMap-1),
					(ouverture*j)/(tailleMap-1),
					a,G,c1,c2,r1,r2);
		}
	}									
}

void Face::transforme() {

	int x1,x2,y1,y2; 
	double d1,d2,d3,d4; // distances de (i,j) aux pixels (x1,y1) etc
	double div;
	unsigned nvGris1, nvGris2, nvGris3, nvGris4;*/

	/* En considérant que le premier noeud de la grille est à (0,0)
	 * et que le pas entre deux noeuds successifs est constant = h */

/*
	double eps = 1e-10;		

	for (int i = 0; i < imageTransformee.rows-1; i++) {
		for (int j = 0; j < imageTransformee.rows-1; j++) {

			x1 = floor(i/h);
			x2 = ceil(i/h+eps); 
			y1 = floor(j/h);
			y2 = ceil(j/h+eps);

			d1 = (i-x1*h)*(j-y1*h);
			d2 = (i-x1*h)*(y2*h-j);
			d3 = (x2*h-i)*(y2*h-j);
			d4 = (x2*h-i)*(j-y1*h);

			nvGris1 = imageRedressee.getSubPx<unsigned char>(Map[x1][y1].x,
					Map[x1][y1].y);
			nvGris2 = imageRedressee.getSubPx<unsigned char>(Map[x1][y2].x,
					Map[x1][y2].y);
			nvGris3 = imageRedressee.getSubPx<unsigned char>(Map[x2][y2].x,
					Map[x2][y2].y);
			nvGris4 = imageRedressee.getSubPx<unsigned char>(Map[x2][y1].x,
					Map[x2][y1].y);

			div = 1.0/(h*h*(x2-x1)*(y2-y1));

			imageTransformee.getPx<unsigned char>(i,j) = 
				(nvGris1*d3 + nvGris2*d4 + nvGris3*d1 + nvGris4*d2)*div;
		}
	}


	if(affichage == TRANSF){
		imageTransformee.afficher(temps_affichage);
	}
}
*/


void Face::supprPersp(int xe, int ye, int xf, int yf) {

	int L = imageDroite.cols;

	/* Les paramètres de l'homologie de centre S */
	double xs = (L-yf)*L*xe/((double) L*(xe-ye-xf+L)+ye*xf-yf*xe);
	double h = (L*(yf+xs-xf)-yf*xs)/((double) L-xf);
	double l = ((L-xs)*yf)/((double) L*(xf-xs));

	/* On parcourt l'image carrée pour remplir ses pixels,
	 * On envoie chacun d'eux dans le trapèze via la transfo projective
	 * On attribue le niveau de gris se trouvant à cet endroit */
	for (int i = 0; i < imageDroite.rows; i++) {
		for (int j = 0; j < imageDroite.cols; j++) {
			imageDroite.getPx<unsigned char>(i,j) =
				imageRecadree.getSubPx<unsigned char>
				(L-((h*l*(L-i))/((l-1)*(L-i)+h)),
				 (h/((l-1)*(L-i)+h))*(j-xs)+xs);
		}
	}

}


FaceH::FaceH(): Face()
{
	idf = FACEH;
}

FaceC::FaceC(): Face()
{
	idf = FACEM;
}

FaceB::FaceB(): Face()
{
	idf = FACEB;
}

FaceG::FaceG(): Face()
{
	idf = FACEG;
}

FaceD::FaceD(): Face()
{
	idf = FACED;
}

Matrx& Face::getImage(){
	return image;
}


