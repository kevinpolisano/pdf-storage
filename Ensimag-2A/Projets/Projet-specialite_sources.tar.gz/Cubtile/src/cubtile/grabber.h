#ifndef __GRABBER3
#define __GRABBER3




/**
 * @brief Retourne 1 si une camera gérable par libdc1394 est disponible
 */
int existeCamera();


/**
 * @brief Initialise une camera
 */
int initCamera();

/**
 * @brief positionne la camera en mode "7"
 */
int setupCameraFormat7();


/**
 * @brief Effectue diverses configurations de la camera (iso, dimensions) en choisissant la qualitée la plus élevée
 */
int confFormat7();

/**
 * @brief Permet de configurer le "shutter", voir featuresReport pour connaitre les valeurs possibles
 */
int shutterFormat7(int shut);

/**
 * @brief Affiche des informations sur la caméra
 */
int reportCameraFeatures();

/**
 * @brief Demande à la camera de commencer à transmettre des données
 */
int startCamera();

/**
 * @brief Terminer proprement la caméra.
 */
void terminerCamera();

/**
 * @brief Arrete la transmission des données
 */
void stopperCamera();

/**
 * @brief Hauteur de l'image
 */ 
int getHauteurGrab();


/*
 * Largeur de l'image
 */ 
int getLargeurGrab();


/**
 * @brief : Rend une frame à la camera
 */
int enFrameGrab(unsigned char ** laframe);

/**
 * @brief : retourne dans frame l'image la plus rescente. Suppose qu'une frame a été récemment ajouté à la file.
 */
int deFrameGrab(unsigned char ** laframe);

#endif
