#include <iostream>

#include "sourceVideo.H"




SourceVideo2::SourceVideo2(int argc, char* argv[]){
	// Hack pour connaitre les dimensions de la video
	// Crado
	Matrx frame_init;

	if(argc>=2){
		type=SRC_FILE;
		cap = cv::VideoCapture(argv[1]); 
		if(!cap.isOpened()){  
			std::cout << "Erreur : ouverture impossible de la video" << std::endl;
			exit(1);
		}
		this->dequeueFrame(&frame_init);
		nbColonnes = frame_init.cols;
		nbLignes = frame_init.rows;
		std::cout<<"Ouveture du fichier ok"<<std::endl;
	}
	else{
		if(existeCamera()){
			type=SRC_DC;
			

			initCamera();


			setupCameraFormat7();


			confFormat7();

			
			nbColonnes = getLargeurGrab();
			nbLignes = getHauteurGrab() ;
			
		}
		else{
			type= SRC_CAM;
			cap = cv::VideoCapture(0);
			if(!cap.isOpened()){  // check if we succeeded
				std::cout << "Erreur : initialisation webcam" << std::endl;
				exit(-1);
			}
			this->dequeueFrame(&frame_init);
			nbColonnes = frame_init.cols;
			nbLignes = frame_init.rows;
		}
	}
}



int SourceVideo2::configurerShutter(double moyenneAAtteindre){
	if(type == SRC_DC){
		cv::Mat frame(getHauteurGrab(), getLargeurGrab(), CV_8UC1);

		startCamera();

		double moyenne = 0;
		int i;
		for(i=100; i<1000 && moyenne<42; i+=10){
			stopperCamera();
		
			shutterFormat7(i);

			startCamera();

			deFrameGrab(&(frame.data));
			moyenne = mean(frame)[0];
			enFrameGrab(&(frame.data));
		}

		while(moyenne>43){
			--i;
			stopperCamera();
		
			shutterFormat7(i);

			startCamera();

			deFrameGrab(&(frame.data));
			moyenne = mean(frame)[0];
			enFrameGrab(&(frame.data));
		}

		stopperCamera();

		std::cout<<"Shutter à : "<<i<<std::endl;
	}

	return 0;
}


/**
 * @brief pour dire à la camera de commener l'envoi des données
 */
void SourceVideo2::demarrer(){
	if(type== SRC_DC){
		startCamera();
	}

}

/**
 * @brief pour dire à la camera de commener l'envoi des données
 */
void SourceVideo2::arreter(){
	if(type== SRC_DC){
		stopperCamera();
	}
}



/**
 * @brief prend une frame
 *
 */
int SourceVideo2::dequeueFrame(Matrx * frame){
		switch(type)
		{
		case SRC_FILE:
			if(!cap.grab()){
				return 0;
			}
			cap.retrieve(*frame);
			if(frame->channels() != 1){
				cvtColor(*frame, *frame, CV_RGB2GRAY); // Bricolage : A virer !!!!!
			}
			return 1;
			break;

		case SRC_CAM:
			cap >> *frame;
			if(frame->channels() != 1){
				cvtColor(*frame, *frame, CV_RGB2GRAY); // Bricolage : A virer !!!!!
			}
			return 1;
			break;
			
		case SRC_DC:
			deFrameGrab(&(frame->data));
			return 1;
			break;

		default:
			return 0;
			break;
		}
}

/**
 * @brief rend une frame
 *
 * La frame rendue est celle contenue dans frame.data
 */
void SourceVideo2::enqueueFrame(Matrx * frame){
	if(type == SRC_DC){
		enFrameGrab(&(frame->data));
	}
}


void SourceVideo2::reportFeatures(){
		switch(type)
		{
		case SRC_FILE:
			std::cout<<"Fichier Video : "<<nbLignes<<" x "<<nbColonnes<<std::endl;
			break;

		case SRC_CAM:
			std::cout<<"Webcam : "<<nbLignes<<" x "<<nbColonnes<<std::endl;
			break;
		case SRC_DC:
			reportCameraFeatures();
			break;

		default:
			break;
		}
}

/**
 * @brief Donne le nombre de ligne de l'image
 */
int SourceVideo2::getHauteur(){
	return nbLignes;

}

/**
 * @brief Donne le nombre de colonnes de l'image
 */
int SourceVideo2::getLargeur(){
	return nbColonnes;
}

/**
 * @brief Destructeur : stop l'utilisation de la caméra
 */ 
SourceVideo2::~SourceVideo2(){
	switch(type)
		{
		case SRC_FILE:
			
			break;
		case SRC_CAM:
			
			break;
			
		case SRC_DC:
			terminerCamera();
			break;

		default:
			break;
		}
}
