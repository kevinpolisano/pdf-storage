

// in order to get function prototypes from glext.h, define GL_GLEXT_PROTOTYPES before including glext.h
#define GL_GLEXT_PROTOTYPES


#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/freeglut.h>
#endif


#ifdef __APPLE__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#else
#include <GL/gl.h>
#endif



#include "util.H"
#include "transformation.H"
#include "sourceVideo.H"


#include "glTransfo.H"


#include <cv.h>
#include <highgui.h>


//GLUT CALLBACK functions
void displayCB();
glTransfo* glT;




// Hack pas top... Necessaire pour les callbacks de GLUT
glTransfo::glTransfo():
	SCREEN_WIDTH( 2*206),
	SCREEN_HEIGHT(2*206),
	CHANNEL_COUNT(1),
	DATA_SIZE(SCREEN_WIDTH * SCREEN_HEIGHT * CHANNEL_COUNT),
	PIXEL_FORMAT(GL_LUMINANCE),
	im_transfo(SCREEN_HEIGHT, SCREEN_WIDTH, CV_8UC1),
	discretisation(60),
	//4 faces, deux coordonnées, et GL quads (donc 4)...
	nbr_element_tex((discretisation-1)*(discretisation-1)*4*2*4),
	nbr_element_pos((discretisation-1)*(discretisation-1)*4*3*4)

	//Meme chose mais pour deux triangles donc 6
	//nbr_element_tex((discretisation-1)*(discretisation-1)*4*2*6),
	//nbr_element_pos((discretisation-1)*(discretisation-1)*4*3*6)

{
	glT = this;

}


// Upload les coordonnées dans la mémoire de la carte graphique
void glTransfo::initVBO(){

	// creation des deux tableaux de coordonnées
	coordTex = new GLfloat[nbr_element_tex]; 
	coordPos = new GLfloat[nbr_element_pos]; 

	// generation des vbo
	glGenBuffersARB(1, &vboIdTex);
	glGenBuffersARB(1, &vboIdPos);

	// On rempli nos deux tableaux
	preRemplirVBO();

	// bind et upload pour utilisation...
	glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboIdTex);
	glBufferDataARB(GL_ARRAY_BUFFER_ARB, sizeof(GLfloat)*nbr_element_tex, coordTex, GL_STATIC_DRAW_ARB);

	glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboIdPos);
	glBufferDataARB(GL_ARRAY_BUFFER_ARB, sizeof(GLfloat)*nbr_element_pos, coordPos, GL_STATIC_DRAW_ARB);

}

void glTransfo::preRemplirVBO(){
	GLfloat* ptrTex = coordTex;
	GLfloat* ptrPos = coordPos;
	
	// Attention, frame initialisée ???
	frame = Matrx(*video);
	double divl = 1/((double)frame.cols); 
	double divh = 1/((double)frame.rows);

	bas.remplir(divl, divh, -0.5, 0.5, ptrTex, ptrPos); //en bas à droite
	gauche.remplir(divl, divh, -0.5, -0.5, ptrTex, ptrPos);
	haut.remplir(divl, divh, 0.5, -0.5, ptrTex, ptrPos);
	droite.remplir(divl, divh, 0.5, 0.5, ptrTex, ptrPos);
}

void glTransfo::init(int argc, char * argv[], SourceVideo2 * vid){
	video = vid;
	// Attention, l'ordre est important
	initGLUT(argc, argv);
	initGL();
	initMap(discretisation);
	// On rempli la VBO avec les 4 maps créées
	initVBO();
}



void glTransfo::drawVBO(){

	// On donne la nouvelle frame à opengl
	glTexImage2D (
	              GL_TEXTURE_2D, 	//Type : texture 2D
	              0, 	//Mipmap : aucun
	              1, 	//Couleurs : 1 seule (niveau de gris)
	              frame.cols, 	//Largeur : 
	              frame.rows, 	//Hauteur : 
	              0, 	//Largeur du bord : 0
	              PIXEL_FORMAT, 	//Format : RGBA
	              GL_UNSIGNED_BYTE, 	//Type des couleurs
	              frame.data	//Addresse de l'image
	              ); 

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

 
	//Efface le framebuffer et le depthbuffer
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ); 	
	glMatrixMode(GL_MODELVIEW); 	
	glLoadIdentity();

	// On positionne opengl sur les 2 VBO
	glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboIdPos);
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, 0);

    glBindBufferARB(GL_ARRAY_BUFFER_ARB, vboIdTex);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(2, GL_FLOAT, 0, 0); 
    
    // Rendu de la texture
    glEnable(GL_TEXTURE_2D); // Redondance ici ??
    glDrawArrays(GL_QUADS, 0, (discretisation-1)*(discretisation-1)* 4 * 4);
    glDisable(GL_TEXTURE_2D);

    // On oubli pas de remettre tout comme c'était avant...
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);


	glFlush();
    // On marque la frame comme displayable, ainsi, réaffiche l'image avant la fin du tour de boucle
	glutPostRedisplay();
}

// Coordonnées en dur
void glTransfo::initMap(int precision){

	// Mettre 30 a la place de 2 !!!
	bas.setMap(precision);
	bas.setCoord(407,168, //A 
	             414,460, //B
	             316,374, //C
	             316,257, //D
	             470,310, //E
	             321,319, 
	             video,
	             FACEB); //F

	// Mettre 30 a la place de 2 !!!
	gauche.setMap(precision);
	gauche.setCoord(99, 157, //A 
	                400,152, //B
	                312,248, //C
	                188,256, //D
	                247,95 , //E
	                247,247, 
	                video,
	                FACEG); //F

	haut.setMap(precision);
	haut.setCoord(89, 473, //A 
	              81,173, //B
	              181,259, //C
	              183,379, //D
	              27,314 , //E
	              178,315, 
	              video,
	              FACEH); //F

	droite.setMap(precision);
	droite.setCoord(404, 477, //A 
	                102,487, //B
	                191,383, //C
	                313,382, //D
	                255,541 , //E
	                251,387, 
	                video,
	                FACED); //F

}





// On utilise GLUT, et on est donc obligé d'avoir une fenetre...
int glTransfo::initGLUT(int argc, char **argv)
{

	glutInit(&argc, argv);

	glutInitDisplayMode(GLUT_RGBA); // display mode
	glutInitWindowSize(SCREEN_WIDTH, SCREEN_HEIGHT);    // window size

	glutInitWindowPosition(100, 100);           // window location

	int handle = glutCreateWindow(argv[0]);     // param is the title of window

	// register GLUT callback functions
	glutDisplayFunc(displayCB);

	glClearColor(.5,.5,.5,0); 	//Change la couleur du fond
	glEnable(GL_DEPTH_TEST); 	//Active le depth test
	glEnable(GL_TEXTURE_2D); 	//Active le texturing
	glGenTextures(1,&Nom); 	//Génère un n° de texture
	glBindTexture(GL_TEXTURE_2D,Nom); 	//Sélectionne ce n°

	return handle;
}



void glTransfo::initGL()
{
	glShadeModel(GL_SMOOTH);                    // shading mathod: GL_SMOOTH or GL_FLAT

	// enable /disable features
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);
	glHint(GL_TEXTURE_COMPRESSION_HINT, GL_FASTEST);
	glHint(GL_FRAGMENT_SHADER_DERIVATIVE_HINT, GL_FASTEST);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);

	// track material ambient and diffuse from surface color, call it before glEnable(GL_COLOR_MATERIAL)

	glClearColor(0, 0, 0, 0);                   // background color
	glClearStencil(0);                          // clear stencil buffer
	glClearDepth(1.0f);                         // 0 is near, 1 is far
	glDepthFunc(GL_LEQUAL);

	initLights();

}



// Les lumières qui vont bien...
void glTransfo::initLights()
{
	// set up light colors (ambient, diffuse, specular)
	GLfloat lightKa[] = {.2f, .2f, .2f, 1.0f};  // ambient light
	GLfloat lightKd[] = {.7f, .7f, .7f, 1.0f};  // diffuse light
	GLfloat lightKs[] = {1, 1, 1, 1};           // specular light
	glLightfv(GL_LIGHT0, GL_AMBIENT, lightKa);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightKd);
	glLightfv(GL_LIGHT0, GL_SPECULAR, lightKs);

	// position the light
	float lightPos[4] = {0, 0, 20, 1}; // positional light
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

	glEnable(GL_LIGHT0);                        // MUST enable each light source after configuration
}



void glTransfo::displayCBO()
{

	drawVBO();

	// hack pour faire du nioveau de gris avec opengl
	glPixelTransferf(GL_RED_SCALE, 0.299f);
	glPixelTransferf(GL_GREEN_SCALE, 0.587f);
	glPixelTransferf(GL_BLUE_SCALE, 0.114f);

	// On selectionnel le buffer dont on veut récuperer les pixels
	glReadBuffer(GL_FRONT);

	//On récupère en RAM les pixels
	glReadPixels(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, PIXEL_FORMAT, GL_UNSIGNED_BYTE, im_transfo.data);

	// On oubli pas de tout remettre dans l'état initial
	glPixelTransferf(GL_RED_SCALE, 1.0f);
	glPixelTransferf(GL_GREEN_SCALE, 1.0f);
	glPixelTransferf(GL_BLUE_SCALE, 1.0f);

	glDrawBuffer(GL_BACK);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

	// On transforme la texture



}

// pas top du tout... Mais ça marche !
void glTransfo::getNext(Matrx & frm, Matrx & image){
	frame = frm;

	// Deux API différentes selon si on est sous linux ou mac
#ifdef __APPLE__
	glutCheckLoop();
#else
	glutMainLoopEvent(); 
#endif
	image = im_transfo;
}

glTransfo::~glTransfo(){
	delete[] coordTex;
	delete[] coordPos;
	glDeleteBuffersARB(1,  & vboIdTex);
	glDeleteBuffersARB(1, &vboIdPos);
}






// Necessaire pour les callback de glut
// Bof...
void displayCB(){
	glT->displayCBO();

}
