#include <iostream>
#include "matx.H"
#include <cmath>

#define PI 3.14159265

Matrx::Matrx()
{}

Matrx::Matrx(int _rows, int _cols, int _type): 
	cv::Mat(_rows, _cols,  _type)
{}

Matrx::Matrx(SourceVideo2 & source):
	Mat(source.getHauteur(), source.getLargeur(), CV_8UC1)
{
	std::cout<<"La matrice : "<<this->rows<<" x "<<this->cols<<std::endl;
}

Matrx::Matrx(const Matrx& m):
	Mat(m),
	temps(m.temps)
{}


Matrx::Matrx(int _rows, int _cols, int _type, void* _data, size_t _step):
	Mat(_rows,  _cols,  _type,  _data, _step)
{}
   

Matrx::Matrx(const Matrx& m, const cv::Range& rowRange, const cv::Range& colRange):
	Mat( m, rowRange, colRange),
	temps(m.temps)
{}

Matrx::Matrx(const Matrx& m, const cv::Rect& roi):
	Mat(m, roi),
	temps(m.temps)
{}

Matrx::Matrx(const cv::Mat & m): 
	Mat(m)
{
}

Matrx Matrx::operator=(cv::Mat const& mat)	
{
	*this = Matrx(mat);
	return *this;
}

void Matrx::afficher(int temps_affichage){
	cv::imshow("image", *this);
	cv::waitKey(temps_affichage);
}



Matrx Matrx::getProjectedHistoX(){
	Matrx res(1,this->size().width,CV_8UC1);
	for (int j = 0; j < this->size().width ; ++j){
		res.at<unsigned char>(1,j) = 0;
	}

	for(int i = 0; i < this->size().width; ++i){
		for (int j = 0; j < this->size().height; ++j){
		res.at<unsigned char>(1,i) += (int)this->at<unsigned char>(j,i)/255;
		}
	}
	return res;
}

Matrx Matrx::getProjectedHistoY(){
	Matrx res(this->size().height,1,CV_8UC1);
	for (int j = 0; j < this->size().height; ++j){
		res.at<unsigned char>(j,1) = 0;
	}

	for(int j = 0; j < this->size().height; ++j){
		for (int i = 0; i < this->size().width; ++i){
			// l'image sur laquelle on travaille étant seuillée
			// il faut normaliser 
		res.at<unsigned char>(j,1) += (int)this->at<unsigned char>(j,i)/255;
		}
	}
	return res;
}




// à générer ensuite automatiquement
void Matrx::initGauss(cv::Size taille){	
	// on parcours la matrice pour la mettre à zéro
	for ( int i = -taille.width; i <= taille.width ; ++i){
		for (int j = -taille.height; j <= taille.height ; ++j){
			this->at<double>(taille.width+i,taille.height+j) = exp(-(double)(i*i+j*j)/2)/(2*PI);
		}
	}
}

void Matrx::histo(){
	cv::Mat hist;
	int bins = 256;
	int histSize[] = {bins};
	float rangeGray[] = {0, 256};
	const float* rangesGray[] = {rangeGray};
	int channels[] = {0};
	cv::calcHist(this,1,channels,Mat(),hist,1,histSize,rangesGray);
	// on affiche l'histo
	//ouverture d'un fichier
	std::ofstream fichier("histo.txt", std::ios::out | std::ios::trunc);
	if(fichier)
	{
		fichier << "x" << " y" << std::endl;
		for ( int i = 0; i < 256; ++i ){
			fichier << i << " " << hist.at<float>(i) << std::endl;
		}
		fichier.close();
	} else {
		std::cout << "impossible d'ouvrir le fichier" << std::endl;
	}
}

void Matrx::printInFile(){
	std::ofstream fichier("doigt.txt", std::ios::out | std::ios::trunc);
	if(fichier)
	{
		fichier << "x" << " y" << " z" << std::endl;
		for ( int i = 0 ; i < this->size().width ; ++i ){
			for ( int j = 0; j < this->size().height ; ++j){
				fichier << i << " " << j << " " << (int)this->at<unsigned char>(i,j) << std::endl;
			}
		}
		fichier.close();
	} else {
		std::cout << "impossible d'ouvrir le fichier" << std::endl;
	}
}




void seuilLineaire(Matrx & src, Matrx & dest, int sb, int sh){
	// initialisation de la matrice
	// Matrx res(this->rows,this->cols,CV_8UC1);

	// pointeur 
	if(dest.rows != src.rows || dest.cols != src.cols){
		dest = Matrx(src.rows, src.cols, CV_8UC1);
	}

	// uchar* ptrSrc = src.data;
	// uchar* ptrRes = dest.data;

	// int seuilCourant;


	// for ( int i = 0; i < src.rows; ++i){
	// 	seuilCourant = sb + i * (sh-sb)/src.rows; // conversion à faire ??
	// 	for ( int j = 0; j < src.cols;++j){
	// 		*ptrRes = ( *ptrSrc > seuilCourant ) ? 255 : 0 ;	
	// 		++ptrSrc;
	// 		++ptrRes;
	// 	}
	// }


	for(int i=0; i<src.rows; i++){
		Matrx srctemp = src(cv::Rect(0, i, src.cols, 1));
		Matrx desttemp = dest(cv::Rect(0, i,src.cols, 1));
		threshold(srctemp, desttemp, sb + i * (sh-sb)/src.rows , 255, cv::THRESH_BINARY);
	}

	//	return res;
}


