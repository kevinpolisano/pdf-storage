#include <iostream>

#include "util.H"
#include "examples_event.H"

static int appear = 0;
static int disappear = 0;
static int motion = 0;

void eApp(InfoEvent I){
 	std::cout<<"\nAppear-----------------"<<std::endl;
 	I.afficher();
	appear++;
	
}

void eDisapp(InfoEvent I){
 	std::cout<<"\nDisappear--------------"<<std::endl;
 	I.afficher();
	disappear++;
}

void eMot(InfoEvent I){
 	std::cout<<"\nMotion-----------------"<<std::endl;
 	I.afficher();
	motion++;
}

int getNbApp(){
	return appear;
}
int getNbDisapp(){
	return disappear;
}
int getNbMot(){
	return motion;
}
