#include "transfo.H"



void Transfo::setMap(int nbDiscretisation) {
	tailleMap = nbDiscretisation;
	Map = new coordPix*[tailleMap];
	for (int i = 0; i < tailleMap; i++) {
		Map[i] = new coordPix[tailleMap];
	}
	ListeCentres = new coordPix[tailleMap];
	ListeRayons = new double[tailleMap];
}

void Transfo::setCoord(double xA, double yA,
                       double xB, double yB,
                       double xC, double yC,
                       double xD, double yD,
                       double xE, double yE,
                       double xF, double yF,
                       SourceVideo2* video,
                       ID_FACE idf) {
	id = idf;
	/* Coordonnées des points de contrôles (plus tard par calibrage) */
	A.x = xA*video->getHauteur()/480.;
	A.y = yA*video->getLargeur()/640.;
	B.x = xB*video->getHauteur()/480.;
	B.y = yB*video->getLargeur()/640.;
	C.x = xC*video->getHauteur()/480.;
	C.y = yC*video->getLargeur()/640.;
	D.x = xD*video->getHauteur()/480.;
	D.y = yD*video->getLargeur()/640.;
	E.x = xE*video->getHauteur()/480.;
	E.y = yE*video->getLargeur()/640.;
	F.x = xF*video->getHauteur()/480.;
	F.y = yF*video->getLargeur()/640.;

	GenListeCentreRayon();
	mapping();
}

void Transfo::GenListeCentreRayon() {
	coordPix * RepFE = new coordPix[tailleMap];
	GenRepartition(F,E,RepFE,tailleMap);

	coordPix * RepCB = new coordPix[tailleMap];
	GenRepartition(C,B,RepCB,tailleMap);

	coordPix * RepDA = new coordPix[tailleMap];
	GenRepartition(D,A,RepDA,tailleMap);

	for (int i = 0; i < tailleMap; i++) {
		ListeCentres[tailleMap-i-1] = cercleTroisPts(RepDA[i],RepFE[i],RepCB[i]);;
		ListeRayons[tailleMap-i-1] = distance(ListeCentres[tailleMap-i-1],RepDA[i]);
	}
}

void Transfo::mapping() {


	coordPix c1 = cercleTroisPts(A,B,E);
	coordPix c2 = cercleTroisPts(C,D,F);
	double r1 = sqrt((c1.x-A.x)*(c1.x-A.x)+(c1.y-A.y)*(c1.y-A.y));
	double r2 = sqrt((c2.x-C.x)*(c2.x-C.x)+(c2.y-C.y)*(c2.y-C.y));

	coordPix dAD = droiteDeuxPts(A,D);
	coordPix dBC = droiteDeuxPts(B,C);
	double a = dAD.x; // coefficient directeur de la droite (AD)
	double c = dBC.x; // coefficient directeur de la droite (BC)

	double ouverture = atan((c-a)/(a*c+1)); // angle entre les 2 droites

	coordPix G = interDeuxDroites(dAD,dBC); // intersec entre les 2 droites

	std::cout<<"Grand cercle : "<<c1.x<<" "<<c1.y<<"  "<<r1<<std::endl;
	std::cout<<"Petit cercle : "<<c2.x<<" "<<c2.y<<"  "<<r2<<std::endl;


	std::cout<<"A : "<<a<<std::endl;
	std::cout<<"C : "<<c<<std::endl;
	std::cout<<"ouverture : "<<ouverture<<std::endl;
	std::cout<<"G : "<<G.x<<"  "<<G.y<<std::endl;
		

	std::cout<<"Mapping"<<tailleMap<<std::endl;
	for (int i = 0; i < tailleMap; i++) {
		for (int j = 0; j < tailleMap; j++) {
			Map[i][j] = calculNoeud(i/(double)(tailleMap-1),
			                        (ouverture*j)/(tailleMap-1),
			                        a,G,c1,c2,r1,r2,tailleMap,
									ListeCentres,ListeRayons);
			//std::cout<<"Map :: Map[i][j]"<< Map[i][j].x<<"  "<<Map[i][j].y<<std::endl;
		}
	}									
}


void Transfo::draw(double divl, double divh, double decx, double decy){
	double h = 1/(double)(tailleMap-1);

	for (int i = 0; i < tailleMap-1; i++) {
		for (int j = 0; j < tailleMap-1; j++) {

			int k = tailleMap-i-2;

			//circle(frame, cv::Point2i(Map[i][j].y, Map[i][j].x) , 3, cv::Scalar_<int>(100, 100) );

			glTexCoord2d(Map[i][j+1].y*divl, Map[i][j+1].x*divh);
			glVertex3d((2*(j+1)*h-1)/2.+decx, //1
			           (-1+2*(k+1)*h)/2. +decy, //1
			           -0);



			glTexCoord2d(Map[i][j].y*divl, Map[i][j].x*divh);
			glVertex3d((2*j*h-1)/2.+decx, //-1
			           (-1+2*(k+1)*h)/2.+decy, //1
			           -0);



			glTexCoord2d(Map[i+1][j].y*divl, Map[i+1][j].x*divh);
			glVertex3d((2*j*h-1)/2.+decx, //-1
			           (-1+2*k*h)/2.+decy, //-1
			           -0);



			glTexCoord2d(Map[i+1][j+1].y*divl, Map[i+1][j+1].x*divh);
			glVertex3d((2*(j+1)*h-1)/2.+decx, //1
			           (-1+2*k*h)/2.+decy, // -1
			           -0);

		}
	}



}


void Transfo::remplir(double divl, double divh, double decx, double decy, GLfloat*& ptrTex, GLfloat*& ptrPos){
	double h = 1/(double)(tailleMap-1);

	for (int i = 0; i < tailleMap-1; i++) {
		for (int j = 0; j < tailleMap-1; j++) {

			int k = tailleMap-i-2;



			*ptrTex = Map[i][j+1].y*divl;
			++ptrTex;
			*ptrTex = Map[i][j+1].x*divh;
			++ptrTex;

			*ptrPos=(2*(j+1)*h-1)/2.+decx;
			++ptrPos;
			*ptrPos=(-1+2*(k+1)*h)/2. +decy;
			++ptrPos;
			*ptrPos=0;
			++ptrPos;
			

			*ptrTex = Map[i][j].y*divl;
			++ptrTex;
			*ptrTex = Map[i][j].x*divh;
			++ptrTex;

			*ptrPos=(2*j*h-1)/2.+decx;
			++ptrPos;
			*ptrPos=(-1+2*(k+1)*h)/2.+decy;
			++ptrPos;
			*ptrPos=0;
			++ptrPos;


			*ptrTex = Map[i+1][j].y*divl;
			++ptrTex;
			*ptrTex = Map[i+1][j].x*divh;
			++ptrTex;

			*ptrPos=(2*j*h-1)/2.+decx;
			++ptrPos;
			*ptrPos=(-1+2*k*h)/2.+decy;
			++ptrPos;
			*ptrPos=0;
			++ptrPos;


			*ptrTex = Map[i+1][j+1].y*divl;
			++ptrTex;
			*ptrTex = Map[i+1][j+1].x*divh;
			++ptrTex;

			*ptrPos=(2*(j+1)*h-1)/2.+decx;
			++ptrPos;
			*ptrPos=(-1+2*k*h)/2.+decy;
			++ptrPos;
			*ptrPos=0;
			++ptrPos;

		}
	}
}


void Transfo::remplirTriangles(double divl, double divh, double decx, double decy, GLfloat*& ptrTex, GLfloat*& ptrPos){
	double h = 1/(double)(tailleMap-1);

	for (int i = 0; i < tailleMap-1; i++) {
		for (int j = 0; j < tailleMap-1; j++) {

			int k = tailleMap-i-2;

			//1
			*ptrTex = Map[i][j+1].y*divl;
			++ptrTex;
			*ptrTex = Map[i][j+1].x*divh;
			++ptrTex;

			*ptrPos=(2*(j+1)*h-1)/2.+decx;
			++ptrPos;
			*ptrPos=(-1+2*(k+1)*h)/2. +decy;
			++ptrPos;
			*ptrPos=0;
			++ptrPos;
			
			//2
			*ptrTex = Map[i][j].y*divl;
			++ptrTex;
			*ptrTex = Map[i][j].x*divh;
			++ptrTex;

			*ptrPos=(2*j*h-1)/2.+decx;
			++ptrPos;
			*ptrPos=(-1+2*(k+1)*h)/2.+decy;
			++ptrPos;
			*ptrPos=0;
			++ptrPos;

			//3
			*ptrTex = Map[i+1][j].y*divl;
			++ptrTex;
			*ptrTex = Map[i+1][j].x*divh;
			++ptrTex;

			*ptrPos=(2*j*h-1)/2.+decx;
			++ptrPos;
			*ptrPos=(-1+2*k*h)/2.+decy;
			++ptrPos;
			*ptrPos=0;
			++ptrPos;

			//3
			*ptrTex = Map[i+1][j].y*divl;
			++ptrTex;
			*ptrTex = Map[i+1][j].x*divh;
			++ptrTex;

			*ptrPos=(2*j*h-1)/2.+decx;
			++ptrPos;
			*ptrPos=(-1+2*k*h)/2.+decy;
			++ptrPos;
			*ptrPos=0;
			++ptrPos;


			//4
			*ptrTex = Map[i+1][j+1].y*divl;
			++ptrTex;
			*ptrTex = Map[i+1][j+1].x*divh;
			++ptrTex;

			*ptrPos=(2*(j+1)*h-1)/2.+decx;
			++ptrPos;
			*ptrPos=(-1+2*k*h)/2.+decy;
			++ptrPos;
			*ptrPos=0;
			++ptrPos;

			//1
			*ptrTex = Map[i][j+1].y*divl;
			++ptrTex;
			*ptrTex = Map[i][j+1].x*divh;
			++ptrTex;

			*ptrPos=(2*(j+1)*h-1)/2.+decx;
			++ptrPos;
			*ptrPos=(-1+2*(k+1)*h)/2. +decy;
			++ptrPos;
			*ptrPos=0;
			++ptrPos;

		}
	}

}

