#include<iostream>

#include "cubtile.H"




_ConfigGeo::_ConfigGeo(int x1, int x2, int x3, int x4, int x5, int x6,
                       int y1, int y2, int y3, int y4, int y5, int y6,
                       int _nl,
                       int _nc):
	nl(_nl),
	nc(_nc),
	rectH(x2, y1, x5-x2, y3-y1),
	rectB(x2, y4, x5-x2, y6-y4),
	rectG(x1, y2, x3-x1, y5-y2),
	rectD(x4, y2, x6-x4, y5-y2),
	rectM(262,191,376-262,304-191) 
{

}
	

Cubtile::Cubtile():
	video(1, NULL),
	frame(video),
	confGeo(
	        94, 168, 254, 382, 474, 547,
	        21, 96, 181, 315, 407, 480,
	        480,
	        640),
	echelle(true)

{	
	faces[0] = &fH;
	faces[1] = &fB;
	faces[2] = &fC;
	faces[3] = &fD;
	faces[4] = &fG;


}
/*
 * Données en dur...
 */
Cubtile::Cubtile(int argc, char * argv[], bool ech):
	video(argc, argv),
	frame(video),
	confGeo(
	        90, 156, 266, 370, 483, 547,
	        21, 91, 193, 305, 409, 480,
	        480,
	        640),
	echelle(ech)
{
	int nl = 480;
	int nc = 640;
	if (argc == 1){
		std::cout << "camera" << std::endl;
		nl = 494;
		nc = 640;
		double rx=494/480;
		double ry=656/640;
		ConfigGeo confGeoTmp = ConfigGeo(90*rx, 156*rx, 266*rx, 370*rx, 483*rx, 547*rx,
		                                 21*ry, 91*ry, 193*ry, 305*ry, 409*ry, 480*ry,
		                                 494,
		                                 656);
		confGeoTmp.rectM.x *= rx ;
		confGeoTmp.rectM.y *= rx;
		confGeoTmp.rectM.height *= ry;
		confGeoTmp.rectM.width *= ry; 
			
		confGeo = confGeoTmp;
	}	
	faces[FACEH] = &fH;
	faces[FACEB] = &fB;
	faces[FACEM] = &fC;
	faces[FACED] = &fD;
	faces[FACEG] = &fG;

	frame = Matrx(nl,nc,CV_8UC1,new unsigned char[nl*nc]);
	gltransfo.init(argc, argv, &video);
}



// Dans l'ordre : récuperer la face du milieu
//                Effectuer les transformations via opengl
//                Récuperer les 4 faces latérales
void Cubtile::transformation()
{	

	faces[FACEM]->initNextFrame(frame(confGeo.rectM));
	gltransfo.getNext(frame, frame_transfo);

	int nl = frame_transfo.rows;
	int nc = frame_transfo.cols;

	faces[FACEH]->initNextFrame(frame_transfo(cv::Rect(nc/2, 0, nc/2, nl/2)));
	faces[FACEB]->initNextFrame(frame_transfo(cv::Rect(0, nl/2, nc/2, nl/2)));

	faces[FACED]->initNextFrame(frame_transfo(cv::Rect(nc/2, nl/2, nc/2, nl/2)));
	faces[FACEG]->initNextFrame(frame_transfo(cv::Rect(0, 0, nc/2, nl/2)));

}

//
// Meme operation sur chacune des faces.
//
void Cubtile::extraction(CHOIX_ALGO algo){
	for(int i=0; i<5; i++){
		faces[i]->extraction(algo);
	}
}

void Cubtile::extractionMesure(CHOIX_ALGO algo, int r){
	for(int i=0; i<5; i++){
		faces[i]->extractionMesure(algo,r);
	}
}


void Cubtile::tracker()
{	
	for(int i=0; i<5; i++)
		faces[i]->tracker(echelle);
}

void Cubtile::trackerMesure()
{	
	for(int i=0; i<5; i++)
		faces[i]->tracker(!echelle);
}

void Cubtile::signaler()
{	
	for(int i=0; i<5; i++)
		faces[i]->signaler();
}



//
// Permet de configurer les différentes variables selon les conditions dans lesquelles se trouve le cubtile...
//
void Cubtile::calibrer()
{	
	std::cout<<"Configuration... Patientez sans toucher au Cubtile"<<std::endl;

	// 42 est la valeur moyenne de l'instensité des pixels sur l'ensemble des images à atteindre.
	video.configurerShutter(42);
	
	//Allouer la mémoire avec d'ajouter des données
	Matrx frame_tamp = Matrx(video.getHauteur(), video.getLargeur(), CV_8UC1);

	// On prend une image
	video.demarrer();

	video.dequeueFrame(&frame_tamp);
	frame_tamp.copyTo(frame);
	video.enqueueFrame(&frame_tamp);
	
	video.arreter();

	// TRANSFO GL ATTENTION, dimensions en dur !!!!!
	frame_transfo = Matrx(2*206, 2*206, CV_8UC1);
	int nl = frame_transfo.rows; 
	int nc = frame_transfo.cols;


	// Configurations de chacune des faces
	faces[FACEM]->initNextFrame(frame(confGeo.rectM));
	gltransfo.getNext(frame, frame_transfo);

	faces[FACEH]->initNextFrame(frame_transfo(cv::Rect(nc/2, 0, nc/2, nl/2)));
	faces[FACEB]->initNextFrame(frame_transfo(cv::Rect(0, nl/2, nc/2, nl/2)));
	faces[FACED]->initNextFrame(frame_transfo(cv::Rect(nc/2, nl/2, nc/2, nl/2)));
	faces[FACEG]->initNextFrame(frame_transfo(cv::Rect(0, 0, nc/2, nl/2)));
	
	//frame_transfo.afficher(0);
	std::cout << "configuration des faces" << std::endl;


	((FaceB*)faces[FACEB])->FaceB::configurer();
	((FaceH*)faces[FACEH])->FaceH::configurer();
	((FaceG*)faces[FACEG])->FaceG::configurer();
	((FaceD*)faces[FACED])->FaceD::configurer();
	((FaceC*)faces[FACEM])->FaceC::configurer();


	// Affichage des fonctionnalitées à l'écran...
	video.reportFeatures();

	std::cout<<"Fin de la configuration !"<<std::endl;

}




void Cubtile::mainLoop(volatile bool & arret, ID_FACE id, AFFICHAGE_FACE etape, CHOIX_ALGO algo)
{	

	// Variables permettant de prendre des mesures de temps
	clock_t debut, inter1, inter2, dequeue=0, transfo=0, extra=0, track=0, fin;
	float total;
	long int compteur = 0;
	float debut_tour;
	float fin_tour;
	float latence = 0;

	// Configure l'affichage d'une des faces
	faces[id]->configurerAffichage(etape);

	video.demarrer();

	debut = clock();

	inter1 = clock();


	// La boucle principale : transformation, extraction, identification et envoi des evenements
	while(!arret){
		compteur++;

		if(!video.dequeueFrame(&frame))
			break;
		debut_tour = (float)clock();

		inter2 = clock(); dequeue+=inter2-inter1; inter1 = inter2;
		
		transformation();
		inter2 = clock(); transfo+=inter2-inter1; inter1 = inter2;

		extraction(algo);
		inter2 = clock(); extra+=inter2-inter1; inter1 = inter2;

		tracker();
		signaler();
		inter2 = clock(); track+=inter2-inter1; inter1 = inter2;
		fin_tour = (float)clock();
		latence += fin_tour-debut_tour;
		
		video.enqueueFrame(&frame);
	}

	fin  = clock();

	video.arreter();

	total = ((float)(fin-debut))/CLOCKS_PER_SEC;

	//Affichage d'informations
	std::cout<<"Duree totale : "<<total<<std::endl<<std::endl;
	std::cout<<"FrameRate : "<<compteur/total<<" frames/sec"<<std::endl<<std::endl;

	std::cout<<"Temps dequeue : "<<(float)100*((float)dequeue)/(total*CLOCKS_PER_SEC)<<"%, "<<1000*((float)dequeue)/(compteur*CLOCKS_PER_SEC)<<" millisecondes en moyenne"<<std::endl;
	std::cout<<"Temps transformation : "<<(float)100*((float)transfo)/(total*CLOCKS_PER_SEC)<<"%, "<<1000*((float)transfo)/(compteur*CLOCKS_PER_SEC)<<" millisecondes en moyenne"<<std::endl;
	std::cout<<"Temps extraction : "<<(float)100*((float)extra)/(total*CLOCKS_PER_SEC)<<"%, "<<1000*((float)extra)/(compteur*CLOCKS_PER_SEC)<<" millisecondes en moyenne"<<std::endl;
	std::cout<<"Temps tracking : "<<(float)100*((float)track)/(total*CLOCKS_PER_SEC)<<"%, "<<1000*((float)track)/(compteur*CLOCKS_PER_SEC)<<" millisecondes en moyenne"<<std::endl<<std::endl;

	std::cout<<"Latence : "<<(1000*latence)/(compteur*CLOCKS_PER_SEC)<<" millisecondes"<<std::endl;


	
}


//
// Meme chose avec des mesures
//
void Cubtile::mainLoopMesure(volatile bool & arret, ID_FACE id, AFFICHAGE_FACE etape, CHOIX_ALGO algo, int r)
{	

	faces[id]->configurerAffichage(etape);

	video.demarrer();
	int nbIter = 1000;
	int compteur = 0;
	while(compteur < nbIter){
		if(!video.dequeueFrame(&frame))
			break;
		transformation();
		extractionMesure(algo,r);
		trackerMesure();
		signaler();
		video.enqueueFrame(&frame);
		compteur++;
	}

	video.arreter();
}



void Cubtile::addEventMotionAll(void (*ptr_fctMotion)(InfoEvent))
{	

	addEventMotion(FACEH, ptr_fctMotion);
	addEventMotion(FACEB, ptr_fctMotion);
	addEventMotion(FACEG, ptr_fctMotion);
	addEventMotion(FACED, ptr_fctMotion);
	addEventMotion(FACEM, ptr_fctMotion);

}
		
void Cubtile::addEventAppearAll(void (*ptr_fctAppear)(InfoEvent))
{	
	addEventAppear(FACEH, ptr_fctAppear);
	addEventAppear(FACEB, ptr_fctAppear);
	addEventAppear(FACEG, ptr_fctAppear);
	addEventAppear(FACED, ptr_fctAppear);
	addEventAppear(FACEM, ptr_fctAppear);
}

void Cubtile::addEventDisappearAll(void (*ptr_fctDisappear)(InfoEvent))
{	
	addEventDisappear(FACEH, ptr_fctDisappear);
	addEventDisappear(FACEB, ptr_fctDisappear);
	addEventDisappear(FACEG, ptr_fctDisappear);
	addEventDisappear(FACED, ptr_fctDisappear);
	addEventDisappear(FACEM, ptr_fctDisappear);
}


void Cubtile::addEventMotion(ID_FACE id, void (*ptr_fctMotion)(InfoEvent))
{	
	faces[id]->addEventMotion(Event(ptr_fctMotion));
}

void Cubtile::addEventAppear(ID_FACE id, void (*ptr_fctAppear)(InfoEvent))
{	
	faces[id]->addEventAppear(Event(ptr_fctAppear));
}

void Cubtile::addEventDisappear(ID_FACE id, void (*ptr_fctDisappear)(InfoEvent))
{	
	faces[id]->addEventDisappear(Event(ptr_fctDisappear));
}

Cubtile::~Cubtile()
{
	/*
	  Probablement rien à faire ici,
	  la video se termine proprement avec l'appel implicite au destructeur
	  Peut-être certaines images sont allouées explicitements ?
	*/	
}

