#include <iostream>
#include "tact.H"


int Tact::compteur = 0;

Tact::Tact(cv::Point2d p, clock_t t):
	position(p),
	deplacement(),
	vitesse(),
	temps(t)
{
	ecart_type = 0.2;
	id = compteur++; 
	absolue = false;
}
Tact::Tact() {}

int Tact::getId() {
	return id;
}

bool Tact::maj(cv::Point2d& p, clock_t t){
	if(absolue || cv::norm(p - position) > 3*ecart_type){
		vitesse = 0;
		deplacement.x = position.x - p.x;
		deplacement.y = position.y - p.y;
		position = p;
		temps = t;
		return true;
	}
	temps = t;
	return false;
}

cv::Point2d Tact::getPos(){
	return position;
}

cv::Point2d Tact::getPosPredict(clock_t t){
	return cv::Point2d(vitesse * (double) (t-temps)) + position;
}

cv::Point2d Tact::getDeplacement(){
	return deplacement;
}

cv::Vec2d Tact::getVitesse(){
	return vitesse;
}
	
void Tact::afficher(){

	std::cout<<"Identifiant : "<<id<<std::endl;	
	std::cout<<"Position : ("<< position.x << ", " << position.y << ")" <<std::endl;
	std::cout<<"Deplacement ("<<deplacement.x<<", "<<deplacement.y<<")"<<std::endl;
	std::cout<<"Vitesse : "<< (cv::Point2d(vitesse)).x <<"pix/ticks"<<std::endl;	
	std::cout<<"Prochaine Position : ("<< (this->getPosPredict(clock())).x << ", " << (this->getPosPredict(clock())).y <<" )"<<std::endl;	
	std::cout<<"Temps"<< temps <<std::endl;	

}

// UGLY : retourne vrai si un point pourrait correspondre à celui attendu
bool Tact::estProche(cv::Point2d p, double distance_max) {

	double distance = cv::norm(position - p);
	if( distance <= distance_max ){
		return true;
	}
	return false;
}


bool Tact::aEteMisAJour(clock_t t) const{
	return t == temps;
}
