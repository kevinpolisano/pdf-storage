#include "tracker.H"
#include "util.H"



Tracker::Tracker(double dist){
	distanceMax = dist;
}


void Tracker::mettreAJour(std::vector<cv::Point2d>& newPoints, clock_t temps, ID_FACE idf, double scale)
{


	// pour tous les points existants
	for( unsigned int i=0 ; i<ptsExistants.size() ; ++i ){
		unsigned int j;
		// pour tous les nouveaux points
		for(j=0 ; j<newPoints.size() ; ++j ){

			// Si il y en a un qui est assez proche :
			// - on met à jour,
			// - on sort le point de la liste
			// - on ajoute un evenementsMotion
			if( ptsExistants[i].estProche(newPoints[j], distanceMax)){
				if(ptsExistants[i].maj(newPoints[j], temps)){
					evenements.storeEventMotion(InfoEvent(idf, ptsExistants[i].getId(), ptsExistants[i].getPos()*scale));
				}
				newPoints.erase(newPoints.begin()+j);
				j = 10000;
			}
		}
	}
	
	
	// Si le point n'a pas de correspondant : 
	// Cest une apparition
	for(unsigned int i = 0; i<newPoints.size(); i++){
		ptsExistants.push_back(Tact(newPoints[i], temps));
		evenements.storeEventAppear(InfoEvent(idf, ptsExistants.back().getId(), ptsExistants.back().getPos()*scale));
	}

	// Enfin, les points qui n'ont pas été mis à jours ont disparus
	for( unsigned int i=0 ; i<ptsExistants.size() ; ++i ){
		if(!ptsExistants[i].aEteMisAJour(temps)){
			evenements.storeEventDisappear(InfoEvent(idf, ptsExistants[i].getId(), ptsExistants[i].getPos()*scale));
			ptsExistants.erase(ptsExistants.begin()+i);
		}
	}
}

void Tracker::configurer(){
	/*
	  TODO : peut-être inutile
	*/

	// La distance max quand même ??? etc...
	
}

void Tracker::configurerAffichage(AFFICHAGE_FACE aff, unsigned int temps_aff){
	/*
	  TODO : peut-etre inutile
	 */
}

void Tracker::addEventMotion(Event E)
{
	evenements.addEventMotion(E);
}

void Tracker::addEventAppear(Event E)
{
	evenements.addEventAppear(E);
}

void Tracker::addEventDisappear(Event E)
{
	evenements.addEventDisappear(E);
}

void Tracker::signaler()
{
	evenements.callBufferMotion();
	evenements.callBufferAppear();
	evenements.callBufferDisappear();
}

void Tracker::signalerMotion()
{
	evenements.callBufferMotion();
}
void Tracker::signalerAppear()
{
	evenements.callBufferAppear();
}

void Tracker::signalerDisappear()
{
	evenements.callBufferDisappear();
}


