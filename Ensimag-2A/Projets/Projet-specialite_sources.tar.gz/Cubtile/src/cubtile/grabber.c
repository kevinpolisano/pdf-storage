

#include <stdio.h>
#include <stdint.h>
#include <dc1394/dc1394.h>
#include <stdlib.h>
#include <inttypes.h>
#include <string.h>

#ifndef _WIN32
#include <unistd.h>
#endif

#include "grabber.h"



static dc1394camera_t *camera;
static dc1394featureset_t features;
static dc1394video_modes_t video_modes;
static dc1394video_mode_t video_mode = 0;
static dc1394color_coding_t coding;
static unsigned int width, height;
static dc1394video_frame_t *frame;
static dc1394_t * d;
static dc1394camera_list_t * list;

static dc1394error_t err;

static unsigned char * mem_adresse;



/*-----------------------------------------------------------------------
 *  Releases the cameras and exits
 *-----------------------------------------------------------------------*/
void cleanup_and_exit(dc1394camera_t *camera)
{
	dc1394_video_set_transmission(camera, DC1394_OFF);
	dc1394_capture_stop(camera);
	dc1394_camera_free(camera);
	exit(1);
}

int existeCamera(){
	d = dc1394_new ();
	if (!d)
		return 0;
	err=dc1394_camera_enumerate (d, &list);
	DC1394_ERR_RTN(err,"Failed to enumerate cameras");

	if (list->num == 0) {
		return 0;
	}
	else{
		return 1;
	}
}

int initCamera(){


	d = dc1394_new ();
	if (!d)
		return 1;
	err=dc1394_camera_enumerate (d, &list);
	DC1394_ERR_RTN(err,"Failed to enumerate cameras");

	if (list->num == 0) {
		dc1394_log_error("No cameras found");
		return 1;
	}

	camera = dc1394_camera_new (d, list->ids[0].guid);
	if (!camera) {
		dc1394_log_error("Failed to initialize camera with guid %"PRIx64, list->ids[0].guid);
		return 1;
	}

	dc1394_camera_free_list (list);

	printf("Using camera with GUID %"PRIx64"\n", camera->guid);
	return 0;
}

int setupCameraFormat7(){

	// get video modes:
	err=dc1394_video_get_supported_modes(camera,&video_modes);
	DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Can't get video modes");

	// select highest res mode: 7
	video_mode = DC1394_VIDEO_MODE_FORMAT7_0;


	return 0;
}


int confFormat7(){

	err=dc1394_get_color_coding_from_video_mode(camera, video_mode,&coding);
	DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Could not get color coding");
	
	err=dc1394_video_set_iso_speed(camera, DC1394_ISO_SPEED_400);
	DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Could not set iso speed");

	// Mode video 7
	err=dc1394_video_set_mode(camera, video_mode);
	DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Could not set video mode");

	// Régler le shutter
	err=dc1394_feature_set_value(camera,DC1394_FEATURE_SHUTTER, 200);
	DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Can't put the shutter");

	/*-----------------------------------------------------------------------
	 *  Image sizes
	 *-----------------------------------------------------------------------*/
	dc1394_get_image_size_from_video_mode(camera, video_mode, &width, &height);
	return 0;
}

int shutterFormat7(int shut){
	
	// Régler le shutter
	err = dc1394_feature_set_value(camera,DC1394_FEATURE_SHUTTER, shut);
	DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Can't put the shutter");

	dc1394_get_image_size_from_video_mode(camera, video_mode, &width, &height);
	return 0;
}




int startCamera(){

	err=dc1394_capture_setup(camera,4, DC1394_CAPTURE_FLAGS_DEFAULT);
	DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Could not setup camera-\nmake sure that the video mode and framerate are\nsupported by your camera");


	/*-----------------------------------------------------------------------
	 *  have the camera start sending us data
	 *-----------------------------------------------------------------------*/
	err=dc1394_video_set_transmission(camera, DC1394_ON);
	DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Could not start camera iso transmission");



	return 0;
}

int reportCameraFeatures(){

	/*-----------------------------------------------------------------------
	 *  report camera's features
	 *-----------------------------------------------------------------------*/
	err=dc1394_feature_get_all(camera,&features);
	if (err!=DC1394_SUCCESS) {
		dc1394_log_warning("Could not get feature set");
	}
	else {
		dc1394_feature_print_all(&features, stdout);
	}



	printf("video mode : %d \n",video_mode);
	printf("Format d'image : %i %i\n",height,width);
	return 0;
}




int deFrameGrab(unsigned char ** laframe){
	unsigned int i=0;
	for( i=0 ; i<3 ; ++i ){
//		printf("i=%d", i);
		err=dc1394_capture_dequeue(camera, DC1394_CAPTURE_POLICY_WAIT, &frame);
		DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Could not capture a frame");
		err=dc1394_capture_enqueue(camera, frame);                        
		DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Could not release a frame (deFrameGrab)");
	}
	err=dc1394_capture_dequeue(camera, DC1394_CAPTURE_POLICY_WAIT, &frame);
	DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Could not capture a frame");
	mem_adresse = *laframe;
	*laframe = frame->image;
	return 0;
}

 
int enFrameGrab(unsigned char ** laframe){
	*laframe = mem_adresse;
	err=dc1394_capture_enqueue(camera, frame);                        
	DC1394_ERR_CLN_RTN(err,cleanup_and_exit(camera),"Could not release a frame");
	return 0;
}


void stopperCamera(){
	
	dc1394_video_set_transmission(camera, DC1394_OFF);
	dc1394_capture_stop(camera);

}


void terminerCamera(){

	dc1394_camera_free(camera);
	dc1394_free (d);
}


int getHauteurGrab(){
	return height;
}

int getLargeurGrab(){
	return width;
}


