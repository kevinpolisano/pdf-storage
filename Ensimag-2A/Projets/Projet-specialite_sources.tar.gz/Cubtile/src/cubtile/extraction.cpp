#include <fstream>
#include "extraction.H"
#include <iostream>
#include "matx.H"

using namespace std;


//
// Configuratin des paramètres necessaires à l'extraction des points
// 
void Extraction::configurer(Matrx & imageRedressee, bool faceM){
	// les rayons des doigts
	rayonMin = 0;
	rayonMax = 7;

	// le temps d'affichage de chaque face
	temps_affichage = 1;

	// On enlève le bruit présent dans l'image pour récuperer la valeur max
	GaussianBlur(imageRedressee,whatever,cv::Size(3,3),0,0,cv::BORDER_DEFAULT);
	cv::minMaxLoc(whatever, NULL, &niveauSeuil, NULL, NULL);	

	//Pour eviter l'overflow dans le calcul du gradient
	depthGradient = CV_16SC1;

	// Affichage par défaut
	affichage = NONE;	
	faceMilieu = faceM;

	// Le rayon sur lequel on mesure le gradient des contours du doigt.
	rayonMoyenneGradient = 3.5;
	nbrPointsEchantillon = 100;

	// Une valeur différente selon la face
	if (!faceMilieu){
		seuilGradient = 7;
	} else {
		seuilGradient = 20;
	}

}

void Extraction::floutter(Matrx & img, Matrx & dest, cv::Size taille){
	GaussianBlur( img, dest, taille, 0, 0, cv::BORDER_DEFAULT );
}


void Extraction::calculerGradient(Matrx & img, Matrx & dest){

	int scale = 1;
	int delta = 0;

	// Gradient en x
	cv::Sobel( img, grad_x, depthGradient, 1, 0, 3, scale, delta, cv::BORDER_DEFAULT );
	cv::convertScaleAbs( grad_x, abs_grad_x );

	// Gradient en y
	cv::Sobel( img, grad_y, depthGradient, 0, 1, 3, scale, delta, cv::BORDER_DEFAULT );
	cv::convertScaleAbs( grad_y, abs_grad_y );

	// Norme 1 à la place de la norme euclidienne, faster...
	cv::addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0, dest);

	if(affichage == GRADIENT){
		dest.afficher(temps_affichage);
	}

}


void Extraction::seuiller(Matrx & img, Matrx & dest){

	if ( ! faceMilieu){
		// les 4 faces latérales ne peuvent pas être seuillées de manière uniformes
		seuilLineaire(img, dest, niveauSeuil-2,niveauSeuil+40);
	} else {
		// Seuil classique
		cv::threshold(img, dest, niveauSeuil + 50 , 255, cv::THRESH_BINARY);
	}
	if(affichage == SEUIL){
		dest.afficher(temps_affichage);
	}
}

void Extraction::distTrans(Matrx & img, Matrx & dest){
	cv::distanceTransform(img, dest, CV_DIST_L1, 3);
	if(affichage == DISTANCE){
		dest.afficher(temps_affichage);
	}
}


/*
  Algorithme utilisé : 
  - Seuil
  - Transformée en distance
  - On récupère les coordonnées du points de distance maximum
  - Ajout de ce point à la liste des candidats
  - On gomme la "tache" correspondant à ce point dans la transformée en distance
  - On recommence avec le point de distance maximum suivant
  -
 
 */
void Extraction::trouverCandidats(Matrx & imageRedressee){
	floutter(imageRedressee, lissee,cv::Size(3,3));
	seuiller(lissee, seuil);

	candidats.clear();
	cv::Point ptSuiv;

	distTrans(seuil, distTransform);


	bool ecri = false;
	std::vector<double> vec;

	// Tant qu'il reste des doigts
	do{

		double max;

		cv::minMaxLoc(distTransform, NULL, &max, NULL, &ptSuiv );	
		if (ecri){
			vec.push_back(max);
		}		
		// Un doigt a un rayon minimum et un rayon maximum
			if(max > rayonMin){
			if(max<rayonMax){
				candidats.push_back(ptSuiv);
			}
		}
		else 
			break;
		// On enlève le dernier doigt trouvé et on recommence avec les doigts restants
		cv::floodFill(distTransform, ptSuiv, cv::Scalar(), NULL, cv::Scalar(max-1, 0), cv::Scalar(0, 0), cv::FLOODFILL_FIXED_RANGE);
	}while(1);

	// Ce qui suit est utilisé pour les mesures et la visualisation des résultats

	if(affichage == CANDIDATS){
		for( unsigned int i=0 ; i<candidats.size() ; ++i ){
			circle(imageRedressee, candidats[i], 3, cv::Scalar_<int>(100, 100) );
			circle(imageRedressee, candidats[i], 4, cv::Scalar_<int>(150, 150) );
		}
		imageRedressee.afficher(temps_affichage);

	}
	if (ecri){
		std::ofstream fichier("niveauGradient.txt", std::ios::out | std::ios::trunc);
		if(fichier)
		{
			fichier << "x" << std::endl;
			for (unsigned int i = 0 ; i < vec.size() ; ++i ){
				fichier << vec[i]<< std::endl;
			}
			fichier.close();
		}
		else {
			std::cout << "impossible d'ouvrir le fichier1" << std::endl;
		}
	}

	// les candidats sont enfin triés pour enlever les faux positifs
	trierCandidats(imageRedressee);
}



// Suppose le seuil déjà calculé
// L'élimination des faux positifs se fait selon un gradient minimum a atteindre sur le contour du doigt.
void Extraction::trierCandidats(Matrx & img){


	std::vector<cv::Point2d>::iterator it = candidats.begin();

	// Calcul du gradient
	floutter(img, lissee, cv::Size(3,3));
	calculerGradient(lissee, gradient);

	bool ecri = false;
	std::vector<double> vec;

	// pour chaque candidat
	while(it != candidats.end()){

		double val4 = gradient.moyennePxDisque<unsigned char>(*it, rayonMoyenneGradient, nbrPointsEchantillon );
		if (ecri){
			vec.push_back(val4);
		}
		// Si le gradient n'est pas assez fort, on l'élimine
		if(val4<seuilGradient){ 
			if(affichage == ELIMINATION){
				circle(gradient, *it,rayonMoyenneGradient,cv::Scalar_<int>(200));
			}
			it = candidats.erase(it);
		}
		else{
			it++; 
		}
	}

	// Affichage et enregistrement des résultats
	if(affichage == ELIMINATION){
		gradient.afficher(temps_affichage);
	}
	if (ecri){
		std::ofstream fichier("niveauGradient.txt", std::ios::out | std::ios::trunc);
		if(fichier)
		{
			fichier << "x" << std::endl;
			for (unsigned int i = 0 ; i < vec.size() ; ++i ){
				fichier << vec[i]<< std::endl;
			}
			fichier.close();
		}
	
		else {
			std::cout << "impossible d'ouvrir le fichier2" << std::endl;
		}
	}
}



void Extraction::configurerAffichage(AFFICHAGE_FACE aff, unsigned int temps_aff){
	this->affichage = aff;
	temps_affichage = temps_aff;
}




cv::Rect Extraction::getRectROI(cv::Point2d pt,Matrx & reg){
	// tronc la zone de ROI dans le cas où on est sur les bords
	int xBas,yBas,xHaut,yHaut;
	xBas = ( pt.x - rayonMax < 0 ) ? 0 : pt.x-rayonMax;
	yBas = ( pt.y - rayonMax < 0 ) ? 0 : pt.y-rayonMax;
	xHaut = (pt.x + rayonMax >= reg.size().width	) ? reg.size().width : xBas + 2*rayonMax;
	yHaut = (pt.y + rayonMax >= reg.size().height	) ? reg.size().height : yBas + 2*rayonMax;

	return cv::Rect(xBas,yBas,xHaut-xBas,yHaut-yBas);
}


//
// Selectionne une region carré autour du centre et calcul le barycentre des points seuillées avec une pondération gaussienne sur le centre
//
cv::Point2d Extraction::extraireBaryPondGauss(cv::Point2d & pts, Matrx & imageRedressee, Matrx & gauss){

	double baryCourX = 0,baryCourY = 0;

	cv::Rect rect;
	baryCourX=baryCourY=0;
	// we select a ROI
	rect = getRectROI(pts,seuil);
	Matrx ROI(seuil,rect);
	for ( int i = 0; i < ROI.size().height ; ++i){
		for (int j = 0; j < ROI.size().width ; ++j){
			baryCourX +=  j * (gauss.at<double>(j,i));	
			baryCourY +=  i * (gauss.at<double>(j,i));
		}
	}
	return cv::Point2f(rect.x + baryCourX/ROI.size().width,rect.y + baryCourY/ROI.size().height);
}

//
// Extrait le barycentre de manière abituelle
//
cv::Point2d Extraction::extraireBary(cv::Point2d & pts, Matrx & imageRedressee){
	seuiller(imageRedressee, seuil);

	double baryCourX = 0,baryCourY = 0;
	int compteur = 0;

	cv::Rect rect;
	baryCourX=baryCourY=compteur=0;
	// we select a ROI
	rect = getRectROI(pts,seuil);
	Matrx ROI(seuil,rect);
	for ( int i = 0; i < ROI.size().height ; ++i){
		for (int j = 0; j < ROI.size().width ; ++j){
			baryCourX += rect.x + j;	
			baryCourY += rect.y + i;
			compteur ++;	
		}
	}
	return cv::Point2f(baryCourX/compteur,baryCourY/compteur);
}


void Extraction::extraireBaryPondIntens(std::vector<cv::Point2d> & pts, Matrx & imageRedressee){
	std::vector<cv::Point2d>::iterator it;

	double min, max;

	double translation = rayonMax;

	//Pour chaque point, on prend le barycentre des points contigus
	for(it = candidats.begin(); it != candidats.end(); it++){
		cv::Point2d somme(0, 0);
		double sommepond = 0;
		Matrx ROI;

		//On recupere le carré qui va bien
		imageRedressee(getRectROI(*it,imageRedressee)).copyTo(ROI); // Copie !!!

		// la valeur minimum du carré
		cv::minMaxLoc(ROI, &min, &max);

		//Barycentre coefficienté
		for(int i=0; i<ROI.rows; i++){
			for(int j=0; j<ROI.cols; j++){
				double coef = (ROI.getPx<unsigned char>(i, j)-min)/(max-min);
				coef = sqrt(coef);
				somme.x += i * coef;
				somme.y += j * coef;
				sommepond += coef;
			}
		}
		somme.x = somme.x /(double) sommepond;
		somme.y = somme.y /(double) sommepond;
		somme.x += (double)it->x-translation;
		somme.y += (double)it->y-translation;
		pts.push_back(somme);
	}
}



cv::Point2d Extraction::extraireCentreEllipse(cv::Point2d & pts){

	cv::Point2d res;

	int i,j;

	// on extrait la région of interest de seuil
	cv::Rect rect = getRectROI(pts,seuil);

	Matrx ROI(rect.height,rect.width,CV_8UC1);// doit être changé
	for ( j = 0; j < rect.width; ++j){
		for ( i = 0; i < rect.height; ++i){
			ROI.at<unsigned char>(j,i) = (int)seuil.at<unsigned char>(rect.y+j,rect.x+i);
		}
	}

	cv::Size taille = ROI.size();


	// variables
	Matrx onex;
	Matrx oney;

	onex = ROI.getProjectedHistoX();
	oney = ROI.getProjectedHistoY();	

	// on remplit un vecteur de point maintenant
	// nécessaire pour fitter l'ellipse
	std::vector<cv::Point2f> vx,vy;
	for( i = 0 ; i < taille.width; ++i ){
		vx.push_back(cv::Point2f(i+rect.x,(int)onex.at<unsigned char>(1,i)));
	}
	for( i = 0 ; i < taille.height ; ++i ){
		vy.push_back(cv::Point2f(i+rect.y,(int)oney.at<unsigned char>(i,1)));
	}

	// on fitte l'ellipse
	cv::RotatedRect rectx = cv::fitEllipse(cv::Mat(vx));
	cv::RotatedRect recty = cv::fitEllipse(cv::Mat(vy));
	res.x = rectx.center.x;
	res.y = recty.center.x;

	return res;

}

//
// Retourne 9 points disposés régulièrement dans carré de taille 2dimension * 2dimension
//
void getPattern(cv::Point2d centre, double dimension, vector<cv::Point2d>& pattern){
	for(int i = -1; i <=1; i++){
		for(int j = -1; j<=1; j++){
			cv::Point2d p;
			p.x = i*dimension;
			p.y = j*dimension;
			pattern.push_back(p+centre);
		}
	}
}

//
// Algorithme retournant la différence quadratique moyenne en subpixel avec la fenêtre centrée en position
//
double moyenneEcartsCarres(Matrx img, Matrx sub_img, cv::Point2d position){
	double somme=0;
	assert(sub_img.data!=NULL);
	double decalx = sub_img.cols/2.;
	double decaly = sub_img.rows/2.;
	for(int i = 0; i<sub_img.rows; i++){
		for(int j = 0; j<sub_img.cols; j++){
			double diff = 
				img.getSubPx<unsigned char>(position.y - decaly + i, position.x - decalx +j) - sub_img.getPx<unsigned char>(i, j) ;

			somme += diff * diff;
		}
	}
	return somme/(sub_img.rows * sub_img.cols); 
}


// Algorithme retournan la position du blockmatching
cv::Point2d Extraction::blockMatching(Matrx & img, Matrx & sub_image, cv::Point2d depart, double precision, double precisionDepart){

	double precisionCourante = precisionDepart;
	std::vector<cv::Point2d> pattern;
	cv::Point2d centreCourant = depart;
	std::vector<cv::Point2d>::iterator it;
	std::vector<cv::Point3d> vec;
	double minValue=10000000, value;
	cv::Point2d bestMatch;



	while(precisionCourante >= precision){
		getPattern(centreCourant, precisionCourante, pattern);
		for(it = pattern.begin(); it != pattern.end(); it++){
			value = moyenneEcartsCarres(img, sub_image, *it);
			vec.push_back(cv::Point3d(it->x,it->y,value));

			if(value<minValue) {
				minValue = value;
				bestMatch = *it;
			}
		}

		precisionCourante = precisionCourante/2.;
		centreCourant = bestMatch;
		pattern.clear();
	}


	bool score_match = false;
	if ( score_match ){	
		std::ofstream fichier("score_matching.txt", std::ios::out | std::ios::trunc);
		if(fichier)
		{
			fichier << "x" << " y" << " score" << std::endl;
			for ( unsigned i = 0 ; i < vec.size(); ++i){
				fichier << vec[i].x << " " << vec[i].y << " " << vec[i].z << std::endl;
			}
			fichier << bestMatch.x << " " << bestMatch.y << " " << minValue << std::endl;
		}
		else {
			std::cout << "Impossible d'ouvrir le fichier3" << std::endl;
			exit(1);
		}
	}

	
	return bestMatch;
}


// Algorithme non-subpixel
cv::Point2d Extraction::median(cv::Point2d & pts){
	cv::Point2d res;

	int i,j;

	// on extrait la région of interest de seuil
	cv::Rect rect = getRectROI(pts,seuil);

	Matrx ROI(rect.height,rect.width,CV_8UC1);// doit être changé
	for ( j = 0; j < rect.width; ++j){
		for ( i = 0; i < rect.height; ++i){
			ROI.at<unsigned char>(j,i) = (int)seuil.at<unsigned char>(rect.y+j,rect.x+i);
		}
	}
	std::vector<unsigned char> vx;
	std::vector<unsigned char> vy;



	// on parcours la ROI
	for ( j = 0; j < rect.width; ++j){
		for ( i = 0; i < rect.height; ++i){
			if (ROI.at<unsigned char>(j,i) != 0){
				vx.push_back(rect.x+j);vy.push_back(rect.y+i);
			}
		}
	}	

	// on trie le tableau avec la STL
	sort(vx.begin(),vx.end());
	sort(vy.begin(),vy.end());

	res.x = vx[vx.size()/2];
	res.y = vy[vy.size()/2];

	return res;

}


// Methode principale
void Extraction::extrairePoints(std::vector<cv::Point2d> & pts, Matrx & imageRedressee, CHOIX_ALGO algo, int r){
	pts.clear();
	candidats.clear();
	string pData; unsigned int i; double ra;
	Matrx patternTmp;
	Matrx gauss(2*rayonMax+1,2*rayonMax+1,CV_64FC1);
	cv::Size taille(rayonMax,rayonMax);
	gauss.initGauss(taille);
	switch(algo){
		case(ACANDIDATS):
			trouverCandidats(imageRedressee);
			pts = candidats;
			break;
		case(BARYCENTRE):
			trouverCandidats(imageRedressee);
			for ( i = 0 ; i < candidats.size(); ++i ){
				pts.push_back(extraireBary(candidats[i],imageRedressee));
			}
			break;
		case(BARYCENTRE_PONDERE_GAUSS):
			trouverCandidats(imageRedressee);
			for ( i = 0 ; i < candidats.size(); ++i ){
				pts.push_back(extraireBaryPondGauss(candidats[i],imageRedressee,gauss));
			}
			break;
		case(BARYCENTRE_VALEURS_PX):// utilisée l'intensité des pixels pour le centre
			trouverCandidats(imageRedressee);
			extraireBaryPondIntens(pts, imageRedressee);
			break;
		case(XY_PROJ_ELLIPSE_FIT):
			trouverCandidats(imageRedressee);
			for ( i = 0 ; i < candidats.size(); ++i ){
				pts.push_back(extraireCentreEllipse(candidats[i]));
			}
			break;
		case(CUBTILE_DATA):
			pData = getenv ("CUBTILE_DATA");
			if (pData!=""){
			}
			else{
				std::cout<<"Aucun patron disponible : abort"<<std::endl;
				exit(1);
			}
			pattern = Matrx(cv::imread(pData+"pattern_milieu.png", 1));
			if(pattern.data == NULL){
				std::cout<<"impossible x'ouvrir le pattern"<<std::endl;
				exit(1);
			}
			trouverCandidats(imageRedressee);
			for(i=0; i<candidats.size(); i++){
				pts.push_back(blockMatching(imageRedressee, pattern, candidats[i], 0.01, 3));
			}
			break;

		case(DISQUE):
			// rayon du plateau à modifier
			pattern = Matrx(2*r,2*r,CV_8UC1);
			unsigned int i;
			for (int i = 0; i < 2*r ; ++i){
				for (int j = 0; j < 2*r;++j){
					pattern.at<unsigned char>(i,j) = 0;
				}
			}
			// the last parameter is -1 to draw a full circle
			circle(pattern,cv::Point(r,r),r,cv::Scalar_<int>(255),-1);
			trouverCandidats(imageRedressee);
			for(i=0; i<candidats.size(); i++){
				pts.push_back(blockMatching(imageRedressee, pattern, candidats[i], 0.01, 3));
			}
			break;
		case(GRADIENT_FLOU):
			// rayon du cercle à modifier ( peut être similaire au cas précédent )
			ra = 6;
			patternTmp = Matrx(4*ra,4*ra,CV_8UC1);
			for (int i = 0; i < 4*ra ; ++i){
				for (int j = 0; j < 4*ra;++j){
					patternTmp.at<unsigned char>(i,j) = 0;
				}
			}
			circle(patternTmp,cv::Point(2*ra,2*ra),ra,cv::Scalar_<int>(255));
			// we have to apply a blurry filter
			floutter(patternTmp,pattern,cv::Size(5,5));
			trouverCandidats(imageRedressee);

			for(i=0; i<candidats.size(); i++){
				pts.push_back(blockMatching(gradient, pattern, candidats[i], 0.01, 3));
			}

		case(MEDIAN):
			trouverCandidats(imageRedressee);
			for ( i = 0 ; i < candidats.size(); ++i ){
				pts.push_back(median(candidats[i]));
			}
			break;


		default:
			std::cout<<"CHOIX ALGO INCONNU"<<std::endl;
			exit(1);
			break;
	}
}
