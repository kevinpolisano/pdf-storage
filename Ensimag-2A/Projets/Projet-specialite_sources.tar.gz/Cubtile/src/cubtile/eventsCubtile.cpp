#include <iostream>
#include "eventsCubtile.H"

void EventsCubtile::addEventMotion(Event E){
	Motion.push_back(E);
}
void EventsCubtile::addEventAppear(Event E){
	Appear.push_back(E);
}
void EventsCubtile::addEventDisappear(Event E){
	Disappear.push_back(E);
}

void EventsCubtile::callEventMotion(InfoEvent I){
	std::vector<Event>::iterator it;
	for(it = Motion.begin(); it != Motion.end(); it++){
		if(I.face ==FACEM && norm(I.pos)<2){
			I.pos.x = 1-I.pos.x;
		}
		it->action(I);
	}
}

void EventsCubtile::callEventAppear(InfoEvent I){
	std::vector<Event>::iterator it;
	for(it = Appear.begin(); it!= Appear.end(); it++){
		if(I.face ==FACEM && norm(I.pos)<2){
			I.pos.x = 1-I.pos.x;
		}
		it->action(I);
	}
}

void EventsCubtile::callEventDisappear(InfoEvent I){
	std::vector<Event>::iterator it;
	for(it = Disappear.begin(); it!= Disappear.end(); it++){
		if(I.face ==FACEM && norm(I.pos)<2){
			I.pos.x = 1-I.pos.x;
		}
		it->action(I);
	}

}



void EventsCubtile::storeEventMotion(InfoEvent I){
	bufferMotion.push_back(I);
}
void EventsCubtile::storeEventAppear(InfoEvent I){
	bufferAppear.push_back(I);
}
void EventsCubtile::storeEventDisappear(InfoEvent I){
	bufferDisappear.push_back(I);
}


void EventsCubtile::callBufferMotion(){
	std::vector<InfoEvent>::iterator it;
	for(it = bufferMotion.begin(); it != bufferMotion.end(); it++){
		callEventMotion(*it);
	}
	bufferMotion.clear();
}
void EventsCubtile::callBufferAppear(){
	std::vector<InfoEvent>::iterator it;
	for(it = bufferAppear.begin(); it != bufferAppear.end(); it++){
		callEventAppear(*it);
	}
	bufferAppear.clear();
}
void EventsCubtile::callBufferDisappear(){
	std::vector<InfoEvent>::iterator it;
	for(it = bufferDisappear.begin(); it != bufferDisappear.end(); it++){
		callEventDisappear(*it);
	}
	bufferDisappear.clear();
}


void EventsCubtile::printStackEvents(){
	std::cout<<"Nombre fonction Appear"<<Appear.size()<<std::endl;
	std::cout<<"Nombre fonction Disappear"<<Disappear.size()<<std::endl;
	std::cout<<"Nombre fonction Motion"<<Motion.size()<<std::endl;

	std::cout<<"Nombre fonction BufferAppear"<<bufferAppear.size()<<std::endl;
	std::cout<<"Nombre fonction bufferDisappear"<<bufferDisappear.size()<<std::endl;
	std::cout<<"Nombre fonction bufferMotion"<<bufferMotion.size()<<std::endl;
}
