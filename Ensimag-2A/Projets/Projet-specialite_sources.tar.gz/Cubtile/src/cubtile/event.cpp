#include "event.H"
#include "util.H"

Event::Event(void (*p)(InfoEvent))
{
	ptrfonction = p;
}

void Event::action(InfoEvent i){
	ptrfonction(i);
}
