#ifndef OBJET_SCENE_H
#define OBJET_SCENE_H


#include <QGLViewer/qglviewer.h>

#include "point_3d.h"



/**
 * \brief Représente un objet dans la scène.
 * \brief La position, la rotation et déformation initiale sont données en paramètre dans le constructeur
 * \param dock un booléen qui indique si l'objet est un dock dans la scène
 * 
 */
class ObjetScene
{
protected:
	double echelle;
	
	double posX, posY, posZ;
	double rotX, rotY, rotZ;
	double scaX, scaY, scaZ;
	
	Point3D* A;
	Point3D* B;
	Point3D* C;
	double alpha;
	
	double* matriceCourante;
	double* matriceRotation;
	double* matriceRotationInverse;
	double* matriceCubtile;
	
	
public:
	ObjetScene(
		double echelle,
		bool dock,
		double posX=0, double posY=0, double posZ=0,
		double rotX=0, double rotY=0, double rotZ=0,
		double scaX=1, double scaY=1, double scaZ=1 );
	virtual ~ObjetScene();
	
	
	void draw(qglviewer::Quaternion orientationCamera);
	void tourner(Point3D* ptFixe, Point3D* ptA, Point3D* ptB);
	void scale(Point3D* ptC, Point3D* ptD, Point3D* ptA, Point3D* ptB);
	
	static bool docked(ObjetScene* objU, ObjetScene* objV);
	
};

#endif