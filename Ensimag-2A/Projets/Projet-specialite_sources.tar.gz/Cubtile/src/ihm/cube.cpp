#include <iostream>
#include <cmath>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif


#ifdef __APPLE__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#else
#include <GL/gl.h>
#endif


#include "cube.h"
#include "objet_scene.h"
#include "point_3d.h"
#include "scene_3d.h"
#include "matrice_4x4.h"




Cube::Cube(
	double echelle, 
	double longueurCote,
	bool dock,
	double posX, double posY, double posZ,
	double rotX, double rotY, double rotZ,
	double scaX, double scaY, double scaZ
) : ObjetScene(
		echelle,
		dock,
		posX, posY, posZ,
		rotX, rotY, rotZ,
		scaX, scaY, scaZ
	)
{
	this->i = echelle * longueurCote/2.0;
}

Cube::~Cube() {}

void Cube::draw(qglviewer::Quaternion orientationCamera){
	
	/**
	std::cout << "  les points pour le dock : ";
	A->afficher();
	B->afficher();
	C->afficher();
	
	std::cout << "ALPHA = " << alpha << std::endl;
	**/
if( alpha!=1 )
	glEnable(GL_BLEND);

	
	ObjetScene::draw(orientationCamera);


glPushMatrix();
// 	glLoadMatrixd(matriceCourante);
	glTranslated( posX, posY, posZ );
	glRotated( rotX, 1, 0, 0 );
	glRotated( rotY, 0, 1, 0 );
	glRotated( rotZ, 0, 0, 1 );
	
	glMultMatrixd(matriceCourante);
	glScaled( scaX, scaY, scaZ );
	
glBegin(GL_QUADS);          // Start Drawing Quads

	
	glColor4d( 1, 0, 0, alpha );
	// Face +Z
	glNormal3f( 0.0f,  0.0f, 1.0f);      // Normal Facing Forward
	glVertex3f( -i, -i,  i);
	glVertex3f( -i,  i,  i);
	glVertex3f(  i,  i,  i);
	glVertex3f(  i, -i,  i);

	glColor4d( 0, 1, 0, alpha );
	// Face -Z
	glNormal3f( 0.0f, 0.0f,-1.0f);      // Normal Facing Away
	glVertex3f( -i, -i, -i);
	glVertex3f( -i,  i, -i);
	glVertex3f(  i,  i, -i);
	glVertex3f(  i, -i, -i);

	glColor4d( 0, 0, 1, alpha );
	// Face +Y
	glNormal3f( 0.0f, 1.0f, 0.0f);      // Normal Facing Up
	glVertex3f( -i,  i, -i);
	glVertex3f( -i,  i,  i);
	glVertex3f(  i,  i,  i);
	glVertex3f(  i,  i, -i);

	glColor4d( 1, 1, 0, alpha );
	// Face -Y
	glNormal3f( 0.0f,-1.0f, 0.0f);      // Normal Facing Down
	glVertex3f( -i, -i, -i);
	glVertex3f( -i, -i,  i);
	glVertex3f(  i, -i,  i);
	glVertex3f(  i, -i, -i);

	glColor4d( 0, 1, 1, alpha );
	// Face +X
	glNormal3f( 1.0f, 0.0f, 0.0f);      // Normal Facing Right
	glVertex3f(  i, -i, -i);
	glVertex3f(  i, -i,  i);
	glVertex3f(  i,  i,  i);
	glVertex3f(  i,  i, -i);

	glColor4d( 1, 0, 1, alpha );
	// Face -X
	glNormal3f(-1.0f, 0.0f, 0.0f);      // Normal Facing Left
	glVertex3f( -i, -i, -i);
	glVertex3f( -i, -i,  i);
	glVertex3f( -i,  i,  i);
	glVertex3f( -i,  i, -i);
	
	
glEnd();                    // Done Drawing Quads

glPopMatrix();

glDisable(GL_BLEND);
}

