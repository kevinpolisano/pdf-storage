#include <QApplication>
#include <QKeyEvent>

#include <iostream>
#include <cmath>

#include "window_scene_3d.h"
// #include "interpreteur.h"
#include "observateur_3d.h"
#include "point_3d.h"

#include "serveur.h"




Observateur3D::Observateur3D() {
	centre = new Point3D(-1, 0, 0, 0);
	fenetre_principale = new WindowScene3D(echelle);
}

Observateur3D::~Observateur3D() {}
	
void Observateur3D::traiter(Paquet p) {
	static int compteur = 0;
	compteur++;
	
// 	if( compteur%10 == 0 ){
// 		points.clear();
// 	}
	
	std::cout << "SIZE_avant=" << points.size() << " valeurs :" << std::endl;
	for( unsigned int i=0 ; i<points.size() ; ++i ){
		std::cout <<  " ";
		points[i]->afficher();
	}
	std::cout << std::endl;
	
	
	
	
	
	int face=p.face;
	if( face>=0 && face<=4 ){
// 	if( face == FACEM ){
		
		if( p.typeEvent == 'm' ){
			for( unsigned int i=0 ; i<points.size() ; ++i ){
				if( points[i]->getId() == p.id ){
					
					//TODO try
					Point3D* point = placement3D(p);
					if( points.size() == 1 ){
						//fenetre_principale->scene->cube->tourner( centre, points[i], point );
						//fenetre_principale->tourner( centre, points[i], point );
					}
					else if( points.size() == 2 ){
						fenetre_principale->scene->cube->tourner( points[(i+1)%2], points[i], point );
					}
					else if( points.size() == 3) {
						fenetre_principale->scene->cube->scale( points[(i+1)%3], points[(i+2)%3], points[i], point );
					}
					points[i]=point;
					break;
				}
			}
		
			fenetre_principale->update();
		}
		if( p.typeEvent == 'a' ){
// 			if( points.size() < 1 ){
				//TODO try
				Point3D* point = placement3D(p);
				points.push_back( point );
	// 			interpreteur->newFinger(p.face, p.id, p.posX, p.posY);
// 			}
		}
		if( p.typeEvent == 'd' ){
			for( unsigned int i=0 ; i<points.size() ; ++i ){
// 				std::cout << "points[i]->getId() = " << points[i]->getId() << std::endl;
// 				std::cout << "p.id = " <<  p.id << std::endl;
				if( points[i]->getId() == p.id ){
// 					std::cout << "ERASE" << std::endl;
					points.erase( points.begin()+i );
					break;
				}
			}
		}
	}
	/**
	std::cout << "SIZE_apres=" << points.size() << " valeurs :" << std::endl;
	for( unsigned int i=0 ; i<points.size() ; ++i ){
		std::cout <<  " ";
		points[i]->afficher();
	}
	std::cout << std::endl;
	**/
	
	
	
	
	
	
	if( fenetre_principale->scene->docking() ){
		std::cout << "\n\n ******* VOUS AVEZ GAGNE !!!! ******* \n\n" << std::endl;
	}
}

Point3D* Observateur3D::placement3D(Paquet p){
	switch(p.face)
	{
		case FACEH:
			std::cout << "** ** FACE du haut ** **" << std::endl;
			return new Point3D( p.id, echelle * (p.posX -0.5), echelle * (0.0 -0.5), echelle * (p.posY -0.5) );
			break;
		case FACEB:
			std::cout << "** ** FACE du bas ** **" << std::endl;
			return new Point3D( p.id, echelle * (1-p.posX -0.5), echelle * (1.0 -0.5), echelle * (p.posY -0.5) );
			break;
		case FACEM:
			std::cout << "** ** FACE du milieu ** **" << std::endl;
			return new Point3D( p.id, echelle * (p.posX -0.5), echelle * (p.posY -0.5), echelle * (0.0  -0.5) );
			break;
		case FACED:
			std::cout << "** ** FACE de droite ** **" << std::endl;
			return new Point3D( p.id, echelle * (1.0 -0.5), echelle * (p.posX -0.5), echelle * (p.posY -0.5) );
			break;
		case FACEG:
			std::cout << "** ** FACE de gauche ** **" << std::endl;
			return new Point3D( p.id, echelle * (0.0 -0.5), echelle * (1.0-p.posX -0.5), echelle * (p.posY -0.5) );
			break;
		default:
			//TODO exception
			break;
	}
}

