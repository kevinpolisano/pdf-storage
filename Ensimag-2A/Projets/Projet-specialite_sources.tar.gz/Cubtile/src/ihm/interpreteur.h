#ifndef INTERPRETEUR_H
#define INTERPRETEUR_H

#include "window_scene_3d.h"
#include "tact.h"

class Interpreteur
{
private:
	WindowScene3D* ws;
	
	std::vector<Tact*> doigts;
	
public:
	Interpreteur(WindowScene3D* ws);
	~Interpreteur();
	
	void newFinger(int face, int id, double x, double y);
	void moveFinger(int face, int id, double x, double y);
	void removeFinger(int face, int id);
	
	void afficheFinger();
};

#endif