#include <iostream>
#include <cmath>

#include "matrice_4x4.h"

void afficher(double* matrice) {
	for( int i=0 ; i<16 ; ++i ){
		std::cout << matrice[i] << " ";
		if( (i+1)%4 == 0 ){
			std::cout << std::endl;
		}
	}
}

void normaliser(double* &matrice) {
	double f = matrice[15];
	if( f != 0 ){
		for( unsigned int i=0 ; i<16 ; ++i ){
			matrice[i] /= f;
		}
	}
}

void transposer(double* &matrice) {
	double* transposition = getMatriceNulle();
		
	transposition[0] = matrice[0];
	transposition[4] = matrice[1];
	transposition[8] = matrice[2];
	transposition[12] = matrice[3];
	
	transposition[1] = matrice[4];
	transposition[5] = matrice[5];
	transposition[9] = matrice[6];
	transposition[13] = matrice[7];
	
	transposition[2] = matrice[8];
	transposition[6] = matrice[9];
	transposition[10] = matrice[10];
	transposition[14] = matrice[11];
	
	transposition[3] = matrice[12];
	transposition[7] = matrice[13];
	transposition[11] = matrice[14];
	transposition[15] = matrice[15];
	
	matrice = transposition;
}

double* getMatriceNulle() {
	double* matrice = new double[16];
	for( unsigned int i=0 ; i<16 ; ++i ){
		matrice[i] = 0;
	}
	return matrice;
}

double* getMatriceIdentite() {
	double* matrice = getMatriceNulle();
	for( unsigned int i=0 ; i<4 ; ++i ){
		matrice[5*i] = 1;
	}
	
	return matrice;
}

double* getMatriceTranslation(double tx, double ty, double tz) {
	double* matrice = getMatriceIdentite();
	matrice[3]  = tx;
	matrice[7]  = ty;
	matrice[11] = tz;
	
	return matrice;
}
double* getMatriceRotationSimple(double angle, double rotX, double rotY, double rotZ) {
	double* matrice = getMatriceIdentite();
	
	if( angle != 0 ){
		double c = cos(angle);
		double s = sin(angle);
		
		matrice[0] = rotX*rotX*(1-c)+c;
		matrice[1] = rotX*rotY*(1-c)-rotZ*s;
		matrice[2] = rotX*rotZ*(1-c)+rotY*s;
		matrice[3] = 0;
		
		matrice[4] = rotX*rotY*(1-c)+rotZ*s;
		matrice[5] = rotY*rotY*(1-c)+c;
		matrice[6] = rotY*rotZ*(1-c)-rotX*s;
		matrice[7] = 0;
		
		matrice[8] = rotX*rotZ*(1-c)-rotY*s;
		matrice[9] = rotY*rotZ*(1-c)+rotX*s;
		matrice[10] = rotZ*rotZ*(1-c)+c;
		matrice[11] = 0;
		
		matrice[12] = 0;
		matrice[13] = 0;
		matrice[14] = 0;
		matrice[15] = 1;
	}
	return matrice;
}

/**
 * \brief Rotation à partir d'un axe défini par les 3 points
 * 
 */
double* getMatriceRotationComplexe(
	double angle, double nx, double ny, double nz,
	double a, double b, double c ) {
	double* matrice = getMatriceIdentite();
	
	if( angle != 0 ){
		double co = cos(angle);
		double si = sin(angle);
		
		double l = nx*nx + ny*ny + nz*nz;
		
		matrice[0] = ( nx*nx + (ny*ny + nz*nz) * co ) / l;
		matrice[1] = ( nx * ny * (1-co) - nz * sqrt(l) * si ) / l;
		matrice[2] = ( nx * nz * (1-co) + ny * sqrt(l) * si ) / l;
		matrice[3] = ( ( a * (ny*ny + nz*nz) - nx * (b*ny + c*nz) ) * (1-co) + (b*nz - c*ny) * sqrt(l) * si ) / l;
		
		matrice[4] = ( nx * ny * (1-co) + nz * sqrt(l) * si ) / l;
		matrice[5] = ( ny*ny + (nx*nx + nz*nz) * co ) / l;
		matrice[6] = ( ny * nz * (1-co) - nx * sqrt(l) * si) / l;
		matrice[7] = ( ( b * (nx*nx + nz*nz) - ny * (a*nx + c*nz) ) * (1-co) + (c*nx - a*nz) * sqrt(l) * si ) / l;
		
		matrice[8] = ( nx * nz * (1-co) - ny * sqrt(l) * si) / l;
		matrice[9] = ( ny * nz * (1-co) + nx * sqrt(l) * si) / l;
		matrice[10] = ( nz*nz + (nx*nx + ny*ny) * co ) / l;
		matrice[11] = ( ( c * (nx*nx + ny*ny) - nz * (a*nx + b*ny) ) * (1-co) + (a*ny - b*nx) * sqrt(l) * si ) / l;
		
		matrice[12] = 0;
		matrice[13] = 0;
		matrice[14] = 0;
		matrice[15] = 1;
	}
	return matrice;
}


double* getMatriceRotationPoint( Point3D* ptC, Point3D* ptA, Point3D* ptB ) {
	
	/////////////////////////
	// Matrice de rotation //
	/////////////////////////
	
	// vecteur CA
	Point3D vec_CA(
		-1,
		ptA->x - ptC->x,
		ptA->y - ptC->y,
		ptA->z - ptC->z
	);
	vec_CA.normaliser();
	
	// vecteur CB
	Point3D vec_CB(
		-1,
		ptB->x - ptC->x,
		ptB->y - ptC->y,
		ptB->z - ptC->z
	);
	vec_CB.normaliser();
	
	
	// produit vectoriel entre les vecteurs CA et CB normalises
	// pour obtenir la normale a la rotation
	Point3D* normale = Point3D::produitVectoriel( &vec_CA, &vec_CB );
	normale->normaliser();
	
	//produit scalaire
	double alpha = acos( Point3D::produitScalaire( &vec_CA, &vec_CB ) );
	
	double* matriceRotation = getMatriceRotationComplexe(alpha, normale->x, normale->y, normale->z, ptC->x, ptC->y, ptC->z);
	normaliser(matriceRotation);
	
	return matriceRotation;
}

Point3D* multMatrix(double* matA, Point3D* ptB) {
	double* matB = new double[4];
	matB[0] = ptB->x;
	matB[1] = ptB->y;
	matB[2] = ptB->z;
	matB[3] = 1;
	
	double* matC = new double[4];
	matC[0] = 0;
	matC[1] = 0;
	matC[2] = 0;
	matC[3] = 0;
	
	for( unsigned int i=0 ; i<4 ; ++i ){
// 		for( unsigned int j=0 ; j<4 ; ++j ){
			for( unsigned int k=0 ; k<4 ; ++k ){ 
				matC[i] += matA[4*i+k] * matB[k];
// 				matC[i] += matB[4*i] * matA[4*i+k];
			}
// 		}
	}
	
	std::cout << "MAT A : ";
	afficher(matA);
	
	double f = matC[3];
	std::cout << "F=" << f << std::endl;
// 	if( f>0.0001 ){
// 		for( unsigned int i=0 ; i<4 ; ++i ){
// 			matC[i] = matC[i]/f;
// 		}
// 	}
	
	Point3D* ptC = new Point3D( ptB->getId(), matC[0], matC[1], matC[2] );
	delete[] matB;
	delete[] matC;
	return ptC;
	
}


double* multMatrix(double* matA, double* matB) {
	double* matC = getMatriceNulle();
	
	for( unsigned int i=0 ; i<4 ; ++i ){
		for( unsigned int j=0 ; j<4 ; ++j ){
			for( unsigned int k=0 ; k<4 ; ++k ){ 
				matC[4*i+j] += matA[4*i+k] * matB[4*k+j];
			}
		}
	}
	return matC;
}
	
	
double* getMatriceScale(double kx, double ky, double kz) {
	double* matrice =  getMatriceIdentite();
	matrice[0] = kx;
	matrice[5] = ky;
	matrice[10] = kz;

	return matrice;

}

double* getMatriceInverse(double* matA) {
	double* matrice =  getMatriceNulle();
	
	matrice[0] = matA[0];
	matrice[1] = matA[4];
	matrice[2] = matA[8];
	matrice[3] = matA[12];
	
	matrice[4] = matA[1];
	matrice[5] = matA[5];
	matrice[6] = matA[9];
	matrice[7] = matA[13];
	
	matrice[8] = matA[2];
	matrice[9] = matA[6];
	matrice[10] = matA[10];
	matrice[11] = matA[14];
	
	matrice[12] = matA[3];
	matrice[13] = matA[7];
	matrice[14] = matA[11];
	matrice[15] = matA[15];
	
	return matrice;
}
