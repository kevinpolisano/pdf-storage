#ifndef SCENE_2D_H
#define SCENE_2D_H

#include <QGraphicsScene>
#include <QGraphicsView>
#include <QWidget>

#include <vector>
#include <string>

#include "finger.h"

class Scene2D : public QGraphicsScene
{
private:
	unsigned int largeur;
	std::vector<Finger*> fingers;

public:
	QGraphicsView* view;
	
	Scene2D(QWidget* parent, const unsigned int largeur, const char* color="white");
	virtual ~Scene2D();
	
	unsigned int getLargeur();

	void show();
	void newFinger(int id, double x, double y);
	void moveFinger(int id, double x, double y);
	void removeFinger(int id);
	void afficheFinger();
	void refresh();
};

#endif
