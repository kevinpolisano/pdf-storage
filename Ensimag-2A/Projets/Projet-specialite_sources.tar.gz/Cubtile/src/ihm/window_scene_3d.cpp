#include <iostream>
#include <QGLViewer/qglviewer.h>

#include "window_scene_3d.h"
#include "matrice_4x4.h"
#include "point_3d.h"


WindowScene3D::WindowScene3D(double echelle) {
	this->echelle = echelle;
	
	setWindowTitle("viewer");
	
	setFixedSize(635, 635);
	show();
}

WindowScene3D::~WindowScene3D() {}



void WindowScene3D::init() {
	// Restore previous viewer state.
// 	restoreStateFromFile();
	  
	glEnable(GL_NORMALIZE);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_AUTO_NORMAL);
	glEnable(GL_COLOR_MATERIAL);
	
	
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	
	setSceneRadius(1000);
	
	modeFilaire = false;
	
	// Fenetre d'aide
// 	help();
	matriceCamera = new double[16];
	scene = new Scene3D(echelle);
}

void WindowScene3D::draw()
{
	camera()->getModelViewMatrix(matriceCamera);
// 	glGetDoublev(GL_MODELVIEW_MATRIX, matriceCamera);
// // 	camera()->getProjectionMatrix(matriceCamera);
// 	camera()->getModelViewProjectionMatrix(matriceCamera);


	qglviewer::Quaternion orientationCamera(camera()->orientation());
// 	orientationCamera.getMatrix(matriceCamera);
	scene->draw(orientationCamera);
}

void WindowScene3D::animate()
{
// 	cube->rotZ += 0.10;
	
}

void WindowScene3D::tourner(Point3D* ptC, Point3D* ptA, Point3D* ptB)
{	
	double* matriceRotation = getMatriceRotationPoint( ptC, ptA, ptB );
	
	qglviewer::Vec posCamera = camera()->position();
	Point3D* p = multMatrix(matriceRotation, &Point3D(-1, posCamera.x, posCamera.y, posCamera.z));
	
	camera()->setPosition(qglviewer::Vec(p->x, p->y, p->z));
	camera()->lookAt(qglviewer::Vec(0, 0, 0));
	std::cout << "::tourner de la fenetre" << std::endl;
}


void WindowScene3D::keyPressEvent(QKeyEvent * e) {
	// Get event modifiers key
	const Qt::KeyboardModifiers modifiers = e->modifiers();
	
	// A simple switch on e->key() is not sufficient if we want to take state key into account.
	// With a switch, it would have been impossible to separate 'F' from 'CTRL+F'.
	// That's why we use imbricated if...else and a "handled" boolean.
	bool handled = false;
	if( (e->key()==Qt::Key_W) && (modifiers==Qt::NoButton) ){
		modeFilaire = !modeFilaire;
		if( modeFilaire ){
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		}
		else {
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		}
		handled = true;
		updateGL();
	}
	
	if( !handled )
		QGLViewer::keyPressEvent(e);
}

QString WindowScene3D::helpString() const {
	QString text("<h2>V i e w e r</h2>");
	text += "Use the mouse to move the camera around the object. ";
	text += "You can respectively revolve around, zoom and translate with the three mouse buttons. ";
	text += "Left and middle buttons pressed together rotate around the camera view direction axis<br><br>";
	text += "Pressing <b>Alt</b> and one of the function keys (<b>F1</b>..<b>F12</b>) defines a camera keyFrame. ";
	text += "Simply press the function key again to restore it. Several keyFrames define a ";
	text += "camera path. Paths are saved when you quit the application and restored at next start.<br><br>";
	text += "Press <b>F</b> to display the frame rate, <b>A</b> for the world axis, ";
	text += "<b>Alt+Return</b> for full screen mode and <b>Control+S</b> to save a snapshot. ";
	text += "See the <b>Keyboard</b> tab in this window for a complete shortcut list.<br><br>";
	text += "Double clicks automates single click actions: A left button double click aligns the closer axis with the camera (if close enough). ";
	text += "A middle button double click fits the zoom of the camera and the right button re-centers the scene.<br><br>";
	text += "A left button double click while holding right button pressed defines the camera <i>Revolve Around Point</i>. ";
	text += "See the <b>Mouse</b> tab and the documentation web pages for details.<br><br>";
	text += "Press <b>Escape</b> to exit the viewer.";
	return text;
}

