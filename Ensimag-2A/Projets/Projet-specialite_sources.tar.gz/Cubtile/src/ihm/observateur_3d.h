#ifndef OBSERVATEUR_3D_H
#define OBSERVATEUR_3D_H

#include <QKeyEvent>
#include <QGLViewer/qglviewer.h>

#include <vector>

#include "serveur.h"
#include "observateur.h"
#include "window_scene_3d.h"
#include "point_3d.h"




class Observateur3D : public Observateur
{
private:
	Point3D* centre;
	std::vector<Point3D*> points; // l'ensemble des doigts
	
	WindowScene3D* fenetre_principale;
	
	static const double echelle=50;
public:
	
	Observateur3D();
	virtual ~Observateur3D();
	
	void traiter(Paquet p);
	static Point3D* placement3D(Paquet p);
};

#endif
