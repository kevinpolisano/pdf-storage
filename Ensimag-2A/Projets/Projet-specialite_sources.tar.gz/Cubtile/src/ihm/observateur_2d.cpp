#include <iostream>

#include "observateur_2d.h"




Observateur2D::Observateur2D() {
	fenetre_principale = new WindowScene2D(largeurScene);
	scenes = fenetre_principale->getScenes(); // opti
}

Observateur2D::~Observateur2D() {}
	
void Observateur2D::traiter(Paquet p) {
	int face=p.face;
	if( face>=0 && face<=4 ){
		if( p.typeEvent == 'm' ){
			scenes[face]->moveFinger(
				p.id, p.posX*largeurScene, p.posY*largeurScene );
		}
		if( p.typeEvent == 'a' ){
			scenes[face]->newFinger(
				p.id, p.posX*largeurScene, p.posY*largeurScene );
		}
		if( p.typeEvent == 'd' ){
			scenes[face]->removeFinger(p.id);
		}
	}
	scenes[face]->refresh();
}
