#include <cmath>

#include "tact.h"

Tact::Tact(int face, int id, double x, double y) {
	this->face = face;
	this->id = id;
	this->x = x;
	this->y = y;
}

Tact::~Tact() {}

int Tact::getFace() {
	return face;
}
int Tact::getId() {
	return id;
}

void Tact::moveTo(double x, double y) {
	this->x = x;
	this->y = y;
}

bool Tact::estProche(double x1, double y1){
	
	double distance = sqrt( (x1-x)*(x1-x) + (y1-y)*(y1-y) );
	
	if( distance<50 ){
		return true;
	}
	return false;
}