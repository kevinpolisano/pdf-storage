#ifndef TACT_H
#define TACT_H

class Tact
{
protected:
	int face;
	int id;
	double x;
	double y;
	
public:
	Tact(int face, int id, double x, double y);
	virtual ~Tact();
	
	int getId();
	int getFace();
	void moveTo(double x, double y);
	bool estProche(double x, double y);
	
};

#endif