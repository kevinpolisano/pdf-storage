#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <netdb.h>
#include <string.h>
#include <iostream>

#include "serveur.h"
#include "observateur.h"

bool affichage=true;

void* serveur(void* data){
	
	Observateur* observateur;
	observateur = (Observateur*) data;
	
	int sock = socket(AF_INET, SOCK_DGRAM, 0);
	if(sock == -1) {
		perror("socket()");
		exit(errno);
	}

	struct sockaddr_in sin;
	sin.sin_addr.s_addr = htonl(INADDR_ANY);
	sin.sin_family = AF_INET;
	sin.sin_port = htons(25555);

	if(bind (sock, (struct sockaddr *) &sin, sizeof sin) == -1)
	{
		perror("bind()");
		exit(errno);
	}


	struct sockaddr_in socket_client;
	socklen_t socket_client_size = sizeof(struct sockaddr_in);
	
	
	
	int n=0;
	while(1){
		n=0;
		Paquet p;
		
		if(( n = recvfrom(sock, &p, sizeof(p), 0, (struct sockaddr *) &socket_client, &socket_client_size)) < 0) {
			perror("recvfrom()");
			exit(errno);
		}
		if( affichage ){
			std::cout << "Nombre octets recus : " << n << std::endl;
			std::cout << "Paquet recu - typeEvent=" << p.typeEvent << " face=" << p.face << " id=" << p.id << " posX=" << p.posX << " posY=" << p.posY << std::endl;
		}
		
		observateur->traiter(p);
	}
}


