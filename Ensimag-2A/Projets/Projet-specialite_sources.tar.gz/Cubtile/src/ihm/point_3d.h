#ifndef POINT_3D_H
#define POINT_3D_H

class Point3D
{
private:
	int id;
	
public:
	double x, y, z;
	
	Point3D(int id, double x, double y, double z);
	virtual ~Point3D();
	
	int getId();
	
	double norme();
	
	void normaliser();
	void afficher();
	
	static double produitScalaire(Point3D* u, Point3D* v);
	static Point3D* produitVectoriel(Point3D* u, Point3D* v);
	static double dist(Point3D* u, Point3D* v);
};

#endif
