#include "interpreteur.h"

Interpreteur::Interpreteur(WindowScene3D* ws) {
	this->ws= ws;
}

Interpreteur::~Interpreteur() {}
	
	
void Interpreteur::newFinger(int face, int id, double x, double y) {
	//for the moment i take care of only one finger
	if( doigts.size() == 0 )
		doigts.push_back(new Tact(face, id, x, y));
}

void Interpreteur::moveFinger(int face, int id, double x, double y) {
	for( unsigned int i=0 ; i<doigts.size() ; ++i ){
		if( doigts[i]->getFace() == face && doigts[i]->getId() == id ){
			// interpretation
// 			ws->getAngle( doigts[i]->
			
			doigts[i]->moveTo(x, y);
		}
		break;
	}
}
void Interpreteur::removeFinger(int face, int id) {
	for( unsigned int i=0 ; i<doigts.size() ; ++i ){
		if( doigts[i]->getFace() == face && doigts[i]->getId() == id ){
			doigts.erase( doigts.begin() + i );
		}
		break;
	}
}