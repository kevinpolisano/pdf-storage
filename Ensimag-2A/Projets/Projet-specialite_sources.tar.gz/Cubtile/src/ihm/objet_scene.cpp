#include <iostream>
#include <cmath>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif


#ifdef __APPLE__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#else
#include <GL/gl.h>
#endif

#include <QGLViewer/qglviewer.h>

#include "window_scene_3d.h"
#include "objet_scene.h"
#include "point_3d.h"
#include "matrice_4x4.h"



ObjetScene::ObjetScene(
	double echelle,
	bool dock,
	double posX, double posY, double posZ,
	double rotX, double rotY, double rotZ,
	double scaX, double scaY, double scaZ
)
{
	this->echelle = echelle;
	
	this->posX = echelle*posX; this->posY = echelle*posY; this->posZ = echelle*posZ;
	this->rotX = rotX; this->rotY = rotY; this->rotZ = rotZ;
	this->scaX = scaX; this->scaY = scaY; this->scaZ = scaZ;
	
	A = new Point3D(1, posX, posY, posZ);
	B = new Point3D(2, posX, posY+1, posZ);
	C = new Point3D(3, posX, posY, posZ+1);
	alpha = (dock) ? 0.3 : 1;
	
	
	// matrice identité
	matriceCourante = getMatriceIdentite();
	matriceRotation = getMatriceIdentite();
	matriceRotationInverse = getMatriceIdentite();
	matriceCubtile  = getMatriceIdentite();
}

ObjetScene::~ObjetScene() {}


void ObjetScene::draw(qglviewer::Quaternion orientationCamera) {
	std::cout << "----------ObjetScene::draw" << std::endl;

/**

	// le code avec camera
	double* matriceCamera = new double[16];
	double* matriceCameraInverse = new double[16];
	
	
	orientationCamera.getMatrix(matriceCamera);
	normaliser(matriceCamera);
	
	orientationCamera.getInverseMatrix(matriceCameraInverse);
	normaliser(matriceCameraInverse);
	
	
	transposer(matriceCamera);
	transposer(matriceCameraInverse); // remet dans l'ordre humain
	
	
	std::cout << "----------matriceCamera" << std::endl;
	afficher( matriceCamera );
	std::cout << "----------matriceCameraInverse" << std::endl;
	afficher( matriceCameraInverse );
	
	
	double* matriceCubCam = multMatrix(matriceCubtile, matriceCamera);
	normaliser(matriceCubCam);
	
	transposer(matriceCourante); // met ordre humain
	double* matriceObjetCam = multMatrix(matriceCourante, matriceCubCam);
	normaliser(matriceObjetCam);
	
	double* nouvelleMatrice = multMatrix(matriceCameraInverse, matriceObjetCam);
	normaliser(nouvelleMatrice);
	
	transposer(nouvelleMatrice); // met ordre machine
	matriceCourante = nouvelleMatrice;

	
	matriceCubtile = getMatriceIdentite();
	delete[] matriceCamera;
	delete[] matriceCameraInverse;
	delete[] matriceCubCam;
	delete[] matriceObjetCam;
	**/


}

void ObjetScene::tourner(Point3D* ptC, Point3D* ptA, Point3D* ptB) {
// on recupere la matrice du cubtile
	std::cout << "matriceCubtile" << std::endl;
	matriceCubtile = getMatriceRotationPoint( ptC, ptA, ptB );
	afficher( matriceCubtile );
	
//remise en orientation initiale
	double* matriceOrientationInit = multMatrix(matriceCubtile, matriceRotation);
	normaliser(matriceOrientationInit);
	
	
// remise dans le repere par rapport a l'anncienne matrice de rotation inverse
	double* matriceCubtileWorld = multMatrix(matriceRotationInverse, matriceOrientationInit);
	normaliser(matriceCubtileWorld);
	
// application a l'anncienne matrice objet
	transposer(matriceCourante); // met ordre humain
	double* nouvelleMatrice = multMatrix(matriceCourante, matriceCubtileWorld);
	normaliser(nouvelleMatrice);
	
	transposer(nouvelleMatrice); // met ordre machine
	matriceCourante = nouvelleMatrice;
	
// obtention de la matrice inverse de la transfo en cours
	/*double * matriceCubtileInverse = getMatriceInverse(matriceCubtile);
	matriceCubtileInverse[12] = 0;
	matriceCubtileInverse[13] = 0;
	matriceCubtileInverse[14] = 0;
	*/
	
	////// obtention de l'unique rotation de la transfo
	matriceCubtile[3] = 0;
	matriceCubtile[7] = 0;
	matriceCubtile[11]= 0;
	std::cout << "matriceCubtile : uniquement rotation" << std::endl;
	afficher( matriceCubtile );
	
	
	
	///// matrice rotation
	
	double* nouvelleMatriceRotation = multMatrix( matriceRotation, matriceCubtile);
	normaliser(nouvelleMatriceRotation);
	
	matriceRotation = nouvelleMatriceRotation;
	//delete[] nouvelleMatriceRotation;
	std::cout << "matriceRotation APRES" << std::endl;
	afficher( matriceRotation );
	
	
	
	
	///// matrice rotation cubtile inverse
	
	double* matriceCubtileInverse = getMatriceRotationPoint( ptC, ptB, ptA );
	matriceCubtileInverse[3] = 0;
	matriceCubtileInverse[7] = 0;
	matriceCubtileInverse[11] = 0;
	
	std::cout << "matriceCubtileInverse" << std::endl;
	afficher( matriceCubtileInverse );
	
// application a l'ancienne matrice de rotation inverse
/**
	double* nouvelleMatriceRotationInverse = multMatrix( matriceRotationInverse, matriceCubtileInverse);
	normaliser(nouvelleMatriceRotationInverse);
	
	matriceRotationInverse = nouvelleMatriceRotationInverse;
	//delete[] nouvelleMatriceRotationInverse;
	**/
	///**
	matriceRotationInverse = getMatriceInverse(matriceRotation);
	//**/
	
	std::cout << "matriceRotationInverse APRES" << std::endl;
	afficher( matriceRotationInverse );
	
	
	// Application aux 3 points du docking
	//TODO
// 	Point3D* nvA = multMatrix(matriceRotation, A);
// 	Point3D* nvB = multMatrix(matriceRotation, B);
// 	Point3D* nvC = multMatrix(matriceRotation, C);
// 	
// 	A->~Point3D();
// 	B->~Point3D();
// 	C->~Point3D();
// 	
// 	
// 	A = nvA;
// 	B = nvB;
// 	C = nvC;
	
	/**
	// Application à l'ancienne matrice
	transposer(matrice);
	double* nouvelleMatrice = multMatrix(matrice, matriceRotation);
	normaliser(nouvelleMatrice);
	transposer(nouvelleMatrice);
	
	matrice = nouvelleMatrice;
	
	delete[] matriceRotation;
	**/
	
	/*
	std::cout << "PASSE" << std::endl;
	
	double* matriceCamera = new double[16];
	std::cout << "double*" << std::endl;
	glGetDoublev(GL_MODELVIEW_MATRIX, matriceCamera);
	std::cout << "getdouble" << std::endl;
	transposer(matriceCamera);
	
	std::cout << "MATRICE CAMERA = ";
	afficher( matriceCamera );
	*/
	
	/*
	//double* matriceCamera = getMatriceIdentite();
	double* matriceCamera = WindowScene3D::getMatriceCamera();
	
	
	
	
	double* matriceIntermediare = multMatrix(matriceCamera, matriceRotationCubtile);
	normaliser(matriceIntermediare);
	
	std::cout << "MATRICE INTERM = ";
	afficher( matriceIntermediare );
	
	
	
	transposer(matrice);
	double* nouvelleMatrice = multMatrix(matrice, matriceIntermediare);
	normaliser(nouvelleMatrice);
	
	std::cout << "MATRICE NOUVEL = ";
	afficher( nouvelleMatrice );
	
	
	std::cout << "---------------------------------------------------" << std::endl;
	
	transposer(nouvelleMatrice);
	matrice = nouvelleMatrice;
	
	delete[] matriceRotationCubtile;
	delete[] matriceCamera;
	delete[] matriceIntermediare;
	
	*/
	
	
}

/* Les points C, D, A définissent le triangle, et le point A
 * se déplace en B 
 */
void ObjetScene::scale(Point3D* ptC, Point3D* ptD, Point3D* ptA, Point3D* ptB) {
	
	double cd = Point3D::dist(ptC,ptD);
	double ac = Point3D::dist(ptC,ptA);
	double ad = Point3D::dist(ptA,ptD);
	
	double p1 = ( cd+ac+ad ) / 2;
	double aireACD = sqrt(p1*(p1-cd)*(p1-ac)*(p1-ad)); // Héron
	
	double bc = Point3D::dist(ptC,ptB);
	double bd = Point3D::dist(ptB,ptD);
	
	
	double p2 = ( cd+bc+bd ) / 2;
	double aireBCD = sqrt(p2*(p2-cd)*(p2-bc)*(p2-bd)); // Héron
	
	
	double tau = aireBCD/aireACD;
		tau = sqrt(tau);
	
	
	double* matriceScale = getMatriceScale(tau,tau,tau);
	normaliser(matriceScale);
	
	
	// Application aux 3 points du docking
	Point3D* nvA = multMatrix(matriceScale, A);
	Point3D* nvB = multMatrix(matriceScale, B);
	Point3D* nvC = multMatrix(matriceScale, C);
	
	A = nvA;
	B = nvB;
	C = nvC;
	
	
	transposer(matriceCourante);
	double* nouvelleMatrice = multMatrix(matriceCourante, matriceScale);
	normaliser(nouvelleMatrice);
	transposer(nouvelleMatrice);
	
	matriceCourante = nouvelleMatrice;
	
	delete[] matriceScale;
}




bool ObjetScene::docked(ObjetScene* objU, ObjetScene* objV) {
	double distA = Point3D::dist( objU->A, objV->A );
	double distB = Point3D::dist( objU->B, objV->B );
	double distC = Point3D::dist( objU->C, objV->C );
	
	
	//TODO for the moment
	double distMatching=0.2;
	if( distA < distMatching && distB < distMatching && distC < distMatching ) {
		return true;
	}
	return false;
}
