#ifndef OBSERVATEUR_H
#define OBSERVATEUR_H

#include "serveur.h"


class Observateur
{
public:
	Observateur();
	virtual ~Observateur();
	
	virtual void traiter(Paquet p);
};


#endif