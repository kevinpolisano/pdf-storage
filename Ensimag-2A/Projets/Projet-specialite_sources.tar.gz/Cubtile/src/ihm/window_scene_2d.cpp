#include "window_scene_2d.h"

#include "serveur.h"


WindowScene2D::WindowScene2D(const unsigned int largeurScene) {
	scenes = new Scene2D*[5];
	scenes[FACEH] = new Scene2D(this, largeurScene, "red");
	scenes[FACEG] = new Scene2D(this, largeurScene, "orange");
	scenes[FACEM] = new Scene2D(this, largeurScene, "yellow");
	scenes[FACED] = new Scene2D(this, largeurScene, "green");
	scenes[FACEB] = new Scene2D(this, largeurScene, "blue");
	
	scenes[FACEH]->show();
	scenes[FACEG]->show();
	scenes[FACEM]->show();
	scenes[FACED]->show();
	scenes[FACEB]->show();
	
	scenes[FACEH]->view->move (   largeurScene+15,                 5 );
	scenes[FACEG]->view->move (                 5,   largeurScene+15 );
	scenes[FACEM]->view->move (   largeurScene+15,   largeurScene+15 );
	scenes[FACED]->view->move ( 2*largeurScene+25,   largeurScene+15 );
	scenes[FACEB]->view->move (   largeurScene+15, 2*largeurScene+25 );
	
	setFixedSize( 3*largeurScene+35, 3*largeurScene+35);
	show();
}

WindowScene2D::~WindowScene2D() {}

Scene2D** WindowScene2D::getScenes() {
	return scenes;
}


