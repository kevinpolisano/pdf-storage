/**
* @file main.cpp
* @brief Le programme principal
*/

#include <iostream>
#include <ctime>
#include <pthread.h>


#include <QApplication>

#include "serveur.h"
#include "observateur.h"
#include "observateur_2d.h"
#include "observateur_3d.h"

int main(int argc, char * argv[]){
	QApplication app(argc, argv);
	
// 	Observateur2D* obs = new Observateur2D();
	Observateur3D* obs = new Observateur3D();
	
	////////////////////////////
	pthread_t thread;
	pthread_create(&thread, NULL, serveur, (void*) obs);
	////////////////////////////
	
	
	return app.exec();
}


