#include <cmath>
#include <iostream>

#include "point_3d.h"


Point3D::Point3D(int id, double x, double y, double z) {
	this->id = id;
	this->x = x;
	this->y = y;
	this->z = z;
}

Point3D::~Point3D() {}
	
int Point3D::getId() {
	return id;
}

void Point3D::afficher() {
	std::cout << " id=" << id << " ( " << x << ", " << y << ", " << z << " )" << std::endl;
}

double Point3D::norme() {
	return sqrt( x*x +y*y + z*z );
}

void Point3D::normaliser() {
	double norme = this->norme();
	x /= norme;
	y /= norme;
	z /= norme;
}

double Point3D::produitScalaire(Point3D* u, Point3D* v) {
	return (u->x * v->x) + (u->y * v->y) + (u->z * v->z) ;
}

Point3D* Point3D::produitVectoriel(Point3D* u, Point3D* v) {
	return new Point3D
	(
		-1,
		u->y*v->z - u->z*v->y,
		u->z*v->x - u->x*v->z,
		u->x*v->y - u->y*v->x
	);
}

double Point3D::dist(Point3D* u, Point3D* v) {

	return sqrt((u->x-v->x)*(u->x-v->x)+(u->y-v->y)*(u->y-v->y)+(u->z-v->z)*(u->z-v->z));

}
