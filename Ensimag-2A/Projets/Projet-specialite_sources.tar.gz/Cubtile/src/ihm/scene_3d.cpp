#include "scene_3d.h"
#include "cube.h"
#include "objet_scene.h"

#include <QGLViewer/qglviewer.h>


Scene3D::Scene3D(double echelle) {
	this->echelle = echelle;
	
	cube = new Cube( 50, 0.10, false );
	dock = new Cube( 50, 0.32, true, 0.5, 0.4, 0 ); 
	
	
	//TODO placer les objet aleatoirement
}

Scene3D::~Scene3D() {}

void Scene3D::draw(qglviewer::Quaternion orientationCamera) {
	cube->draw(orientationCamera);
	dock->draw(orientationCamera);
}


bool Scene3D::docking() {
	if( ObjetScene::docked( cube, dock ) ){
		return true;
	}
	return false;
}


