#ifndef OBSERVATEUR_2D_H
#define OBSERVATEUR_2D_H

#include "serveur.h"

#include "observateur.h"
#include "window_scene_2d.h"
#include "scene_2d.h"


class Observateur2D : public Observateur
{
private:
	static const unsigned int largeurScene=200;
	
	WindowScene2D* fenetre_principale;
	Scene2D** scenes;

public:
	Observateur2D();
	virtual ~Observateur2D();
	
	void traiter(Paquet p);
};


#endif
