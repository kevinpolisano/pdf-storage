#ifndef WINDOW_SCENE_2D_H
#define WINDOW_SCENE_2D_H

#include <QWidget>

#include "scene_2d.h"


class WindowScene2D : public QWidget
{
private:
	Scene2D** scenes;
public:
	WindowScene2D(const unsigned int largeurScene);
	virtual ~WindowScene2D();
	
	Scene2D** getScenes();
};

#endif
