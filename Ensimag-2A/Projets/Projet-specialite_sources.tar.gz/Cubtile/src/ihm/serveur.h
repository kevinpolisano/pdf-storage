#ifndef SERVEUR_H
#define SERVEUR_H

enum ID_FACE{
	FACEH,
	FACEB,
	FACEM,
	FACED,
	FACEG
};

typedef struct _paquet
{
	char typeEvent;
	ID_FACE face;
	int id;
	double posX;
	double posY;
} Paquet;

void* serveur(void* data);

#endif
