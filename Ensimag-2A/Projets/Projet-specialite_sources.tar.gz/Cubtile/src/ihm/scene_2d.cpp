#include <QGraphicsScene>
#include <QGraphicsView>
#include <QWidget>

#include <iostream>

#include "scene_2d.h"
#include "finger.h"


Scene2D::Scene2D(QWidget* parent,
			 const unsigned int largeur, 
			 const char* color ) : QGraphicsScene()
{
	view = new QGraphicsView(this, parent);
	view->setFixedSize(largeur+5, largeur+5);
	view->setStyleSheet(QString("background-color: ").append(color));
	
	this->largeur = largeur;
	
	QLineF* abscisses1 = new QLineF(0, 0, largeur, 0);
	QLineF* ordonnees1 = new QLineF(0, 0, 0, largeur);
	QLineF* abscisses2 = new QLineF(0, largeur, largeur, largeur);
	QLineF* ordonnees2 = new QLineF(largeur, 0, largeur, largeur);
	addLine(*abscisses1);
	addLine(*ordonnees1);
	addLine(*abscisses2);
	addLine(*ordonnees2);
}

Scene2D::~Scene2D() {}

void Scene2D::show(){
	view->show();
}

void Scene2D::newFinger(int id, double x, double y) {
	if( x>largeur || y>largeur ){
		return;
	}
	else {
		Finger* f = new Finger(id);
		
		QRectF* cercle = new QRectF( x, y, 10, 10 );
		f->setItem(addEllipse(*cercle));
		fingers.push_back(f);
		
		std::cout << "x=" << x << " y=" << y << std::endl;
	}
}

void Scene2D::moveFinger(int id, double x, double y) {
	if( x>largeur || y>largeur ){
		return;
	}
	else {
		for( unsigned int i=0 ; i<fingers.size() ; ++i ){
			if( fingers[i]->getId() == id ){
				fingers[i]->moveTo( x, y );
				break;
			}
		}
		std::cout << "x=" << x << " y=" << y << std::endl;
	}
}

void Scene2D::removeFinger(int id) {
	for( unsigned int i=0 ; i<fingers.size() ; ++i ){
		if( fingers[i]->getId() == id ){
			removeItem(fingers[i]->getItem());
			fingers.erase(fingers.begin() + i);
			break;
		}
	}
}

void Scene2D::afficheFinger() {
	if( !fingers.empty() ){
		std::cout << "id des fingers : ";
		for( unsigned int i=0 ; i<fingers.size() ; ++i ){
			std::cout << fingers[i]->getId() << " ";
		}
		std::cout << std::endl;
	}
}

void Scene2D::refresh() {
	update();
	view->update();
}


