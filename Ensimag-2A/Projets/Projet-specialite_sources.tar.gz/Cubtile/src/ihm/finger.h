#ifndef FINGER_H
#define FINGER_H

#include <QGraphicsEllipseItem>

class Finger
{
protected:
	QGraphicsEllipseItem* item;
	int id;
	
public:
	Finger(int id);
	virtual ~Finger();
	
	int getId();
	QGraphicsEllipseItem* getItem();
	void setItem(QGraphicsEllipseItem* item);
	void moveTo(double x, double y);
	bool estProche(double x, double y);
	
};

#endif