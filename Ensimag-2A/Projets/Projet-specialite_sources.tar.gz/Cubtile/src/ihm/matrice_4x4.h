#ifndef MATRICE_4x4_H
#define MATRICE_4x4_H

#include "point_3d.h"

void afficher(double* matrice);

void normaliser(double* &matrice);
void transposer(double* &matrice);

double* getMatriceNulle();
double* getMatriceIdentite();
double* getMatriceTranslation(double tx, double ty, double tz);

double* getMatriceRotationPoint( Point3D* ptC, Point3D* ptA, Point3D* ptB );
double* getMatriceRotationSimple(double angle, double rotX, double rotY, double rotZ);
double* getMatriceRotationComplexe(
	double angle, double nx, double ny, double nz,
	double a, double b, double c );
double* getMatriceScale(double kx, double ky, double kz);

double* getMatriceInverse(double* matA);

Point3D* multMatrix(double* matA, Point3D* ptB);
double* multMatrix(double* matA, double* matB);


#endif
