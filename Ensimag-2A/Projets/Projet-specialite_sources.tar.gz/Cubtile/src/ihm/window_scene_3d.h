#ifndef WINDOW_SCENE_3D_H
#define WINDOW_SCENE_3D_H

#include <QKeyEvent>
#include <QGLViewer/qglviewer.h>
//#include <homebrew/Cellar/libqglviewer/2.3.16/QGLViewer.framework/Version/2/Headers/qglviewer.h>

#include "scene_3d.h"


class WindowScene3D : public QGLViewer
{
private :
	double echelle;
	
	bool modeFilaire;
	
	void init();
	void draw();
	void animate();
	
	void keyPressEvent(QKeyEvent *e);
	QString helpString() const;

	WindowScene3D();
	
	double* matriceCamera;
	
public:
	Scene3D* scene;
	
	WindowScene3D(double echelle);
	virtual ~WindowScene3D();
	
	void tourner(Point3D* ptFixe, Point3D* ptA, Point3D* ptB);
};


#endif

