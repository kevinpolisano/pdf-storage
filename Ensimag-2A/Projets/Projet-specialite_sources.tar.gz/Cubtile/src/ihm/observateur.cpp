#include "observateur.h"


Observateur::Observateur() {}
Observateur::~Observateur() {}
	
void Observateur::traiter(Paquet p) {}