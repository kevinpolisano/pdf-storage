#include <QGraphicsEllipseItem>
#include <cmath>

#include "finger.h"

Finger::Finger(int id) {
	this->id = id;
}

Finger::~Finger() {}

int Finger::getId() {
	return id;
}

QGraphicsEllipseItem* Finger::getItem() {
	return item;
}

void Finger::setItem(QGraphicsEllipseItem* item) {
	this->item = item;
}

void Finger::moveTo(double x, double y) {
	QRectF r = item->rect();
	r.moveTo(x, y);
	item->setRect(r);
}

bool Finger::estProche(double x, double y){
	qreal x1=0, y1=0, x2=0, y2=0;
	getItem()->rect().getCoords(&x1, &y1, &x2, &y2);
	double distance = sqrt( (x1-x)*(x1-x) + (y1-y)*(y1-y) );
	
	if( distance<50 ){
		return true;
	}
	return false;
}