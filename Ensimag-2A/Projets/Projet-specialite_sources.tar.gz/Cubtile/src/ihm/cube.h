#ifndef CUBE_H
#define CUBE_H


#include <QGLViewer/qglviewer.h>
#include "objet_scene.h"
#include "point_3d.h"

class Cube : public ObjetScene
{
private:
	double i;
public:
	
	Cube(
		double echelle,
		double longueurCote,
		bool dock,
		double posX=0, double posY=0, double posZ=0,
		double rotX=0, double rotY=0, double rotZ=0,
		double scaX=1, double scaY=1, double scaZ=1 );
	virtual ~Cube();
	
	void draw(qglviewer::Quaternion orientationCamera);
};

#endif
