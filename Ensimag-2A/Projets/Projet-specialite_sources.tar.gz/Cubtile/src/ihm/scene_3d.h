#ifndef SCENE_3D_H
#define SCENE_3D_H


#include <QGLViewer/qglviewer.h>

#include "objet_scene.h"
#include "cube.h"



class Scene3D
{
private:
	double echelle;
	
public:
	Cube* cube;
	Cube* dock;
	
	Scene3D(double echelle);
	virtual ~Scene3D();
	
	void draw(qglviewer::Quaternion);
	
	bool docking();
	
	
	
	
	QGLViewer* parent;
};

#endif