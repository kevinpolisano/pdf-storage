
Ensimag,

Projet de spécialitée image : "Precision Sub-Pixel avec le Cubtile"

Année 2012


Victor Sabatier
Kevin Polisano
Kevin Boury
Téo Mazars

BIBLIOTHEQUES REQUISES :

Glut, OpenCV, qglviewer, libdc1394, R (optionnel)

Installation de la libcubtile :

dans src/cubtile :
make

Installation de l'ihm :
Ajoutez le répertoire lib à la variable d'environnement LD_LIBRARY_PATH
dans src/ihm :
make


Installation du clientserveur
Ajoutez le répertoire lib à la variable d'environnement LD_LIBRARY_PATH
dans src/clientserveur
make


Execution :

0) Connectez le cubtile à la machine
1) Lancer l'ihm (src/ihm/viewer)
2) Lancer le traitement du cubtile : (src/clientserveur/main2)
3) Jouez !


