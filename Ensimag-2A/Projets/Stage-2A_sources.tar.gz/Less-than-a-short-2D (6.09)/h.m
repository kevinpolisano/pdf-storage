function res = h(s)
global RROI Q;
h = RROI/Q;
c = 200/(2*h);
regulariser = 1;
if regulariser
    res = 2.*sinc(s.*c).^2.*c.^2.*pi.*s;
else
    res = 1/(pi*s);
end
end



