function res = n(phi)
res = [-sin(phi) cos(phi)];
end

