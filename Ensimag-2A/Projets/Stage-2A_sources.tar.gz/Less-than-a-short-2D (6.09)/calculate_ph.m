%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fill the array PH by calculating all pH(n(phi_k),sl)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function calculate_ph
global params ph M Q;

if params.phpcalc == 1
    for k=1:M
        k
        for l=-Q+1:Q -1
                ph(k,l+Q+1) = pH(k,l);
        end
    end
end

% we save the ph matrix (to avoid to calculate it each time)
save donnees
end

