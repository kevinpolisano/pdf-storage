function drawpH(k,l)
global params;
if params.seepH == 1
    pH(k,l);
end
end

