
function Lout = transformation(I,u,v,L)
for i=1:size(L,2)
    Lout(:,i) = transf(I,u,v,L(:,i));
end;
end


