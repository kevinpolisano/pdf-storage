function mode(choix)
global params;
switch choix,
    % No plot
    case 0,
       Traj = 0;
       Img = 0;
       ROI = 0;
       ROIINT = 0;
       phpcalc = 1;
       seeLineKL = 0;
       seeBeam = 0;
       seepH = 0;
       displayG = 0;
    % Draw the vertex path, the image, ROI and a beam g(lambda,alpha)
    case 1,
       Traj = 1;
       Img = 1;
       ROI = 1;
       ROIINT = 0;
       phpcalc = 0;
       seeLineKL = 0;
       seeBeam = 1;
       seepH = 0;
       displayG = 1;
    % Draw vertex path, the image and the ROI
    case 2,
       Traj = 1;
       Img = 1;
       ROI = 1;
       ROIINT = 0;
       phpcalc = 0;
       seeLineKL = 0;
       seeBeam = 0;
       seepH = 0;
       noplot = 0;
       displayG = 0;
    % Draw vertex path, the image and the ROI interior
    case 3,
       Traj = 1;
       Img = 1;
       ROI = 1;
       ROIINT = 1;
       phpcalc = 0;
       seeLineKL = 0;
       seeBeam = 0;
       seepH = 0;
       displayG = 0;
    % Draw vertex path, the image and n(phik(k))
    case 4,
       Traj = 1;
       Img = 1;
       ROI = 1;
       ROIINT = 0;
       phpcalc = 0;
       seeLineKL = 1;
       seeBeam = 0;
       seepH = 0;
       displayG = 1;
    % Draw vertex path, the image, the ROI and pH
    case 5,
       Traj = 1;
       Img = 1;
       ROI = 1;
       ROIINT = 0;
       phpcalc = 0;
       seeLineKL = 0;
       seeBeam = 0;
       seepH = 1;
       displayG = 1;
    % Draw vertex path, the image, the ROI and all beams
    case 6,
       Traj = 1;
       Img = 1;
       ROI = 0;
       ROIINT = 0;
       phpcalc = 1;
       seeLineKL = 0;
       seeBeam = 0;
       seepH = 0;
       displayG = 1;
    otherwise,
        error('numéro du mode inconnu');
end;
params = struct('Traj', Traj,'Img',Img,'ROI',ROI,'ROIINT',ROIINT,'phpcalc',phpcalc,'seeLineKL',seeLineKL,'seeBeam',seeBeam,'seepH',seepH,'displayG',displayG);
end

