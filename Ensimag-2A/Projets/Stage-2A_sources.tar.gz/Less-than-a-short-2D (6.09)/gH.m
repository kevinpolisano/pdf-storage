%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate gH(lambda_ind,n(alpha_k)) resulting of a convolution
% between g and the Hilbert filter H
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function res = gH(ind,k)
global angles lambda G params pas H;
long = length(angles);
somme = 0;
for i=1:long
    if params.displayG == 1
        var = G(ind,i); %g(lambda(ind),alph);
    else
        var = G(ind,i);
    end
    somme = somme + H(long+k-i)*var;
end
res = somme*pas;
end