%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Give one fanbeam projection from the vertex a(lambda) 
% oriented by the vector alpha by calculating the line integral 
% in this direction across the Shepp-Logan image
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function res = g(lambda,alpha)
global I u v width height P params RROI;

S = a(lambda); % the vertex point (source's position)
n = 256;       % discretization of the line integral

% Intersection of the beam with image borders
[A,B] = intersec_beam_image(S,alpha);
if (dist(S,A)>dist(S,B))
    C = A;
    A = B;
    B = C;
end

% Discretization of the line integral
L = discretiser(A,B,alpha,n);

% Keep only points in the FOV
LROI = selectROI(L);
if (LROI == -1) % if the beam doesn't cross the FOV
    res = 0;
    return;
end;

if params.displayG == 1
    %plot(L(1,:),L(2,:),'r:o');
    plot(LROI(1,:),LROI(2,:),'g:o');
end

% The line integral seen in the image's referential
LROIout = transformation(I,u,v,LROI);
Lout = transformation(I,u,v,L);

if params.seeBeam == 1
    figure;
    plot(Lout(1,:),Lout(2,:),'r:o');
    axis([0 128 0 128]);
end;

%Limage = pixeliser(Lout);
LROIimage = pixeliser(LROIout);

% We evaluate the line integral
vAB = B-A;
longueur = norm(vAB);
pas = longueur/(n-1);
integrale = 0;
for i=1:length(LROIimage)-1
        integrale = integrale + P(LROIimage(1,i),LROIimage(2,i));
end;
res = integrale*pas;
%plot(Limage(1,:),Limage(2,:),'g:o');
end

