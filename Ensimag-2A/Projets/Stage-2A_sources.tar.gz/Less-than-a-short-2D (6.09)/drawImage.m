function drawImage
global params xbox ybox;
if params.Img == 1
    plot(xbox,ybox);   
    axis([-300 300 -300 300],'equal');
end
end

