function res = alpha(lambda,gamma)
res = cos(gamma)*e1(lambda)+sin(gamma)*e2(lambda);
end

