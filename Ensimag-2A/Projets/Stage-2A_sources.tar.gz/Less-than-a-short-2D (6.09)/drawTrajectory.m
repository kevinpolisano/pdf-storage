function drawTrajectory
global params;
global A;
if params.Traj == 1
    plot(A(1,:),A(2,:),'r:o');
end
end

