function res = e2(lambda) % correspond à ni
res = [-sin(lambda) cos(lambda)];
end

