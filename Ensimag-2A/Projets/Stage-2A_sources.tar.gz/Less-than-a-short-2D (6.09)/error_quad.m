function res = error_quad(T1,T2)
s = 0;
l1 = size(T1,1);
l2 = size(T1,2);
for i=1:l1
    for j=1:l2
        s = s + (T1(i,j)-T2(i,j))^2;
    end
end
res = sqrt(s);      
end
