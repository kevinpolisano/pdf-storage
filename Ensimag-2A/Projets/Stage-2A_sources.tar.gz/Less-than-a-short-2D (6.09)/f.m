function res = f(x)
global RROI Q M php PHIK SL;

%php
somme = 0;
const = RROI/Q;
for k=1:M
    
    % we locate where x.n(phik) is between sl and sl+1
    y = dot(x,n(PHIK(k)));
    l = -Q;
    while abs(SL(l+Q+1)-y)-const+0.0000001 >= 0
        l = l+1;
    end
    
    % we interpolate pH'(n(phik),x.n(phik))
    pHpInterpol = ((y-SL(l+Q+1))*php(k,l+1+Q)+(SL(l+Q+2)-y)*php(k,l+Q));
    somme = somme + pHpInterpol;
end
res = somme/(2*M*const);
end

% x = sl(-9)*n(phik(7)),  x.n(phik(7))