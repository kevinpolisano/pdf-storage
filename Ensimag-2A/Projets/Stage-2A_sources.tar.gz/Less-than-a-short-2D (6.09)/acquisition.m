%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% First main function of the program : CT imaging
% Input : data defined in init_data.m (modified manually by user)
% Output : Structures G and GH filled (Sinogram and its filtre)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function acquisition
global G GH;

% Initialization of data
init_data;

% Fill the sinogram (projection step)
mode(0);
fillSinogram;

% Display the sinogram
figure;
Sino = mat2gray(G);
imshow(Sino);

% Apply Hilbert filter to the sinogram
fillHilbert;

% Display the filtred sinogram
figure;
Hilb = mat2gray(GH);
imshow(Hilb);

save donnees

end

