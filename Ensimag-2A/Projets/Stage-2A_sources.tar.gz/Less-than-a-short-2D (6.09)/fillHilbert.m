%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fill the array GH by calculating all gH(lambda_i,n(alpha_j))
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function fillHilbert
global GH lambda angles;

for i=1:length(lambda)
    i
    for j=1:length(angles)  
        GH(i,j) = gH(i,j);
    end
end

end

