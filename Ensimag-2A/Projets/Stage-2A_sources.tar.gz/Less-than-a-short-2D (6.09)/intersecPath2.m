function  [P5,P6,P5in,P6in,l5,l6] = intersecPath2(k,l)
global Rtraj SL PHIK Q;
c = asin(SL(l+Q+1)/Rtraj);
l5 = PHIK(k)+c;
l6 = PHIK(k)+sign(c)*pi-c;
if l5 < 0
    l5 = l5 + 2*pi;
end;
if l6 < 0
    l6 = l6 + 2*pi;
end;
P5 = a(l5);
P6 = a(l6);
P5in = isPath(l5);
P6in = isPath(l6);
end

