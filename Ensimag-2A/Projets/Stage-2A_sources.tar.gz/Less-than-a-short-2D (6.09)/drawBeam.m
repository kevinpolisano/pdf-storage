function drawBeam(lamb,alph)
global params;
if params.seeBeam == 1
    g(lamb,alph); 
end
end

