function [ind2,lt] = findOtherVertex(k,l,ind)
global lambda Rtraj;
P2 = sl(l)*n(phik(k));
S = a(lambda(ind));
[xl,yl] = intersecPath(P2,n(phik(k)),S);
lt = acos(xl/Rtraj);
d1 = dist(a(lambda(ind-1)),a(lt));
d2 = dist(a(lambda(ind+1)),a(lt));
if d1 < d2
   ind2 = ind-1;
else
   ind2 = ind+1;
end;
end

