function bool = isPath(l)
global lambda;
if (l<lambda(1)) | (l>lambda(length(lambda)))
    bool = 0;
else
    bool = 1;
end;
end

