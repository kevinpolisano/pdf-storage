function [P1,P2,P1in,P2in,l1,l2] = intersecPath(A,n)
global Rtraj;
a = n(1)
b = n(2)
if (abs(b) > 1e-8)
c = -n(1)*A(1)-n(2)*A(2);
aa = -a/b;
bb = -c/b;
dd = (2*aa*bb)^2-4*(1+aa^2)*(bb^2-Rtraj^2);
x1 = (-2*aa*bb-sqrt(dd))/(2*(1+aa^2));
x2 = (-2*aa*bb+sqrt(dd))/(2*(1+aa^2));
P1(1) = x1;
P1(2) = aa*x1+bb;
P2(1) = x2;
P2(2) = aa*x2+bb;
else
    disp 'vertical intersection';
    P1(1) = A(1);
P1(2) = -sqrt(Rtraj^2-A(1)^2);
P2(1) = A(1);;
P2(2) = sqrt(Rtraj^2-A(1)^2);
end;
l1 = acos(P1(1)/Rtraj);
if (P1(2)<0)
    l1 = 2*pi-l1;
end;
l2 = acos(P2(1)/Rtraj);
if (P2(2)<0)
    l2 = 2*pi-l2;
end;
P1in = isPath(l1);
P2in = isPath(l2);
% d1 = dist(S,P1);
% d2 = dist(S,P2);
% if d1 < d2
%     x = x1;
% else
%     x = x2;
% end;
% y = aa*x+bb;
end

