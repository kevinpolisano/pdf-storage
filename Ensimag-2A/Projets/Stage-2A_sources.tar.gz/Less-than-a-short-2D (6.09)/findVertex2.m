function i = findVertex2(lt)
global lambda;
k = 1;
lk = lambda(k);
while (lt > lk)
    k = k+1;
    lk = lambda(k);
end;
if k>1
i = k-1;
else
i = 1;
end;
end


