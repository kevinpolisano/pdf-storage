%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fill the array G by calculating all g(lambda_i,alpha_j)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function fillSinogram
global lambda angles G;
for i=1:length(lambda)
    i
    lamb = lambda(i);
    for j=1:length(angles)
        alph = angles(j);
        G(i,j) = g(lamb,alpha(lamb,alph));
    end
end
end

