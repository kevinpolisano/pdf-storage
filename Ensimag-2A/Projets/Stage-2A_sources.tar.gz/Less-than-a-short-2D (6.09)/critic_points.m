function L = critic_points(Ferr,tol,c)
l = 1;
for k=1:length(Ferr)
    if (Ferr(k) >= tol)
        i = floor(k/c) + 1;
        j = mod(k,c);
        if (j == 0)
            j = c;
        end
        L(1,l) = i;
        L(2,l) = j;
        l = l+1;
    end
end;
end

