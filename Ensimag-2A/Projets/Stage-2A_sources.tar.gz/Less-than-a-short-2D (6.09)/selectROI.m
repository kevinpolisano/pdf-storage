function Lout = selectROI(L)
global RROI;
k = 1;
for i=1:length(L)
    P = L(:,i);
    if (sqrt(P(1)^2+P(2)^2) < RROI-1)
        Lout(:,k) = P;
        k = k+1;
    end
end;
if (k == 1)
    Lout = -1;
end
end

