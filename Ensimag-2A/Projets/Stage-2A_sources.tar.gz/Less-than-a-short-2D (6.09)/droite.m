function [X,Y] = droite(A,B)
X = -300:1:300;
a = (B(2)-A(2))/(B(1)-A(1));
b = B(2)-a*B(1);
Y = a*X+b;
end

