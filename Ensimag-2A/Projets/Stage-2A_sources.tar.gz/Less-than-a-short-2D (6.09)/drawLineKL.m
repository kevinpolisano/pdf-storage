function drawLineKL(k,l)
global params lambda angles;
if params.seeLineKL == 1
    P1(1)=0;
    P1(2)=0;
    P2 = sl(l)*n(phik(k));
    [X1 Y1] = droite(P1,P2);
    %plot(X1,Y1,'b');

    [X2 Y2] = droite2(P2,n(phik(k)));
    plot(X2,Y2,'k');

    plot(P1(1),P1(2),'m:*');
    plot(P2(1),P2(2),'k:*');
    
%     ind = findVertex(k,l);
%     [X3 Y3] = droite(a(lambda(ind)),P2);
%     plot(X3,Y3,'g');
%     S = a(lambda(ind));
%     plot(S(1),S(2),'g:*');
    
    [P3 P4 P3in P4in l1 l2] = intersecPath(P2,n(phik(k)))
       [P5 P6 P5in P6in l5 l6] = intersecPath2(k,l)

     axis([-500 500 -500 500],'equal');
  
    if P3in
        plot(P3(1),P3(2),'b:*');
    else
        plot(P3(1),P3(2),'y:*');
    end
    if P4in
        plot(P4(1),P4(2),'b:*');
    else
        plot(P4(1),P4(2),'y:*');
    end
%     xl = P3(1);
%     lt = acos(xl/Rtraj);
%     d1 = dist(a(lambda(ind-1)),a(lt));
%     d2 = dist(a(lambda(ind+1)),a(lt));
%     if d1 < d2
%         ind2 = ind-1;
%     else
%         ind2 = ind+1;
%     end;
%     lt 
%     ind2
%     S2 = a(lambda(ind2));
%      plot(S2(1),S2(2),'r:*');
     
%     l1 = acos(P3(1)/Rtraj);
%     if (P3(2)<0)
%         l1 = 2*pi-l1;
%     end;
%     l1

if P3in
    lt = l1;
else
    lt = l2;
end;

    alp = alphat(P2,lt);
%    g(lt,alpha(lt,alp));
    j = findAngle(alp);
    i = findVertex2(lt);
    li = lambda(i);   
    lisuiv = lambda(i+1);
    
    Li = a(li);
    Lisuiv =a(lisuiv);
   
    
    alphj = angles(j);
    alphjsuiv = angles(j+1); % en réalité +1 mais pour voir..
    
     axis([-500 500 -500 500],'equal');
    g(lt,alpha(lt,alp));
  
    g(li,alpha(li,alphj));
    
    g(li,alpha(li,alphjsuiv));
   
    g(lisuiv,alpha(lisuiv,alphj));
    g(lisuiv,alpha(lisuiv,alphjsuiv));
    
     plot(Li(1),Li(2),'g:*');
    plot(Lisuiv(1),Lisuiv(2),'g:*');
    
    n(phik(k))
   
end
end

