function Lout = pixeliser(L)
for i=1:size(L,2)
    Lout(1,i) = floor(L(1,i));
    if Lout(1,i) <= 0
        Lout(1,i) = 1;
    end
    if Lout(1,i) >= 129
        Lout(1,i) = 128;
    end
    Lout(2,i) = floor(L(2,i));
    if Lout(2,i) <= 0
        Lout(2,i) = 1;
    end
    if Lout(2,i) >= 129
        Lout(2,i) = 128;
    end
end;
end

