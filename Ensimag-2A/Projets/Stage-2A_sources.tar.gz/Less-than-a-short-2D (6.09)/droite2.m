function [X,Y] = droite2(A,n)
X = -300:1:300;
a = n(1);
b = n(2);
c = -n(1)*A(1)-n(2)*A(2);
Y = -(a*X+c)/b;
end

