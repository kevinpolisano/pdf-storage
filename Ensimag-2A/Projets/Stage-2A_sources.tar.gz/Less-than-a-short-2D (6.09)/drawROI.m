function drawROI
global params RROI M Q;
if params.ROI == 1
    circle(0,0,RROI);
end

if params.ROIINT == 1
    for k=1:M
        for l=-Q+1:Q-1        
            Pkl = sl(l)*n(phik(k))
            plot(Pkl(1),Pkl(2),'g:o');
        end
    end
end
end

