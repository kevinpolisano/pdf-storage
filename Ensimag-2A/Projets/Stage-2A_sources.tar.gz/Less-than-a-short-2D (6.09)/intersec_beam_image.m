% I : upper left coin of the image in the absolute referential
% u,v : vectors which define the image's orientations
% height, width : image's dimensions
% S : source point of the beam
% alpha : vector director of the beam
% Return intersections between the beam and the image
function [A,B] = intersec_beam_image(S,alpha)
global params xbox ybox;

% The beam
D = S + alpha*1000; % position of the detector
xb = [S(1) D(1)];
yb = [S(2) D(2)];
hold on;
if params.displayG == 1
    plot(S(1),S(2),'r:*');
    plot(xb,yb,'red');
end
%mapshow(xb,yb,'Marker','+')

% Intersection of the rectangle C1C2C3C4 with the beam (SD)
[xi, yi] = intersections(xb, yb, xbox, ybox);
%if params.displayG == 1
%    plot(xi,yi,'m:o');
%end;
A(1) = xi(1);
A(2) =yi(1);
B(1) = xi(2);
B(2) = yi(2);
%mapshow(xi,yi,'DisplayType','point','Marker','o')
end

