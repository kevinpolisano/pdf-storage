%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Second main function : Rebinning fanbeam geometry to parallel
% Input : G and GH stored in file donnees.mat
% Output : PH and PHP filled (in default mode 0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function fanbeam;
global lambda gammam;

load donnees;

% PLOTTING MODE
% choix 0 : Evaluate php without any plot
% choix 1 : Draw the vertex path, the image, FOV and a beam g(lambda,alpha)
% choix 2 : Draw vertex path, the image and the FOV
% choix 3 : Draw vertex path, the image and the FOV interior
% choix 4 : Draw vertex path, the image and n(phik(k))
% choix 5 : Draw vertex path, the image, the FOV and pH
% choix 6 : Draw vertex path, the image, the FOV and all beams

choix = 0;
mode(choix);

drawImage;

hold on
drawTrajectory;

drawROI;

k = 10;
l = -50;
drawLineKL(k,l);
%pH(k,l)

%lamb = lambda(1);
%alph = alpha(lamb,gammam-0.1);
%drawBeam(lamb,alph);

drawpH(k,l);

% we estimate pH(n(phi_k),sl) for all (k,l)
calculate_ph;

% we estimate pH'(n(phi_k),sl) for all (k,l)
calculate_php;

end

