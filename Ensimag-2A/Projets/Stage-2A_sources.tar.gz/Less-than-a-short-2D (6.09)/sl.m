function res = sl(l)
global RROI Q;
res = l*RROI/Q;
end

