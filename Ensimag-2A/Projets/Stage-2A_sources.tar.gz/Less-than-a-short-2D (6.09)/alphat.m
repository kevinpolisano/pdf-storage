function alph = alphat(Pkl,lt)
v1 = -a(lt);
v2 = Pkl-a(lt)+0.0001;
% v1
% v2
% v1(2)/v1(1)
% v2(2)/v2(1)
% atan(v1(2)/v1(1))
% atan(v2(2)/v2(1))
if (v1(1)<0) & (v1(2)<0) & (v2(1)<0) & (v2(2)>0)
    alph = atan(v1(2)/v1(1))-atan(v2(2)/v2(1)); % non trigonometric orientation
else
    alph = atan2(v1(2),v1(1))-atan2(v2(2),v2(1));
end

