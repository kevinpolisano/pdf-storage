function Q = transf(I,u,v,P)
x0 = [1 0];
theta = acos(dot(u,x0));
T(1) = P(1)-I(1);
T(2) = P(2)-I(2);
Q(1) = cos(theta)*T(1)-sin(theta)*T(2);
Q(2) = sin(theta)*T(1)+cos(theta)*T(2);
end