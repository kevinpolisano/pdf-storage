function j = findAngle(alph)
global angles;
l = 1;
aj = angles(l);
while (alph > aj)
    l = l+1;
    aj = angles(l);
end;
j = l-1;
end

