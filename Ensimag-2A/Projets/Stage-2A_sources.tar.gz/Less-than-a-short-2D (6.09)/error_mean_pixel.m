function res = error_mean_pixel(T1,T2)
s = 0;
l1 = size(T1,1);
l2 = size(T1,2);
for i=1:l1
    for j=1:l2
        s = s + abs(T1(i,j)-T2(i,j));
    end
end
res = s/(l1*l2);      
end

