%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Evaluate pH(n(phi_k),sl)) by a bilinear interpolation of gH
% It corresponds to the rebinning process
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function res = pH(k,l)
global lambda doublecalc nonreconst Q SL PHIK;

Pkl = SL(l+Q+1)*n(PHIK(k)); 

orthoN = n(PHIK(k)+pi/2);



% we're looking for the intersection P1=a(l1) and P2=a(l2)
% between the line (phi_k,s_l) and the vertex path
[P1 P2 P1in P2in l1 l2] = intersecPath2(k,l);
%[P1 P2 P1in P2in l1 l2] = intersecPath(Pkl,n(phik(k)));

% if P1 belongs to the vertex path
if P1in 
    alph1 = alphat(Pkl,l1)
    i = findVertex2(l1);
    j = findAngle(alph1);
    pH1 = interpolBilGH(i,l1,j,alph1);
    vPA1 = (P1-Pkl)/norm(P1-Pkl);
    pH1 = -pH1*(sign(dot(vPA1,orthoN)));
end

% if P1 belongs to the vertex path
if P2in 
    alph2 = alphat(Pkl,l2)
    i = findVertex2(l2);
    j = findAngle(alph2);
    pH2 = interpolBilGH(i,l2,j,alph2);
    vPA2 = (P2-Pkl)/norm(P2-Pkl);
    pH2 = -pH2*(sign(dot(vPA2,orthoN)));
end

if P1in & not(P2in)
    result = pH1;
end;

if P2in & not(P1in)
    result = pH2;
end;

if P1in & P2in
    doublecalc(k,l+Q+1) = 1;
    result = (pH1+pH2)/2;
end;

if not(P1in) & not(P2in)
    disp 'nonreconst';
    nonreconst(k,l+Q+1) = 1;
    result = 0;
end;

res = result;
end

