function res = phik(k)
global M;
res = (k*pi)./M;
end

