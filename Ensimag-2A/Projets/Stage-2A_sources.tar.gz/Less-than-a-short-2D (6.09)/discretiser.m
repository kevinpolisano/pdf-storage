function L = discretiser(A,B,alpha,n)
vAB = B-A;
longueur = norm(vAB);
pas = longueur/(n-1);
L = zeros(2,n);
for i=1:n
    P = A + (i-1)*pas*alpha;
    L(:,i) = P;
    
end
end

