function res = e1(lambda)
res = [-cos(lambda) -sin(lambda)];
end

