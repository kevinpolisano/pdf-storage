%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Last main function of the program : the reconstruction
% It reconstructs a square image inscribed in the FOV circle
% by calculating f(x) for each pixels x inside
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function reconstruction

load donnees;
global php SL PHIK;

global I u v;
x = sl(8)*n(phik(5));
y=transf(I,u,v,x)
f(x)
P = phantom(128);
P(floor(y(1)),floor(y(2)))

global RROI;
r = RROI-1;
c = sqrt(2)*r;
PP(1) = floor(-c/2);
PP(2) = floor(c/2);
cote = floor(c);

F = zeros(cote,cote);
Freal = zeros(cote,cote);
for i=1:cote
    i
    for j=1:cote
        x(2) = PP(2)-(i-1);
        x(1) = PP(1)+(j-1);
        F(i,j) = f(x);
        y=transf(I,u,v,x);
        Freal(i,j)=P(floor(y(1)),floor(y(2)));
    end
end

[moy_pix e_pix max_err err_quad Ferr] = calculate_errors(F,Freal)
error_by_pix = error_mean_pixel(F,Freal)
error_quadra = error_quad(F,Freal)


ImgDensity = mat2gray(F);


LL = critic_points(Ferr,0.1,cote);
save donnees;

imshow(ImgDensity);
hold on
plot(LL(1,:),LL(2,:),'o','color','r');
hold off

figure;
plot(Ferr);
hold on;
plot([1 length(Ferr)],[moy_pix moy_pix],'r');
axis([0 5000 0 0.1]);




end

