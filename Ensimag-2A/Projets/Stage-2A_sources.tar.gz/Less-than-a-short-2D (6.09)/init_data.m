%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% File that contains all constants and structures used then   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function init_data

% Shepp-Logan phantom (size 128x128)
global P;
P = phantom(128);

global I u v width height xbox ybox;
% image's positions
I = [-98 5];
v = [cos(pi/4) sin(pi/4)];
u = [cos(-pi/4) sin(-pi/4)];
% image's dimensions
width = 128;
height = 128;
uh = u*height;
vw = v*width;
% Image's box :
C1 = I;
C2 = I + vw;
C3 = C2 + uh;
C4 = I + uh;
xbox = [C1(1) C2(1) C3(1) C4(1) C1(1)];
ybox = [C1(2) C2(2) C3(2) C4(2) C1(2)];

% Circular trajectory (vertex path)
global Rtraj;
Rtraj = 150;

% Circular FOV (field of view) and angle of view
global RROI gammam Q M;
RROI = 50;
gammam = asin(RROI/Rtraj);

% FOV discretization
Q = 512;
M = floor(pi*Q);

% Vertex path discretization
NVertex = 512;
global lambda;
lambda = linspace(0,pi+2*gammam,NVertex);
global A; % contains vertex points
A = zeros(2,NVertex);
for i=1:NVertex 
    cour = a(lambda(i));
    A(1,i) = cour(1);
    A(2,i) = cour(2);
end

% Beams discretization
global angles pas;
Nbeams = 1024;
angles = linspace(-gammam,gammam,Nbeams);
pas = (2.*gammam)./(length(angles)-1);

% Storage in vectors instead of calling functions
global H SL PHIK;
for l=1-length(angles):length(angles)-1
    H(l+length(angles))=h(sin(l*pas));
end;
for l=-Q:Q
    SL(l+Q+1) = sl(l);
end;
for k=1:M
    PHIK(k) = phik(k);
end;

% Structures in memory which will be filled
global G GH ph php doublecalc nonreconst;
G = zeros(length(lambda),length(angles));
GH = zeros(length(lambda),length(angles));
ph = zeros(M,2*Q+1);
php = zeros(M,2*Q+1);

doublecalc = zeros(M,2*Q+1);
nonreconst = zeros(M,2*Q+1);

% All is saved in a data file donnees.mat
save donnees;

end