function [moy_pix,e_pix,max_err,err_quad,Ferr] = calculate_errors(F,Freal);
l1 = size(F,1);
l2 = size(F,2);
k = 1;
for i=1:l1
    for j=1:l2
        Ferr(k) = abs(F(i,j)-Freal(i,j));
        k = k+1;
    end
end
moy_pix = mean(Ferr);
e_pix = std(Ferr);
max_err = max(Ferr);
err_quad = sum(Ferr.^2);
end