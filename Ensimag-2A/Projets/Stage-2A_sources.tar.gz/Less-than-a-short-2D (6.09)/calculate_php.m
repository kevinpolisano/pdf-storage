%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fill the array PHP by calculating all pH'(n(phi_k),sl))
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function calculate_php
global params M Q php
load donnees

if params.phpcalc == 1
    for k=1:M
        k
        php(k,1) = (ph(k,2)-ph(k,1))/(sl(-Q+1)-sl(-Q));
        for l=-Q+2:Q  
            php(k,l+Q) = (ph(k,l+Q+1)-ph(k,l+Q-1))/(sl(l+1)-sl(l-1));
        end
    end
end
% we save the php matrix (to avoid to calculate it each time)
save donnees
end

