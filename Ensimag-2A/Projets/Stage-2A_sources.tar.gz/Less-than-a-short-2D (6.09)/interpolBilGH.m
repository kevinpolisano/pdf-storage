function res = interpolBilGH(i,lt,j,alpht)
global lambda angles GH;
x1 = lambda(i);
x = lt;
x2 = lambda(i+1);

y1 = angles(j);
y = alpht;
y2 = angles(j+1);

% i
% j
% y1
% y2
% GH(i,j)
% GH(i+1,j)
% GH(i,j+1)
% GH(i+1,j+1)
somme = GH(i,j)*(x2-x)*(y2-y)+GH(i+1,j)*(x-x1)*(y2-y);
somme = somme + GH(i,j+1)*(x2-x)*(y-y1)+GH(i+1,j+1)*(x-x1)*(y-y1);

res = somme/((x2-x1)*(y2-y1));
end

