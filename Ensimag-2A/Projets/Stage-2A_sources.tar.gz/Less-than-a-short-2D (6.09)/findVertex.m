function res = findVertex(k,l)
global lambda;
ind = 1;
m = abs(sl(l)-dot(a(lambda(ind)),n(phik(k))));
for i=2:length(lambda)
    test = abs(sl(l)-dot(a(lambda(i)),n(phik(k))));
    if test<m
        m = test;
        ind = i;
    end
end

% VERSION AMELIOREE
% for i=1:length(lambda)
%     ni = e2(lambda(i));
%     m(i) = dot(ni,n(phik(k)));
% end:
% m = m(1);
% ind = 1;
% for i=2:length(lambda)
%     if m(i)>m 
%         m = m(i);
%         ind = i;
%     end
% end

res = ind;
end

