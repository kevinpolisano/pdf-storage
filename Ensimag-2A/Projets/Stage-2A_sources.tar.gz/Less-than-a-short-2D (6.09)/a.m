function res = a(lambda)
global Rtraj;
x = Rtraj*cos(lambda);
y = Rtraj*sin(lambda);
res = [x y];
end

