function out = mainHH( )
% Temps de simulation (en ms)
tfinal=100;

% Conditions initiales (ici y0 est point fixe)
 y0=[-65,0.3177,0.06,0.6];
%y0 = [-10,0.3177,0.06,0.6]

% Résolution du système différentiel par méthode de Runge-Kutta
display 'Resolution du systeme dynamique'
[t,y]=ode45('Hodgkin',[0,tfinal],y0);

% On récupère V, n, m et h
y1=y(:,1);
y2=y(:,2);
y3=y(:,3);
y4=y(:,4);

% Variables de déclenchement

% n + h
plot(t,y2+y4,'r')
xlabel('temps (ms)');
ylabel('potentiel (mV)');
title('n+h pour 4uA');
axis([0 100 0 1]);

V=[-80:0.01:50];
for i=1:size(V,2)
    i
    V(i)
    Tm(i)=tau_m(V(i));  
        Tn(i)=tau_n(V(i));
            Th(i)=tau_h(V(i));
    Tm(i)
end
% plot(V,Tm,'r');
% hold on
% plot(V,Tn,'g');
% plot(V,Th,'b');
% xlabel('V (mV)');
% ylabel('\tau (ms)');
% title('Constantes de temps');
% legend('\tau_m','\tau_n','\tau_h');

end

function res = alpha_n(V)
    res = 0.01*(V+55)/(1-exp(-(V+55)/10));
end

function res = alpha_m(V)
    res = 0.1*(V+40)/(1-exp(-(V+40)/10));
end

function res = alpha_h(V)
    res = 0.07*exp(-(V+65)/20);
end

function res = beta_n(V)
    res = 0.125*exp(-(V+65)/80);
end

function res = beta_m(V)
    res = 4*exp(-(V+65)/18);
end

function res = beta_h(V)
    res = 1/(1+exp(-(V+35)/10));
end

function res = tau_m(V)
    res = 1/(alpha_m(V)+beta_m(V));
end

function res = tau_n(V)
    res = 1/(alpha_n(V)+beta_n(V));
end

function res = tau_h(V)
    res = 1/(alpha_h(V)+beta_h(V));
end