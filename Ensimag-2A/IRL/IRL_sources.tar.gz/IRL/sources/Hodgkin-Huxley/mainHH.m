function out = mainHH( )
% Temps de simulation (en ms)
tfinal=100;

% Conditions initiales (ici y0 est point fixe)
 y0=[-65,0.3177,0.06,0.6];
%y0 = [-10,0.3177,0.06,0.6]

% Résolution du système différentiel par méthode de Runge-Kutta
display 'Resolution du systeme dynamique'
[t,y]=ode45('Hodgkin',[0,tfinal],y0);

% On récupère V, n, m et h
y1=y(:,1);
y2=y(:,2);
y3=y(:,3);
y4=y(:,4);

% On les trace

% Potentiel membranaire V
subplot(221)
plot(t,y1)
xlabel('temps (ms)');
ylabel('potentiel (mV)');
title('potentiel membranaire V');

% Variables de déclenchement

% V
subplot(221)
plot(t,y2)
xlabel('temps (ms)');
ylabel('potentiel (mV)');
title('V');
axis([0 100 -70 50]);

% n
subplot(222)
plot(t,y2,'g')
xlabel('temps (ms)');
ylabel('potentiel (mV)');
title('n');
axis([0 100 0 1]);

% m
subplot(223)
plot(t,y3,'r')
xlabel('temps (ms)');
ylabel('potentiel (mV)');
title('m');
axis([0 100 0 1]);

% h
subplot(224)
plot(t,y4,'m')
xlabel('temps (ms)');
ylabel('potentiel (mV)');
title('h');
axis([0 100 0 1]);
end

