
% On met le système différentiel sous la forme Y' = f(Y)
% avec Y = (V,n,m,h) appartenant à R^4 et f : R^4 -> R^4
% Ici Hodgkin joue le rôle de f, elle calcule f(y)
function ypoint = Hodgkin(t,y)
% Constantes physiques
gNa=120;
gK=36;
gL=0.3;
eNa=50;
eK=-77;
eL=-54.4;
cM=1;
Q10=3;
T=6.3;
Tb=6.3;
phi=Q10^((T-Tb)/10);
current = 4; % 4 et 10 ùA/cm²
tstimul = 10;

% On injecte le courant à la date tstimul
if (t < tstimul) 
    stimul = 0;
else
    stimul = current; 
end

% Image de y par f
ypoint(1) = 1/cM*(-gNa*y(3)^3*y(4)*(y(1)-eNa)-gK*y(2)^4*(y(1)-eK)-gL*(y(1)-eL)+stimul);
ypoint(2) = phi*(alpha_n(y(1))*(1-y(2))-beta_n(y(1))*y(2));
ypoint(3) = phi*(alpha_m(y(1))*(1-y(3))-beta_m(y(1))*y(3));
ypoint(4) = phi*(alpha_h(y(1))*(1-y(4))-beta_h(y(1))*y(4));

ypoint = ypoint';

end

function res = alpha_n(V)
    res = 0.01*(V+55)/(1-exp(-(V+55)/10));
end

function res = alpha_m(V)
    res = 0.1*(V+40)/(1-exp(-(V+40)/10));
end

function res = alpha_h(V)
    res = 0.07*exp(-(V+65)/20);
end

function res = beta_n(V)
    res = 0.125*exp(-(V+65)/80);
end

function res = beta_m(V)
    res = 4*exp(-(V+65)/18);
end

function res = beta_h(V)
    res = 1/(1+exp(-(V+35)/10));
end