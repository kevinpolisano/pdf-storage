function res = fi(v,w,Iapp)
    res = F(v,w)+Iapp;
end

function res = F(v,w)
    res = 0.04*v*v+5*v+140-w;
    %res = 0.00127627*v*v+0.158183*v+5.213845;
    %res = 3*v*v+374*v+10552-1170*w;
end