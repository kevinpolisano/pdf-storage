function out = mainIF()
tsimul = 150;
stimul = 20; % courant applique
step = 0.01; % pour la methode d'Euler
tn = 0;
yn(1) = -10;  
yn(2) = 0.1;
vreset = -50;
seuilfixe = 30; % seuil au dela duquel on emet un spike
d = 2;
i = 1;
j = 1;

temps(i) = tn;
volt(i) = yn(1);

while (tn < tsimul)
    tn
    yn
    yn = IF(yn,tn,step,stimul);
    tn = tn+step;
    
    if (yn(1) > seuilfixe) 
        yn(1) = vreset;
        yn(2) = yn(2)+d;
        spike(j) = tn;
        j = j+1
    end;   
    i = i+1;
    temps(i) = tn;
    volt(i) = yn(1);
end;

plot(temps,volt);
end