function res = gi(v,w)
%a=0.0159; b=1.353;
a=0.02; b=0.2;
%res = 0.0004*v+0.2729-0.2707*w;
res = a*(b*v-w);
end

