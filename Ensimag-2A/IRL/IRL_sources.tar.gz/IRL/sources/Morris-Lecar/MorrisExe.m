
function out = main( )
% Temps de simulation (en ms)
tfinal=300;

% Conditions initiales
y03=[-10,0.1];
y02=[-25,0.15]
Iapp=90;

% Résolution du système différentiel par méthode de Runge-Kutta
display 'Resolution du systeme dynamique'
[t3,y3]=ode45(@(t,y) Morris(t,y,Iapp),[0,tfinal],y03);
[t2,y2]=ode45(@(t,y) Morris(t,y,Iapp),[0,tfinal],y02);

% On récupère les solutions
V3=y3(:,1);
n3=y3(:,2);
V2=y2(:,1);
n2=y2(:,2);

% On les trace

%Potentiels membranaire V
figure(1);
plot(t3,V3,'r')
hold on
plot (t2,V2,'b')
%line([0 700],[-36 -36],'Linestyle','--','Color','g')
xlabel('temps (ms)');
ylabel('potentiel (mV)');
title('potentiel membranaire solution');
leg2 = legend('V3','V2','VR');
hold off

% Diagramme de phase
figure(2);
plot(V3,n3,'r')
fi = @(V,n) f(V,n,Iapp);
hold on;
plot(V2,n2,'b');
ez1=ezplot(fi,[-70,50]);
set(ez1,'Color',[0 1 0]);
ez2=ezplot('g',[-70,50]);
set(ez2,'Color',[1 0 1]);
% plot(-25,0.07,'o','Color','g');
% plot(-37,0.07,'o','Color','b');
% plot(60.5,0.07,'o','Color','r');
% line([-37 -25],[0.07 0.07],'Color','b')
% line([60.5 -25],[0.07 0.07],'Color','r')
xlabel('V');
ylabel('n');
title('Diagramme de phase');
axis([-70 50 0 0.6]);
leg1 = legend('(V3,n3)','(V2,n2)','V-nullcline','n-nullcline');

end

