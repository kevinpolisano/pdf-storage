

% On met le système différentiel sous la forme Y' = f(Y)
% avec Y = (V,n,m,h) appartenant à R^4 et f : R^4 -> R^4
% Ici Hodgkin joue le rôle de f, elle calcule f(y)
function ypoint = Morris(t,y,Iapp)
% Constantes physiques

% Image de y par f
ypoint(1) = f(y(1),y(2),Iapp);
ypoint(2) = g(y(1),y(2));

ypoint = ypoint';

end





