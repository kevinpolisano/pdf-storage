function res = g(V,n)
phi=0.04;
res = phi*(n_inf(V)-n)/tau_n(V);
end

function res = tau_n(V)
    V3=2;
    V4=30;
    res = 1/cosh((V-V3)/(2*V4));
end

function res = n_inf(V)
    V3=2;
    V4=30;
    res = 0.5*(1+tanh((V-V3)/V4));
end