
function res = f(V,n,Iapp)
gCa=4.4;
gK=8;
gL=2;
eCa=120;
eK=-84;
eL=-60;
CM=20;
res = 1/CM*(-gCa*m_inf(V)*(V-eCa)-gK*n*(V-eK)-gL*(V-eL)+Iapp);
end

function res = m_inf(V)
    V1=-1.2;
    V2=18;
    res = 0.5*(1+tanh((V-V1)/V2));
end