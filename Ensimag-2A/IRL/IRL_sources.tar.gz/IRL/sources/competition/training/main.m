function out = main( )
spike_train('current.txt','voltage_allrep.txt');
end