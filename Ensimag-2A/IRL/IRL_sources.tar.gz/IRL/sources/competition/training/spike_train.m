function out = spike_train(entree,sortie)
fid_entree = fopen(entree);
[tab_entree,count] = fscanf(fid_entree,'%f',inf);
count
tab_entree = tab_entree';
fclose(fid_entree);
dim_entree = size(tab_entree,2)
%for i=1:dim_entree
 %   disp(tab_entree(i));
%end

fid_sortie = fopen(sortie);
[tab_sortie,count] = fscanf(fid_sortie,'%f %f %f %f %f %f %f %f %f %f %f %f %f',[13 inf]);
count
tab_sortie = tab_sortie';
fclose(fid_sortie);
dim_sortie = size(tab_sortie)

%for i=1:1
 %   for j=1:dim_sortie(2)
  %      disp(tab_sortie(i,j));
   % end
%end

v = tab_sortie(:,5);
size(v)
v3 = zeros(size(v),1);

for i=1:size(v)
    if (v(i)>=0)
        v3(i) = v(i);
    end
end

size(v3)
%plot(1:size(v3),v3);
plot(1:size(v),v);
end