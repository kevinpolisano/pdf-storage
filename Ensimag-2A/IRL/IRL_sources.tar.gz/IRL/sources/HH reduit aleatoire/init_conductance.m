%function init_conductance
% initialisation pour un input de type conductance
global Tsim Tagexc Taginh Tinac;
       
Tsim = 250 ;
t_exc = 2.45 ;
t_inh = 6.11 ;
A_exc = .073 ;
A_inh = .04  ;

Tinac = 10; % en ms;

fe = 80*3 ; % frequence effective : 80 synapses excitatrices � Hz
Te = 10^3/fe ;
fi = 20*2 ; % frequence effective : 20 synapses inhibitrices �  Hz
Ti = 10^3/fi ;

nspike_exc = round(Tsim/Te) ;
tspike_exc = cumsum(expinv(rand(nspike_exc,1),Te)) ;
nspike_inh = round(Tsim/Ti) ;
tspike_inh = cumsum(expinv(rand(nspike_inh,1),Ti)) ;

% on precalcule les conductances (utile pour gexc et ginh)
t=0:0.1:Tsim ;
Tagexc = zeros(1,length(t)) ;
Taginh = zeros(1,length(t)) ;
for i=1:length(t)
    for k = 1:nspike_exc
        Tagexc(i) = Tagexc(i) + A_exc*exp(-(t(i)-tspike_exc(k))/t_exc)*heav(t(i)-tspike_exc(k)) ;
    end
    for k = 1:nspike_inh
        Taginh(i) = Taginh(i) + A_inh*exp(-(t(i)-tspike_inh(k))/t_inh)*heav(t(i)-tspike_inh(k)) ;
    end
end

 % visualisation des conductances
%   figure
%   subplot(2,1,1) ;
%   plot(t,Tagexc,'r') ;
%   subplot(2,1,2) ;
%   plot(t,Taginh) ;