function y = input(t,v)
global Tinac

Eexc = 0.   ;
Einh = -75. ;
if (t > Tinac)
    y = gexc(t)*(Eexc-v) + ginh(t)*(Einh-v) ; 
else
    y = 0;
end;
    
end