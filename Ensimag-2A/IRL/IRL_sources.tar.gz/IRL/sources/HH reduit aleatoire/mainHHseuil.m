function out = main( )

a = -85; %Vmin
b = 50;  %Vmax
nx = 24; %nb subdivisions des abscisses
ny = 24;
hx = (b-a)/(nx-1);
hy = 1/(ny-1);

init_conductance;
tfinal=Tsim;

% Résolution du système différentiel par méthode de Runge-Kutta
i = 5
j = 2
% Conditions initiales (ici y0 est point fixe)
 y0=[-65,0.3177];
 
 Iapp=0;

[t,y]=ode15s(@(t,y) HHreduit(t,y,Iapp),[0,tfinal],y0);

% On récupère V, n

y1=y(:,1);
y2=y(:,2);
max(y1)

size(t)
size(y1)

t00=t;

tsimul = Tsim;
stimul = 0;
step = 0.001;
tn = 0;
yn(1) = -65;
yn(2) = 0.3177;
vreset = -75;
nreset = 0.7;
%d = 8;
i = 1;
j = 1;
refrac = 3;
temps(i) = tn;
volt(i) = yn(1);


while (tn < tsimul)

    yn = IFc(yn,tn,step,stimul);
    tn = tn+step;
    
    if (yn(2) < seuil(yn(1))) 
        yn(1) = vreset;
        yn(2) = nreset;
        spike(j) = tn;
        tn = tn+refrac;
        j = j+1
    end;   
    i = i+1;
    temps(i) = tn;
    volt(i) = yn(1);
end;

spike
j

% On affiche les spikes tronques
plot(temps,volt,'r');

hold on;
size(t)
size(y1)

% Et la reponse complete
plot(t00,y1);

axis([0 tfinal -80 50]);

end

