function y = gexc(t)

global Tsim Tagexc ;

n_bin = length(Tagexc)  ;
i = round(t/Tsim*(n_bin-1)) + 1 ;
y = Tagexc(i) ;