
function ysuiv = IF(yn,tn,h,stimul)
% Constantes physiques

% Image de y par f
ysuiv(1) = yn(1) + h*frc(yn(1),yn(2),stimul,tn);
ysuiv(2) = yn(2) + h*gr(yn(1),yn(2));

ysuiv = ysuiv';

end

