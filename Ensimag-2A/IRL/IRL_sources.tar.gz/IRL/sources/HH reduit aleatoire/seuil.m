function res = seuil(V)
a = 0.01879363;
b = 1.432178915;
res = a*V+b;
end