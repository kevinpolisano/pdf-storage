function out = mainIF()

init_conductance;

tsimul = Tsim;
stimul = 0;
step = 0.01;
tn = 0;
yn(1) = -65;
yn(2) = 0.3177;
vreset = -75;
nreset = 0.7;
i = 1;
j = 1;
refrac = 3;
temps(i) = tn;
volt(i) = yn(1);
potn(i) = yn(2)

while (tn < tsimul)
    tn
    yn
    yn = IFc(yn,tn,step,stimul);
    tn = tn+step;
    
    if (yn(2) < seuil(yn(1))) 
        yn(1) = vreset;
        yn(2) = nreset;
        spike(j) = tn;
        tn = tn+refrac;
        j = j+1
    end;   
    i = i+1;
    temps(i) = tn;
    volt(i) = yn(1);
    potn(i) = yn(2);
end;

spike
j
%v=[1,1,1,1,1,1,1,1]
%scatter(spike,v)


%plot(temps,volt);
a=-75
b=30

 Iapp=0;
if (a > -76.7)
    V = [a : 0.1 : b];
else
    V = [-76.7 : 0.1 : b];
end
N = zeros(size(V,2),1);
[N(1),fval] = fsolve(@(n) fr(V(1),n,Iapp),0.25);
N(1)
% V-nullcline
for i=2:size(V,2)
    i
    [N(i),fval] = fsolve(@(n) fr(V(i),n,Iapp),N(i-1));
    N(i)
end;

plot(volt,potn);
%plot(y1,y2,'b');
%fi = @(V,n) fr(V,n,Iapp);
hold on;
%ez1=ezplot(fi,[a,b]);

ez1=plot(V,N,'Color',[0 1 0],'LineWidth',2);
set(ez1,'Color',[0 1 0]);
ez2=ezplot('gr',[a,b]);
set(ez2,'Color',[1 0 1]);
%xlabel('temps (ms)');
%ylabel('potentiel (mV)');
%title('n');
axis([-75 30 0 1]);

end
