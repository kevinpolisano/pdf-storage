function y = ginh(t)

global Tsim Taginh ;

n_bin = length(Taginh)  ;
i = round(t/Tsim*(n_bin-1)) + 1 ;
y = Taginh(i) ;