function res = minimization2( )
x0 =[0,0,0,0];
[x,resnorm] = fminunc(@gmin,x0);
x
resnorm 
end

function res = gmin(z)
alpha1=z(1)
beta1=z(2)
gamma1=z(3)
mu1=z(4)
xmin=-60
ymin=0.1
xmax=-30
ymax=0.4
ainteg = @(x,y)differ(x,y,alpha1,beta1,gamma1,mu1)
res = dblquad(ainteg,xmin,xmax,ymin,ymax,1.0e-3);
end

function res = differ(x,y,alpha1,beta1,gamma1,mu1)
res = (grm(x,y)-alpha1.*x.*x-beta1.*x-gamma1-mu1.*y).^2;
end

function res = grm(V,n)
Q10=3;
T=6.3;
Tb=6.3;
phi=Q10^((T-Tb)/10);
res = phi*(alpha_n(V)*(1-n)-beta_n(V)*n);;
end

function res = alpha_n(V)
if abs(V+55) < 0.001
    res = 1 + (V+55)/20;
else
    res = 0.01*(V+55)/(1-exp(-(V+55)/10));
end
end

function res = beta_n(V)
    res = 0.125*exp(-(V+65)/80);
end