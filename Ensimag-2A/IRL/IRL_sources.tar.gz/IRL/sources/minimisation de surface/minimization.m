function res = minimization( )
% condition initiale
x0 =[3,374,10552,-1170];
[x,resnorm] = fminunc(@fmin,x0);
x       % solution de la minimisation
resnorm % erreur commise
end

% Distance L2 entre la surface f et la surface quadratique
function res = fmin(z)
alpha1=z(1)
beta1=z(2)
gamma1=z(3)
mu1=z(4)
xmin=-60
ymin=0.1
xmax=-30
ymax=0.4
ainteg = @(x,y)differ(x,y,alpha1,beta1,gamma1,mu1)
res = dblquad(ainteg,xmin,xmax,ymin,ymax,1.0e-3);
end

function res = differ(x,y,alpha1,beta1,gamma1,mu1)
res = (frm(x,y)-alpha1.*x.*x-beta1.*x-gamma1-mu1.*y).^2;
end

% surface f
function res = frm(x,y)
% Constantes physiques
gNa=120;
gK=36;
gL=0.3;
eNa=50;
eK=-77;
eL=-54.4;
cM=1;
res =  1/cM.*(-gNa.*m_infty(x).^3.*(0.8-y).*(x-eNa)-gK.*y.^4.*(x-eK)-gL.*(x-eL));
end

function res = m_infty(x)
    res = alpha_m(x)./(alpha_m(x)+beta_m(x));   
end

function res = alpha_m(x)
if abs(x+40) < 0.001
    res = 1 + (x+40)./20;
else
    res = 0.1.*(x+40)./(1-exp(-(x+40)./10));
end
end

function res = beta_m(x)
    res = 4.*exp(-(x+65)./18);
end
