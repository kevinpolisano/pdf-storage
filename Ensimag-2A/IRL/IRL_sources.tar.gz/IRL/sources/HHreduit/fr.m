
function res = fr(V,n)
% Constantes physiques
gNa=120;
gK=36;
gL=0.3;
eNa=50;
eK=-77;
eL=-54.4;
cM=1;
res =  1/cM*(-gNa*m_infty(V)^3*(0.8-n)*(V-eNa)-gK*n^4*(V-eK)-gL*(V-eL));
end

function res = m_infty(V)
    res = alpha_m(V)/(alpha_m(V)+beta_m(V));   
end

function res = alpha_m(V)
if abs(V+40) < 0.001
    res = 1 + (V+40)/20;
else
    res = 0.1*(V+40)/(1-exp(-(V+40)/10));
end
end

function res = beta_m(V)
    res = 4*exp(-(V+65)/18);
end
