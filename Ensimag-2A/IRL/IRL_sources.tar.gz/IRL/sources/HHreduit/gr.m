function res = g(V,n)
Q10=3;
T=6.3;
Tb=6.3;
phi=Q10^((T-Tb)/10);
res = phi*(alpha_n(V)*(1-n)-beta_n(V)*n);;
end

function res = alpha_n(V)
if abs(V+55) < 0.001
    res = 1 + (V+55)/20;
else
    res = 0.01*(V+55)/(1-exp(-(V+55)/10));
end
end

function res = beta_n(V)
    res = 0.125*exp(-(V+65)/80);
end