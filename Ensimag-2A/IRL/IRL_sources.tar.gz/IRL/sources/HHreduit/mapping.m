function out = main( )
% Temps de simulation (en ms)
tfinal=20;

a = -85; %Vmin
b = 50;  %Vmax
c = 1;
nx = 500; %nb subdivisions des abscisses
ny = 500;
hx = (b-a)/(nx-1);
hy = c/(ny-1);
cpt = 0;
k=1;

for i=1:nx
    for j=1:ny
% Résolution du système différentiel par méthode de Runge-Kutta
i,j
% Conditions initiales (ici y0 est point fixe)
% y0=[-65,0.3177,0.06,0.6];
    y0 = [a+(i-1)*hx,(j-1)*hy]

[t,y]=ode15s('HHreduit',[0,tfinal],y0);

% On récupère V, n
y1=y(:,1);
%y2=y(:,2);
m=max(y1);
if m>50
    m=50;
    cpt=cpt+1;
end
M(i,j)=m;
X(k)=a+(i-1)*hx;
Y(k)=(j-1)*hy;
k=k+1;
    end
end

cpt
X
Y

cmap = zeros(256,3);
cmap(1:128,3) = linspace(1, 0, 128);   % bleu
cmap(129:end,1) = linspace(0, 1, 128);  % rouge
cmap(129,:) = [];  % efface les doublons [0,0,0]
cmap

Vmin=min(min(M))
Vmax=max(max(M))

size(X,2)
C = zeros(size(X,2),3);
k = 1;
for i=1:nx
    for j=1:ny
        V=M(i,j);
        alpha=(V-Vmin)/(Vmax-Vmin);
        C(k,:)=(1-alpha)*[0 0 1]+alpha*[1 0 0];
        k = k+1;
    end
end
C
X=X'
Y=Y'
Iapp=0; 

if (a > -76.7)
    V = [a : 0.1 : b];
else
    V = [-76.7 : 0.1 : b];
end

N = zeros(size(V,2),1);
[N(1),fval] = fsolve(@(n) fr(V(1),n),0.25);
N(1)
% V-nullcline
for i=2:size(V,2)
    i
    [N(i),fval] = fsolve(@(n) fr(V(i),n),N(i-1));
    N(i)
end;

cpt

% On affiche la mapping ainsi que les nullclines
scatter(X,Y,10,C,'filled');
hold on
fi = @(V,n) fr(V,n);
ez1=plot(V,N,'Color',[0 1 0],'LineWidth',2);
ez2=ezplot('gr',[a,b]);
set(ez2,'Color',[1 1 0],'LineWidth',2);
xlabel('V');
ylabel('n');
axis([a b 0 c]);
title('Zones de spike');


end

