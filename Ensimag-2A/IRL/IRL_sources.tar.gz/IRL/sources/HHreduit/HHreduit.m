
% On met le système différentiel sous la forme Y' = f(Y)
% avec Y = (V,n) appartenant à R^2 et f : R^2 -> R^2
% Ici HH_reduit joue le rôle de f, elle calcule f(y)
function ypoint = HHreduit(t,y)
% Constantes physiques
gNa=120;
gK=36;
gL=0.3;
eNa=50;
eK=-77;
eL=-54.4;
cM=1;
Q10=3;
T=6.3;
Tb=6.3;
phi=Q10^((T-Tb)/10);
%current = 10; % 4 et 10 ùA/cm²


% Image de y par f
ypoint(1) = fr(y(1),y(2));
ypoint(2) = gr(y(1),y(2));

ypoint = ypoint';

end







