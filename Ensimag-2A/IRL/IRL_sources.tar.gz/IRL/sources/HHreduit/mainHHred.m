function out = main( )
% Temps de simulation (en ms)
tfinal=20;

a = -85; %Vmin
b = 50;  %Vmax
nx = 24; %nb subdivisions des abscisses
ny = 24;
hx = (b-a)/(nx-1);
hy = 1/(ny-1);


% Résolution du système différentiel par méthode de Runge-Kutta

% Conditions initiales (ici y0 est point fixe)

 y0=[-65,0.3177];
 
 Iapp=0;

[t,y]=ode15s(@(t,y) HHreduit(t,y,Iapp),[0,tfinal],y0);

% On récupère V, n
y1=y(:,1);
y2=y(:,2);
max(y1)

 
% if (a > -76.7)
%     V = [a : 0.1 : b];
% else
%     V = [-76.7 : 0.1 : b];
% end
% N = zeros(size(V,2),1);
% [N(1),fval] = fsolve(@(n) fr(V(1),n,Iapp),0.25);
% N(1)
% % V-nullcline
% for i=2:size(V,2)
%     i
%     [N(i),fval] = fsolve(@(n) fr(V(i),n,Iapp),N(i-1));
%     N(i)
% end;


%y(1:100)
plot(t,y1);
axis([0 tfinal -80 50]);
%plot(y1,y2,'b');
%fi = @(V,n) fr(V,n,Iapp);
hold on;
%ez1=ezplot(fi,[a,b]);
%set(ez1,'Color',[0 1 0]);
%ez1=plot(V,N,'Color',[0 1 0],'LineWidth',2);
%ez2=ezplot('gr',[a,b]);
%set(ez2,'Color',[1 0 1]);
xlabel('temps (ms)');
ylabel('potentiel (mV)');
title('n');
%axis([a b 0 1]);

end

