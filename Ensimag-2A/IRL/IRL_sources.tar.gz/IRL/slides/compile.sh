#!/bin/bash

latex slides.tex
dvips slides.dvi
ps2pdf slides.ps
rm slides.dvi slides.ps slides.aux slides.log