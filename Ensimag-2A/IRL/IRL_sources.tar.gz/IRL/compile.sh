#!/bin/bash

latex rapport.tex
dvips rapport.dvi
ps2pdf rapport.ps
rm rapport.dvi rapport.ps rapport.aux rapport.log